function getAllUrlParams() {
  return Object.fromEntries(new URLSearchParams(location.search));
}
function createLead() {
  var e = { parameters: getAllUrlParamsObj };
  Cookies.set("Lead", e, { expires: 1 });
}
function is_this_utm_equal_to_cookie_utm_values() {
  if (void 0 === cookieExist) return !1;
  for (const e of my_utmParameters) {
    if (!(JSON.parse(cookieExist).parameters[e] === getAllUrlParamsObj[e]))
      return !1;
  }
  return !0;
}
function setUTMformValues() {
  function e(e) {
    let r = JSON.parse(Cookies.get("Lead")).parameters[e],
      a = document.getElementsByClassName(e);
    if (a.length > 0)
      for (var s = 0; s < a.length; s++) a[s].value = r && void 0 !== r ? r : t;
  }
  const t = "null";
  for (const t of my_utmParameters) e(t);
}
const my_utmParameters = [
  "utm_source",
  "utm_medium",
  "utm_campaign",
  "utm_term",
  "utm_content",
  "gclid",
];
var cookieExist = Cookies.get("Lead"),
  getAllUrlParamsObj = getAllUrlParams(),
  getAllUrlParamsJSON = JSON.stringify(getAllUrlParamsObj),
  isEmpty = jQuery.isEmptyObject(getAllUrlParamsObj);
isEmpty || void 0 !== cookieExist || (createLead(), setUTMformValues());
let compare = is_this_utm_equal_to_cookie_utm_values();
isEmpty ||
  void 0 === cookieExist ||
  (compare || (Cookies.remove("Lead"), createLead()), setUTMformValues()),
  isEmpty && void 0 !== cookieExist && setUTMformValues();
