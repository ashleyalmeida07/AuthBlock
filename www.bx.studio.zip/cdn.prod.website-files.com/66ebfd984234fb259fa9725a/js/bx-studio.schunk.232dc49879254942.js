(self.webpackChunk = self.webpackChunk || []).push([
  ["400"],
  {
    5487: function () {
      "use strict";
      window.tram = (function (e) {
        function t(e, t) {
          return new G.Bare().init(e, t);
        }
        function a(e) {
          var t = parseInt(e.slice(1), 16);
          return [(t >> 16) & 255, (t >> 8) & 255, 255 & t];
        }
        function n(e, t, a) {
          return (
            "#" + (0x1000000 | (e << 16) | (t << 8) | a).toString(16).slice(1)
          );
        }
        function i() {}
        function l(e, t, a) {
          if ((void 0 !== t && (a = t), void 0 === e)) return a;
          var n = a;
          return (
            $.test(e) || !q.test(e)
              ? (n = parseInt(e, 10))
              : q.test(e) && (n = 1e3 * parseFloat(e)),
            0 > n && (n = 0),
            n == n ? n : a
          );
        }
        function d(e) {
          Y.debug && window && window.console.warn(e);
        }
        var o,
          c,
          s,
          r = (function (e, t, a) {
            function n(e) {
              return "object" == typeof e;
            }
            function i(e) {
              return "function" == typeof e;
            }
            function l() {}
            return function d(o, c) {
              function s() {
                var e = new r();
                return i(e.init) && e.init.apply(e, arguments), e;
              }
              function r() {}
              c === a && ((c = o), (o = Object)), (s.Bare = r);
              var f,
                u = (l[e] = o[e]),
                p = (r[e] = s[e] = new l());
              return (
                (p.constructor = s),
                (s.mixin = function (t) {
                  return (r[e] = s[e] = d(s, t)[e]), s;
                }),
                (s.open = function (e) {
                  if (
                    ((f = {}),
                    i(e) ? (f = e.call(s, p, u, s, o)) : n(e) && (f = e),
                    n(f))
                  )
                    for (var a in f) t.call(f, a) && (p[a] = f[a]);
                  return i(p.init) || (p.init = o), s;
                }),
                s.open(c)
              );
            };
          })("prototype", {}.hasOwnProperty),
          f = {
            ease: [
              "ease",
              function (e, t, a, n) {
                var i = (e /= n) * e,
                  l = i * e;
                return (
                  t +
                  a *
                    (-2.75 * l * i + 11 * i * i + -15.5 * l + 8 * i + 0.25 * e)
                );
              },
            ],
            "ease-in": [
              "ease-in",
              function (e, t, a, n) {
                var i = (e /= n) * e,
                  l = i * e;
                return t + a * (-1 * l * i + 3 * i * i + -3 * l + 2 * i);
              },
            ],
            "ease-out": [
              "ease-out",
              function (e, t, a, n) {
                var i = (e /= n) * e,
                  l = i * e;
                return (
                  t +
                  a *
                    (0.3 * l * i + -1.6 * i * i + 2.2 * l + -1.8 * i + 1.9 * e)
                );
              },
            ],
            "ease-in-out": [
              "ease-in-out",
              function (e, t, a, n) {
                var i = (e /= n) * e,
                  l = i * e;
                return t + a * (2 * l * i + -5 * i * i + 2 * l + 2 * i);
              },
            ],
            linear: [
              "linear",
              function (e, t, a, n) {
                return (a * e) / n + t;
              },
            ],
            "ease-in-quad": [
              "cubic-bezier(0.550, 0.085, 0.680, 0.530)",
              function (e, t, a, n) {
                return a * (e /= n) * e + t;
              },
            ],
            "ease-out-quad": [
              "cubic-bezier(0.250, 0.460, 0.450, 0.940)",
              function (e, t, a, n) {
                return -a * (e /= n) * (e - 2) + t;
              },
            ],
            "ease-in-out-quad": [
              "cubic-bezier(0.455, 0.030, 0.515, 0.955)",
              function (e, t, a, n) {
                return (e /= n / 2) < 1
                  ? (a / 2) * e * e + t
                  : (-a / 2) * (--e * (e - 2) - 1) + t;
              },
            ],
            "ease-in-cubic": [
              "cubic-bezier(0.550, 0.055, 0.675, 0.190)",
              function (e, t, a, n) {
                return a * (e /= n) * e * e + t;
              },
            ],
            "ease-out-cubic": [
              "cubic-bezier(0.215, 0.610, 0.355, 1)",
              function (e, t, a, n) {
                return a * ((e = e / n - 1) * e * e + 1) + t;
              },
            ],
            "ease-in-out-cubic": [
              "cubic-bezier(0.645, 0.045, 0.355, 1)",
              function (e, t, a, n) {
                return (e /= n / 2) < 1
                  ? (a / 2) * e * e * e + t
                  : (a / 2) * ((e -= 2) * e * e + 2) + t;
              },
            ],
            "ease-in-quart": [
              "cubic-bezier(0.895, 0.030, 0.685, 0.220)",
              function (e, t, a, n) {
                return a * (e /= n) * e * e * e + t;
              },
            ],
            "ease-out-quart": [
              "cubic-bezier(0.165, 0.840, 0.440, 1)",
              function (e, t, a, n) {
                return -a * ((e = e / n - 1) * e * e * e - 1) + t;
              },
            ],
            "ease-in-out-quart": [
              "cubic-bezier(0.770, 0, 0.175, 1)",
              function (e, t, a, n) {
                return (e /= n / 2) < 1
                  ? (a / 2) * e * e * e * e + t
                  : (-a / 2) * ((e -= 2) * e * e * e - 2) + t;
              },
            ],
            "ease-in-quint": [
              "cubic-bezier(0.755, 0.050, 0.855, 0.060)",
              function (e, t, a, n) {
                return a * (e /= n) * e * e * e * e + t;
              },
            ],
            "ease-out-quint": [
              "cubic-bezier(0.230, 1, 0.320, 1)",
              function (e, t, a, n) {
                return a * ((e = e / n - 1) * e * e * e * e + 1) + t;
              },
            ],
            "ease-in-out-quint": [
              "cubic-bezier(0.860, 0, 0.070, 1)",
              function (e, t, a, n) {
                return (e /= n / 2) < 1
                  ? (a / 2) * e * e * e * e * e + t
                  : (a / 2) * ((e -= 2) * e * e * e * e + 2) + t;
              },
            ],
            "ease-in-sine": [
              "cubic-bezier(0.470, 0, 0.745, 0.715)",
              function (e, t, a, n) {
                return -a * Math.cos((e / n) * (Math.PI / 2)) + a + t;
              },
            ],
            "ease-out-sine": [
              "cubic-bezier(0.390, 0.575, 0.565, 1)",
              function (e, t, a, n) {
                return a * Math.sin((e / n) * (Math.PI / 2)) + t;
              },
            ],
            "ease-in-out-sine": [
              "cubic-bezier(0.445, 0.050, 0.550, 0.950)",
              function (e, t, a, n) {
                return (-a / 2) * (Math.cos((Math.PI * e) / n) - 1) + t;
              },
            ],
            "ease-in-expo": [
              "cubic-bezier(0.950, 0.050, 0.795, 0.035)",
              function (e, t, a, n) {
                return 0 === e ? t : a * Math.pow(2, 10 * (e / n - 1)) + t;
              },
            ],
            "ease-out-expo": [
              "cubic-bezier(0.190, 1, 0.220, 1)",
              function (e, t, a, n) {
                return e === n
                  ? t + a
                  : a * (-Math.pow(2, (-10 * e) / n) + 1) + t;
              },
            ],
            "ease-in-out-expo": [
              "cubic-bezier(1, 0, 0, 1)",
              function (e, t, a, n) {
                return 0 === e
                  ? t
                  : e === n
                  ? t + a
                  : (e /= n / 2) < 1
                  ? (a / 2) * Math.pow(2, 10 * (e - 1)) + t
                  : (a / 2) * (-Math.pow(2, -10 * --e) + 2) + t;
              },
            ],
            "ease-in-circ": [
              "cubic-bezier(0.600, 0.040, 0.980, 0.335)",
              function (e, t, a, n) {
                return -a * (Math.sqrt(1 - (e /= n) * e) - 1) + t;
              },
            ],
            "ease-out-circ": [
              "cubic-bezier(0.075, 0.820, 0.165, 1)",
              function (e, t, a, n) {
                return a * Math.sqrt(1 - (e = e / n - 1) * e) + t;
              },
            ],
            "ease-in-out-circ": [
              "cubic-bezier(0.785, 0.135, 0.150, 0.860)",
              function (e, t, a, n) {
                return (e /= n / 2) < 1
                  ? (-a / 2) * (Math.sqrt(1 - e * e) - 1) + t
                  : (a / 2) * (Math.sqrt(1 - (e -= 2) * e) + 1) + t;
              },
            ],
            "ease-in-back": [
              "cubic-bezier(0.600, -0.280, 0.735, 0.045)",
              function (e, t, a, n, i) {
                return (
                  void 0 === i && (i = 1.70158),
                  a * (e /= n) * e * ((i + 1) * e - i) + t
                );
              },
            ],
            "ease-out-back": [
              "cubic-bezier(0.175, 0.885, 0.320, 1.275)",
              function (e, t, a, n, i) {
                return (
                  void 0 === i && (i = 1.70158),
                  a * ((e = e / n - 1) * e * ((i + 1) * e + i) + 1) + t
                );
              },
            ],
            "ease-in-out-back": [
              "cubic-bezier(0.680, -0.550, 0.265, 1.550)",
              function (e, t, a, n, i) {
                return (
                  void 0 === i && (i = 1.70158),
                  (e /= n / 2) < 1
                    ? (a / 2) * e * e * (((i *= 1.525) + 1) * e - i) + t
                    : (a / 2) *
                        ((e -= 2) * e * (((i *= 1.525) + 1) * e + i) + 2) +
                      t
                );
              },
            ],
          },
          u = {
            "ease-in-back": "cubic-bezier(0.600, 0, 0.735, 0.045)",
            "ease-out-back": "cubic-bezier(0.175, 0.885, 0.320, 1)",
            "ease-in-out-back": "cubic-bezier(0.680, 0, 0.265, 1)",
          },
          p = window,
          E = "bkwld-tram",
          T = /[\-\.0-9]/g,
          I = /[A-Z]/,
          y = "number",
          m = /^(rgb|#)/,
          g = /(em|cm|mm|in|pt|pc|px)$/,
          b = /(em|cm|mm|in|pt|pc|px|%)$/,
          O = /(deg|rad|turn)$/,
          v = "unitless",
          R = /(all|none) 0s ease 0s/,
          L = /^(width|height)$/,
          _ = document.createElement("a"),
          N = ["Webkit", "Moz", "O", "ms"],
          A = ["-webkit-", "-moz-", "-o-", "-ms-"],
          S = function (e) {
            if (e in _.style) return { dom: e, css: e };
            var t,
              a,
              n = "",
              i = e.split("-");
            for (t = 0; t < i.length; t++)
              n += i[t].charAt(0).toUpperCase() + i[t].slice(1);
            for (t = 0; t < N.length; t++)
              if ((a = N[t] + n) in _.style) return { dom: a, css: A[t] + e };
          },
          h = (t.support = {
            bind: Function.prototype.bind,
            transform: S("transform"),
            transition: S("transition"),
            backface: S("backface-visibility"),
            timing: S("transition-timing-function"),
          });
        if (h.transition) {
          var M = h.timing.dom;
          if (((_.style[M] = f["ease-in-back"][0]), !_.style[M]))
            for (var C in u) f[C][0] = u[C];
        }
        var U = (t.frame =
            (o =
              p.requestAnimationFrame ||
              p.webkitRequestAnimationFrame ||
              p.mozRequestAnimationFrame ||
              p.oRequestAnimationFrame ||
              p.msRequestAnimationFrame) && h.bind
              ? o.bind(p)
              : function (e) {
                  p.setTimeout(e, 16);
                }),
          k = (t.now =
            (s =
              (c = p.performance) &&
              (c.now || c.webkitNow || c.msNow || c.mozNow)) && h.bind
              ? s.bind(c)
              : Date.now ||
                function () {
                  return +new Date();
                }),
          w = r(function (t) {
            function a(e, t) {
              var a = (function (e) {
                  for (var t = -1, a = e ? e.length : 0, n = []; ++t < a; ) {
                    var i = e[t];
                    i && n.push(i);
                  }
                  return n;
                })(("" + e).split(" ")),
                n = a[0];
              t = t || {};
              var i = X[n];
              if (!i) return d("Unsupported property: " + n);
              if (!t.weak || !this.props[n]) {
                var l = i[0],
                  o = this.props[n];
                return (
                  o || (o = this.props[n] = new l.Bare()),
                  o.init(this.$el, a, i, t),
                  o
                );
              }
            }
            function n(e, t, n) {
              if (e) {
                var d = typeof e;
                if (
                  (t ||
                    (this.timer && this.timer.destroy(),
                    (this.queue = []),
                    (this.active = !1)),
                  "number" == d && t)
                )
                  return (
                    (this.timer = new F({
                      duration: e,
                      context: this,
                      complete: i,
                    })),
                    void (this.active = !0)
                  );
                if ("string" == d && t) {
                  switch (e) {
                    case "hide":
                      c.call(this);
                      break;
                    case "stop":
                      o.call(this);
                      break;
                    case "redraw":
                      s.call(this);
                      break;
                    default:
                      a.call(this, e, n && n[1]);
                  }
                  return i.call(this);
                }
                if ("function" == d) return void e.call(this, this);
                if ("object" == d) {
                  var u = 0;
                  f.call(
                    this,
                    e,
                    function (e, t) {
                      e.span > u && (u = e.span), e.stop(), e.animate(t);
                    },
                    function (e) {
                      "wait" in e && (u = l(e.wait, 0));
                    }
                  ),
                    r.call(this),
                    u > 0 &&
                      ((this.timer = new F({ duration: u, context: this })),
                      (this.active = !0),
                      t && (this.timer.complete = i));
                  var p = this,
                    E = !1,
                    T = {};
                  U(function () {
                    f.call(p, e, function (e) {
                      e.active && ((E = !0), (T[e.name] = e.nextStyle));
                    }),
                      E && p.$el.css(T);
                  });
                }
              }
            }
            function i() {
              if (
                (this.timer && this.timer.destroy(),
                (this.active = !1),
                this.queue.length)
              ) {
                var e = this.queue.shift();
                n.call(this, e.options, !0, e.args);
              }
            }
            function o(e) {
              var t;
              this.timer && this.timer.destroy(),
                (this.queue = []),
                (this.active = !1),
                "string" == typeof e
                  ? ((t = {})[e] = 1)
                  : (t = "object" == typeof e && null != e ? e : this.props),
                f.call(this, t, u),
                r.call(this);
            }
            function c() {
              o.call(this), (this.el.style.display = "none");
            }
            function s() {
              this.el.offsetHeight;
            }
            function r() {
              var e,
                t,
                a = [];
              for (e in (this.upstream && a.push(this.upstream), this.props))
                (t = this.props[e]).active && a.push(t.string);
              (a = a.join(",")),
                this.style !== a &&
                  ((this.style = a), (this.el.style[h.transition.dom] = a));
            }
            function f(e, t, n) {
              var i,
                l,
                d,
                o,
                c = t !== u,
                s = {};
              for (i in e)
                (d = e[i]),
                  i in z
                    ? (s.transform || (s.transform = {}), (s.transform[i] = d))
                    : (I.test(i) &&
                        (i = i.replace(/[A-Z]/g, function (e) {
                          return "-" + e.toLowerCase();
                        })),
                      i in X ? (s[i] = d) : (o || (o = {}), (o[i] = d)));
              for (i in s) {
                if (((d = s[i]), !(l = this.props[i]))) {
                  if (!c) continue;
                  l = a.call(this, i);
                }
                t.call(this, l, d);
              }
              n && o && n.call(this, o);
            }
            function u(e) {
              e.stop();
            }
            function p(e, t) {
              e.set(t);
            }
            function T(e) {
              this.$el.css(e);
            }
            function y(e, a) {
              t[e] = function () {
                return this.children
                  ? m.call(this, a, arguments)
                  : (this.el && a.apply(this, arguments), this);
              };
            }
            function m(e, t) {
              var a,
                n = this.children.length;
              for (a = 0; n > a; a++) e.apply(this.children[a], t);
              return this;
            }
            (t.init = function (t) {
              if (
                ((this.$el = e(t)),
                (this.el = this.$el[0]),
                (this.props = {}),
                (this.queue = []),
                (this.style = ""),
                (this.active = !1),
                Y.keepInherited && !Y.fallback)
              ) {
                var a = W(this.el, "transition");
                a && !R.test(a) && (this.upstream = a);
              }
              h.backface &&
                Y.hideBackface &&
                H(this.el, h.backface.css, "hidden");
            }),
              y("add", a),
              y("start", n),
              y("wait", function (e) {
                (e = l(e, 0)),
                  this.active
                    ? this.queue.push({ options: e })
                    : ((this.timer = new F({
                        duration: e,
                        context: this,
                        complete: i,
                      })),
                      (this.active = !0));
              }),
              y("then", function (e) {
                return this.active
                  ? (this.queue.push({ options: e, args: arguments }),
                    void (this.timer.complete = i))
                  : d(
                      "No active transition timer. Use start() or wait() before then()."
                    );
              }),
              y("next", i),
              y("stop", o),
              y("set", function (e) {
                o.call(this, e), f.call(this, e, p, T);
              }),
              y("show", function (e) {
                "string" != typeof e && (e = "block"),
                  (this.el.style.display = e);
              }),
              y("hide", c),
              y("redraw", s),
              y("destroy", function () {
                o.call(this),
                  e.removeData(this.el, E),
                  (this.$el = this.el = null);
              });
          }),
          G = r(w, function (t) {
            function a(t, a) {
              var n = e.data(t, E) || e.data(t, E, new w.Bare());
              return n.el || n.init(t), a ? n.start(a) : n;
            }
            t.init = function (t, n) {
              var i = e(t);
              if (!i.length) return this;
              if (1 === i.length) return a(i[0], n);
              var l = [];
              return (
                i.each(function (e, t) {
                  l.push(a(t, n));
                }),
                (this.children = l),
                this
              );
            };
          }),
          B = r(function (e) {
            function t() {
              var e = this.get();
              this.update("auto");
              var t = this.get();
              return this.update(e), t;
            }
            (e.init = function (e, t, a, n) {
              (this.$el = e), (this.el = e[0]);
              var i,
                d,
                o,
                c = t[0];
              a[2] && (c = a[2]),
                j[c] && (c = j[c]),
                (this.name = c),
                (this.type = a[1]),
                (this.duration = l(t[1], this.duration, 500)),
                (this.ease =
                  ((i = t[2]),
                  (d = this.ease),
                  (o = "ease"),
                  void 0 !== d && (o = d),
                  i in f ? i : o)),
                (this.delay = l(t[3], this.delay, 0)),
                (this.span = this.duration + this.delay),
                (this.active = !1),
                (this.nextStyle = null),
                (this.auto = L.test(this.name)),
                (this.unit = n.unit || this.unit || Y.defaultUnit),
                (this.angle = n.angle || this.angle || Y.defaultAngle),
                Y.fallback || n.fallback
                  ? (this.animate = this.fallback)
                  : ((this.animate = this.transition),
                    (this.string =
                      this.name +
                      " " +
                      this.duration +
                      "ms" +
                      ("ease" != this.ease ? " " + f[this.ease][0] : "") +
                      (this.delay ? " " + this.delay + "ms" : "")));
            }),
              (e.set = function (e) {
                (e = this.convert(e, this.type)), this.update(e), this.redraw();
              }),
              (e.transition = function (e) {
                (this.active = !0),
                  (e = this.convert(e, this.type)),
                  this.auto &&
                    ("auto" == this.el.style[this.name] &&
                      (this.update(this.get()), this.redraw()),
                    "auto" == e && (e = t.call(this))),
                  (this.nextStyle = e);
              }),
              (e.fallback = function (e) {
                var a =
                  this.el.style[this.name] ||
                  this.convert(this.get(), this.type);
                (e = this.convert(e, this.type)),
                  this.auto &&
                    ("auto" == a && (a = this.convert(this.get(), this.type)),
                    "auto" == e && (e = t.call(this))),
                  (this.tween = new D({
                    from: a,
                    to: e,
                    duration: this.duration,
                    delay: this.delay,
                    ease: this.ease,
                    update: this.update,
                    context: this,
                  }));
              }),
              (e.get = function () {
                return W(this.el, this.name);
              }),
              (e.update = function (e) {
                H(this.el, this.name, e);
              }),
              (e.stop = function () {
                (this.active || this.nextStyle) &&
                  ((this.active = !1),
                  (this.nextStyle = null),
                  H(this.el, this.name, this.get()));
                var e = this.tween;
                e && e.context && e.destroy();
              }),
              (e.convert = function (e, t) {
                if ("auto" == e && this.auto) return e;
                var a,
                  i,
                  l = "number" == typeof e,
                  o = "string" == typeof e;
                switch (t) {
                  case y:
                    if (l) return e;
                    if (o && "" === e.replace(T, "")) return +e;
                    i = "number(unitless)";
                    break;
                  case m:
                    if (o) {
                      if ("" === e && this.original) return this.original;
                      if (t.test(e))
                        return "#" == e.charAt(0) && 7 == e.length
                          ? e
                          : ((a = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(e))
                              ? n(a[1], a[2], a[3])
                              : e
                            ).replace(/#(\w)(\w)(\w)$/, "#$1$1$2$2$3$3");
                    }
                    i = "hex or rgb string";
                    break;
                  case g:
                    if (l) return e + this.unit;
                    if (o && t.test(e)) return e;
                    i = "number(px) or string(unit)";
                    break;
                  case b:
                    if (l) return e + this.unit;
                    if (o && t.test(e)) return e;
                    i = "number(px) or string(unit or %)";
                    break;
                  case O:
                    if (l) return e + this.angle;
                    if (o && t.test(e)) return e;
                    i = "number(deg) or string(angle)";
                    break;
                  case v:
                    if (l || (o && b.test(e))) return e;
                    i = "number(unitless) or string(unit or %)";
                }
                return (
                  d(
                    "Type warning: Expected: [" +
                      i +
                      "] Got: [" +
                      typeof e +
                      "] " +
                      e
                  ),
                  e
                );
              }),
              (e.redraw = function () {
                this.el.offsetHeight;
              });
          }),
          V = r(B, function (e, t) {
            e.init = function () {
              t.init.apply(this, arguments),
                this.original || (this.original = this.convert(this.get(), m));
            };
          }),
          x = r(B, function (e, t) {
            (e.init = function () {
              t.init.apply(this, arguments), (this.animate = this.fallback);
            }),
              (e.get = function () {
                return this.$el[this.name]();
              }),
              (e.update = function (e) {
                this.$el[this.name](e);
              });
          }),
          P = r(B, function (e, t) {
            function a(e, t) {
              var a, n, i, l, d;
              for (a in e)
                (i = (l = z[a])[0]),
                  (n = l[1] || a),
                  (d = this.convert(e[a], i)),
                  t.call(this, n, d, i);
            }
            (e.init = function () {
              t.init.apply(this, arguments),
                this.current ||
                  ((this.current = {}),
                  z.perspective &&
                    Y.perspective &&
                    ((this.current.perspective = Y.perspective),
                    H(this.el, this.name, this.style(this.current)),
                    this.redraw()));
            }),
              (e.set = function (e) {
                a.call(this, e, function (e, t) {
                  this.current[e] = t;
                }),
                  H(this.el, this.name, this.style(this.current)),
                  this.redraw();
              }),
              (e.transition = function (e) {
                var t = this.values(e);
                this.tween = new Q({
                  current: this.current,
                  values: t,
                  duration: this.duration,
                  delay: this.delay,
                  ease: this.ease,
                });
                var a,
                  n = {};
                for (a in this.current) n[a] = a in t ? t[a] : this.current[a];
                (this.active = !0), (this.nextStyle = this.style(n));
              }),
              (e.fallback = function (e) {
                var t = this.values(e);
                this.tween = new Q({
                  current: this.current,
                  values: t,
                  duration: this.duration,
                  delay: this.delay,
                  ease: this.ease,
                  update: this.update,
                  context: this,
                });
              }),
              (e.update = function () {
                H(this.el, this.name, this.style(this.current));
              }),
              (e.style = function (e) {
                var t,
                  a = "";
                for (t in e) a += t + "(" + e[t] + ") ";
                return a;
              }),
              (e.values = function (e) {
                var t,
                  n = {};
                return (
                  a.call(this, e, function (e, a, i) {
                    (n[e] = a),
                      void 0 === this.current[e] &&
                        ((t = 0),
                        ~e.indexOf("scale") && (t = 1),
                        (this.current[e] = this.convert(t, i)));
                  }),
                  n
                );
              });
          }),
          D = r(function (t) {
            function l() {
              var e,
                t,
                a,
                n = c.length;
              if (n)
                for (U(l), t = k(), e = n; e--; ) (a = c[e]) && a.render(t);
            }
            var o = { ease: f.ease[1], from: 0, to: 1 };
            (t.init = function (e) {
              (this.duration = e.duration || 0), (this.delay = e.delay || 0);
              var t = e.ease || o.ease;
              f[t] && (t = f[t][1]),
                "function" != typeof t && (t = o.ease),
                (this.ease = t),
                (this.update = e.update || i),
                (this.complete = e.complete || i),
                (this.context = e.context || this),
                (this.name = e.name);
              var a = e.from,
                n = e.to;
              void 0 === a && (a = o.from),
                void 0 === n && (n = o.to),
                (this.unit = e.unit || ""),
                "number" == typeof a && "number" == typeof n
                  ? ((this.begin = a), (this.change = n - a))
                  : this.format(n, a),
                (this.value = this.begin + this.unit),
                (this.start = k()),
                !1 !== e.autoplay && this.play();
            }),
              (t.play = function () {
                this.active ||
                  (this.start || (this.start = k()),
                  (this.active = !0),
                  1 === c.push(this) && U(l));
              }),
              (t.stop = function () {
                var t, a;
                this.active &&
                  ((this.active = !1),
                  (a = e.inArray(this, c)) >= 0 &&
                    ((t = c.slice(a + 1)),
                    (c.length = a),
                    t.length && (c = c.concat(t))));
              }),
              (t.render = function (e) {
                var t,
                  a = e - this.start;
                if (this.delay) {
                  if (a <= this.delay) return;
                  a -= this.delay;
                }
                if (a < this.duration) {
                  var i,
                    l,
                    d = this.ease(a, 0, 1, this.duration);
                  return (
                    (t = this.startRGB
                      ? ((i = this.startRGB),
                        (l = this.endRGB),
                        n(
                          i[0] + d * (l[0] - i[0]),
                          i[1] + d * (l[1] - i[1]),
                          i[2] + d * (l[2] - i[2])
                        ))
                      : Math.round((this.begin + d * this.change) * s) / s),
                    (this.value = t + this.unit),
                    void this.update.call(this.context, this.value)
                  );
                }
                (t = this.endHex || this.begin + this.change),
                  (this.value = t + this.unit),
                  this.update.call(this.context, this.value),
                  this.complete.call(this.context),
                  this.destroy();
              }),
              (t.format = function (e, t) {
                if (((t += ""), "#" == (e += "").charAt(0)))
                  return (
                    (this.startRGB = a(t)),
                    (this.endRGB = a(e)),
                    (this.endHex = e),
                    (this.begin = 0),
                    void (this.change = 1)
                  );
                if (!this.unit) {
                  var n = t.replace(T, "");
                  n !== e.replace(T, "") &&
                    d("Units do not match [tween]: " + t + ", " + e),
                    (this.unit = n);
                }
                (t = parseFloat(t)),
                  (e = parseFloat(e)),
                  (this.begin = this.value = t),
                  (this.change = e - t);
              }),
              (t.destroy = function () {
                this.stop(),
                  (this.context = null),
                  (this.ease = this.update = this.complete = i);
              });
            var c = [],
              s = 1e3;
          }),
          F = r(D, function (e) {
            (e.init = function (e) {
              (this.duration = e.duration || 0),
                (this.complete = e.complete || i),
                (this.context = e.context),
                this.play();
            }),
              (e.render = function (e) {
                e - this.start < this.duration ||
                  (this.complete.call(this.context), this.destroy());
              });
          }),
          Q = r(D, function (e, t) {
            (e.init = function (e) {
              var t, a;
              for (t in ((this.context = e.context),
              (this.update = e.update),
              (this.tweens = []),
              (this.current = e.current),
              e.values))
                (a = e.values[t]),
                  this.current[t] !== a &&
                    this.tweens.push(
                      new D({
                        name: t,
                        from: this.current[t],
                        to: a,
                        duration: e.duration,
                        delay: e.delay,
                        ease: e.ease,
                        autoplay: !1,
                      })
                    );
              this.play();
            }),
              (e.render = function (e) {
                var t,
                  a,
                  n = this.tweens.length,
                  i = !1;
                for (t = n; t--; )
                  (a = this.tweens[t]).context &&
                    (a.render(e), (this.current[a.name] = a.value), (i = !0));
                return i
                  ? void (this.update && this.update.call(this.context))
                  : this.destroy();
              }),
              (e.destroy = function () {
                if ((t.destroy.call(this), this.tweens)) {
                  var e;
                  for (e = this.tweens.length; e--; ) this.tweens[e].destroy();
                  (this.tweens = null), (this.current = null);
                }
              });
          }),
          Y = (t.config = {
            debug: !1,
            defaultUnit: "px",
            defaultAngle: "deg",
            keepInherited: !1,
            hideBackface: !1,
            perspective: "",
            fallback: !h.transition,
            agentTests: [],
          });
        (t.fallback = function (e) {
          if (!h.transition) return (Y.fallback = !0);
          Y.agentTests.push("(" + e + ")");
          var t = RegExp(Y.agentTests.join("|"), "i");
          Y.fallback = t.test(navigator.userAgent);
        }),
          t.fallback("6.0.[2-5] Safari"),
          (t.tween = function (e) {
            return new D(e);
          }),
          (t.delay = function (e, t, a) {
            return new F({ complete: t, duration: e, context: a });
          }),
          (e.fn.tram = function (e) {
            return t.call(null, this, e);
          });
        var H = e.style,
          W = e.css,
          j = { transform: h.transform && h.transform.css },
          X = {
            color: [V, m],
            background: [V, m, "background-color"],
            "outline-color": [V, m],
            "border-color": [V, m],
            "border-top-color": [V, m],
            "border-right-color": [V, m],
            "border-bottom-color": [V, m],
            "border-left-color": [V, m],
            "border-width": [B, g],
            "border-top-width": [B, g],
            "border-right-width": [B, g],
            "border-bottom-width": [B, g],
            "border-left-width": [B, g],
            "border-spacing": [B, g],
            "letter-spacing": [B, g],
            margin: [B, g],
            "margin-top": [B, g],
            "margin-right": [B, g],
            "margin-bottom": [B, g],
            "margin-left": [B, g],
            padding: [B, g],
            "padding-top": [B, g],
            "padding-right": [B, g],
            "padding-bottom": [B, g],
            "padding-left": [B, g],
            "outline-width": [B, g],
            opacity: [B, y],
            top: [B, b],
            right: [B, b],
            bottom: [B, b],
            left: [B, b],
            "font-size": [B, b],
            "text-indent": [B, b],
            "word-spacing": [B, b],
            width: [B, b],
            "min-width": [B, b],
            "max-width": [B, b],
            height: [B, b],
            "min-height": [B, b],
            "max-height": [B, b],
            "line-height": [B, v],
            "scroll-top": [x, y, "scrollTop"],
            "scroll-left": [x, y, "scrollLeft"],
          },
          z = {};
        h.transform &&
          ((X.transform = [P]),
          (z = {
            x: [b, "translateX"],
            y: [b, "translateY"],
            rotate: [O],
            rotateX: [O],
            rotateY: [O],
            scale: [y],
            scaleX: [y],
            scaleY: [y],
            skew: [O],
            skewX: [O],
            skewY: [O],
          })),
          h.transform &&
            h.backface &&
            ((z.z = [b, "translateZ"]),
            (z.rotateZ = [O]),
            (z.scaleZ = [y]),
            (z.perspective = [g]));
        var $ = /ms/,
          q = /s|\./;
        return (e.tram = t);
      })(window.jQuery);
    },
    5756: function (e, t, a) {
      "use strict";
      var n,
        i,
        l,
        d,
        o,
        c,
        s,
        r,
        f,
        u,
        p,
        E,
        T,
        I,
        y,
        m,
        g,
        b,
        O,
        v,
        R = window.$,
        L = a(5487) && R.tram;
      ((n = {}).VERSION = "1.6.0-Webflow"),
        (i = {}),
        (l = Array.prototype),
        (d = Object.prototype),
        (o = Function.prototype),
        l.push,
        (c = l.slice),
        l.concat,
        d.toString,
        (s = d.hasOwnProperty),
        (r = l.forEach),
        (f = l.map),
        l.reduce,
        l.reduceRight,
        (u = l.filter),
        l.every,
        (p = l.some),
        (E = l.indexOf),
        l.lastIndexOf,
        (T = Object.keys),
        o.bind,
        (I =
          n.each =
          n.forEach =
            function (e, t, a) {
              if (null == e) return e;
              if (r && e.forEach === r) e.forEach(t, a);
              else if (e.length === +e.length) {
                for (var l = 0, d = e.length; l < d; l++)
                  if (t.call(a, e[l], l, e) === i) return;
              } else
                for (var o = n.keys(e), l = 0, d = o.length; l < d; l++)
                  if (t.call(a, e[o[l]], o[l], e) === i) return;
              return e;
            }),
        (n.map = n.collect =
          function (e, t, a) {
            var n = [];
            return null == e
              ? n
              : f && e.map === f
              ? e.map(t, a)
              : (I(e, function (e, i, l) {
                  n.push(t.call(a, e, i, l));
                }),
                n);
          }),
        (n.find = n.detect =
          function (e, t, a) {
            var n;
            return (
              y(e, function (e, i, l) {
                if (t.call(a, e, i, l)) return (n = e), !0;
              }),
              n
            );
          }),
        (n.filter = n.select =
          function (e, t, a) {
            var n = [];
            return null == e
              ? n
              : u && e.filter === u
              ? e.filter(t, a)
              : (I(e, function (e, i, l) {
                  t.call(a, e, i, l) && n.push(e);
                }),
                n);
          }),
        (y =
          n.some =
          n.any =
            function (e, t, a) {
              t || (t = n.identity);
              var l = !1;
              return null == e
                ? l
                : p && e.some === p
                ? e.some(t, a)
                : (I(e, function (e, n, d) {
                    if (l || (l = t.call(a, e, n, d))) return i;
                  }),
                  !!l);
            }),
        (n.contains = n.include =
          function (e, t) {
            return (
              null != e &&
              (E && e.indexOf === E
                ? -1 != e.indexOf(t)
                : y(e, function (e) {
                    return e === t;
                  }))
            );
          }),
        (n.delay = function (e, t) {
          var a = c.call(arguments, 2);
          return setTimeout(function () {
            return e.apply(null, a);
          }, t);
        }),
        (n.defer = function (e) {
          return n.delay.apply(n, [e, 1].concat(c.call(arguments, 1)));
        }),
        (n.throttle = function (e) {
          var t, a, n;
          return function () {
            t ||
              ((t = !0),
              (a = arguments),
              (n = this),
              L.frame(function () {
                (t = !1), e.apply(n, a);
              }));
          };
        }),
        (n.debounce = function (e, t, a) {
          var i,
            l,
            d,
            o,
            c,
            s = function () {
              var r = n.now() - o;
              r < t
                ? (i = setTimeout(s, t - r))
                : ((i = null), a || ((c = e.apply(d, l)), (d = l = null)));
            };
          return function () {
            (d = this), (l = arguments), (o = n.now());
            var r = a && !i;
            return (
              i || (i = setTimeout(s, t)),
              r && ((c = e.apply(d, l)), (d = l = null)),
              c
            );
          };
        }),
        (n.defaults = function (e) {
          if (!n.isObject(e)) return e;
          for (var t = 1, a = arguments.length; t < a; t++) {
            var i = arguments[t];
            for (var l in i) void 0 === e[l] && (e[l] = i[l]);
          }
          return e;
        }),
        (n.keys = function (e) {
          if (!n.isObject(e)) return [];
          if (T) return T(e);
          var t = [];
          for (var a in e) n.has(e, a) && t.push(a);
          return t;
        }),
        (n.has = function (e, t) {
          return s.call(e, t);
        }),
        (n.isObject = function (e) {
          return e === Object(e);
        }),
        (n.now =
          Date.now ||
          function () {
            return new Date().getTime();
          }),
        (n.templateSettings = {
          evaluate: /<%([\s\S]+?)%>/g,
          interpolate: /<%=([\s\S]+?)%>/g,
          escape: /<%-([\s\S]+?)%>/g,
        }),
        (m = /(.)^/),
        (g = {
          "'": "'",
          "\\": "\\",
          "\r": "r",
          "\n": "n",
          "\u2028": "u2028",
          "\u2029": "u2029",
        }),
        (b = /\\|'|\r|\n|\u2028|\u2029/g),
        (O = function (e) {
          return "\\" + g[e];
        }),
        (v = /^\s*(\w|\$)+\s*$/),
        (n.template = function (e, t, a) {
          !t && a && (t = a);
          var i,
            l = RegExp(
              [
                ((t = n.defaults({}, t, n.templateSettings)).escape || m)
                  .source,
                (t.interpolate || m).source,
                (t.evaluate || m).source,
              ].join("|") + "|$",
              "g"
            ),
            d = 0,
            o = "__p+='";
          e.replace(l, function (t, a, n, i, l) {
            return (
              (o += e.slice(d, l).replace(b, O)),
              (d = l + t.length),
              a
                ? (o += "'+\n((__t=(" + a + "))==null?'':_.escape(__t))+\n'")
                : n
                ? (o += "'+\n((__t=(" + n + "))==null?'':__t)+\n'")
                : i && (o += "';\n" + i + "\n__p+='"),
              t
            );
          }),
            (o += "';\n");
          var c = t.variable;
          if (c) {
            if (!v.test(c))
              throw Error("variable is not a bare identifier: " + c);
          } else (o = "with(obj||{}){\n" + o + "}\n"), (c = "obj");
          o =
            "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" +
            o +
            "return __p;\n";
          try {
            i = Function(t.variable || "obj", "_", o);
          } catch (e) {
            throw ((e.source = o), e);
          }
          var s = function (e) {
            return i.call(this, e, n);
          };
          return (s.source = "function(" + c + "){\n" + o + "}"), s;
        }),
        (e.exports = n);
    },
    9461: function (e, t, a) {
      "use strict";
      var n = a(3949);
      n.define(
        "brand",
        (e.exports = function (e) {
          var t,
            a = {},
            i = document,
            l = e("html"),
            d = e("body"),
            o = window.location,
            c = /PhantomJS/i.test(navigator.userAgent),
            s =
              "fullscreenchange webkitfullscreenchange mozfullscreenchange msfullscreenchange";
          function r() {
            var a =
              i.fullScreen ||
              i.mozFullScreen ||
              i.webkitIsFullScreen ||
              i.msFullscreenElement ||
              !!i.webkitFullscreenElement;
            e(t).attr("style", a ? "display: none !important;" : "");
          }
          function f() {
            var e = d.children(".w-webflow-badge"),
              a = e.length && e.get(0) === t,
              i = n.env("editor");
            if (a) {
              i && e.remove();
              return;
            }
            e.length && e.remove(), i || d.append(t);
          }
          return (
            (a.ready = function () {
              var a,
                n,
                d,
                u = l.attr("data-wf-status"),
                p = l.attr("data-wf-domain") || "";
              /\.webflow\.io$/i.test(p) && o.hostname !== p && (u = !0),
                u &&
                  !c &&
                  ((t =
                    t ||
                    ((a = e('<a class="w-webflow-badge"></a>').attr(
                      "href",
                      "https://webflow.com?utm_campaign=brandjs"
                    )),
                    (n = e("<img>")
                      .attr(
                        "src",
                        "https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg"
                      )
                      .attr("alt", "")
                      .css({ marginRight: "4px", width: "26px" })),
                    (d = e("<img>")
                      .attr(
                        "src",
                        "https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg"
                      )
                      .attr("alt", "Made in Webflow")),
                    a.append(n, d),
                    a[0])),
                  f(),
                  setTimeout(f, 500),
                  e(i).off(s, r).on(s, r));
            }),
            a
          );
        })
      );
    },
    322: function (e, t, a) {
      "use strict";
      var n = a(3949);
      n.define(
        "edit",
        (e.exports = function (e, t, a) {
          if (
            ((a = a || {}),
            (n.env("test") || n.env("frame")) &&
              !a.fixture &&
              !(function () {
                try {
                  return !!(window.top.__Cypress__ || window.PLAYWRIGHT_TEST);
                } catch (e) {
                  return !1;
                }
              })())
          )
            return { exit: 1 };
          var i,
            l = e(window),
            d = e(document.documentElement),
            o = document.location,
            c = "hashchange",
            s =
              a.load ||
              function () {
                var t, a, n;
                (i = !0),
                  (window.WebflowEditor = !0),
                  l.off(c, f),
                  (t = function (t) {
                    var a;
                    e.ajax({
                      url: p("https://editor-api.webflow.com/api/editor/view"),
                      data: { siteId: d.attr("data-wf-site") },
                      xhrFields: { withCredentials: !0 },
                      dataType: "json",
                      crossDomain: !0,
                      success:
                        ((a = t),
                        function (t) {
                          var n, i, l;
                          if (!t)
                            return void console.error(
                              "Could not load editor data"
                            );
                          (t.thirdPartyCookiesSupported = a),
                            (i =
                              (n = t.scriptPath).indexOf("//") >= 0
                                ? n
                                : p("https://editor-api.webflow.com" + n)),
                            (l = function () {
                              window.WebflowEditor(t);
                            }),
                            e
                              .ajax({
                                type: "GET",
                                url: i,
                                dataType: "script",
                                cache: !0,
                              })
                              .then(l, u);
                        }),
                    });
                  }),
                  ((a = window.document.createElement("iframe")).src =
                    "https://webflow.com/site/third-party-cookie-check.html"),
                  (a.style.display = "none"),
                  (a.sandbox = "allow-scripts allow-same-origin"),
                  (n = function (e) {
                    "WF_third_party_cookies_unsupported" === e.data
                      ? (E(a, n), t(!1))
                      : "WF_third_party_cookies_supported" === e.data &&
                        (E(a, n), t(!0));
                  }),
                  (a.onerror = function () {
                    E(a, n), t(!1);
                  }),
                  window.addEventListener("message", n, !1),
                  window.document.body.appendChild(a);
              },
            r = !1;
          try {
            r =
              localStorage &&
              localStorage.getItem &&
              localStorage.getItem("WebflowEditor");
          } catch (e) {}
          function f() {
            !i && /\?edit/.test(o.hash) && s();
          }
          function u(e, t, a) {
            throw (console.error("Could not load editor script: " + t), a);
          }
          function p(e) {
            return e.replace(/([^:])\/\//g, "$1/");
          }
          function E(e, t) {
            window.removeEventListener("message", t, !1), e.remove();
          }
          return (
            /[?&](update)(?:[=&?]|$)/.test(o.search) || /\?update$/.test(o.href)
              ? (function () {
                  var e = document.documentElement,
                    t = e.getAttribute("data-wf-site"),
                    a = e.getAttribute("data-wf-page"),
                    n = e.getAttribute("data-wf-item-slug"),
                    i = e.getAttribute("data-wf-collection"),
                    l = e.getAttribute("data-wf-domain");
                  if (t && a) {
                    var d = "pageId=" + a;
                    (d += "&utm_source=legacy_editor"),
                      n &&
                        i &&
                        l &&
                        (d +=
                          "&domain=" +
                          encodeURIComponent(l) +
                          "&itemSlug=" +
                          encodeURIComponent(n) +
                          "&collectionId=" +
                          i),
                      (window.location.href =
                        "https://webflow.com/external/designer/" + t + "?" + d);
                  }
                })()
              : r
              ? s()
              : o.search
              ? (/[?&](edit)(?:[=&?]|$)/.test(o.search) ||
                  /\?edit$/.test(o.href)) &&
                s()
              : l.on(c, f).triggerHandler(c),
            {}
          );
        })
      );
    },
    2338: function (e, t, a) {
      "use strict";
      a(3949).define(
        "focus-visible",
        (e.exports = function () {
          return {
            ready: function () {
              if ("undefined" != typeof document)
                try {
                  document.querySelector(":focus-visible");
                } catch (e) {
                  !(function (e) {
                    var t = !0,
                      a = !1,
                      n = null,
                      i = {
                        text: !0,
                        search: !0,
                        url: !0,
                        tel: !0,
                        email: !0,
                        password: !0,
                        number: !0,
                        date: !0,
                        month: !0,
                        week: !0,
                        time: !0,
                        datetime: !0,
                        "datetime-local": !0,
                      };
                    function l(e) {
                      return (
                        !!e &&
                        e !== document &&
                        "HTML" !== e.nodeName &&
                        "BODY" !== e.nodeName &&
                        "classList" in e &&
                        "contains" in e.classList
                      );
                    }
                    function d(e) {
                      e.getAttribute("data-wf-focus-visible") ||
                        e.setAttribute("data-wf-focus-visible", "true");
                    }
                    function o() {
                      t = !1;
                    }
                    function c() {
                      document.addEventListener("mousemove", s),
                        document.addEventListener("mousedown", s),
                        document.addEventListener("mouseup", s),
                        document.addEventListener("pointermove", s),
                        document.addEventListener("pointerdown", s),
                        document.addEventListener("pointerup", s),
                        document.addEventListener("touchmove", s),
                        document.addEventListener("touchstart", s),
                        document.addEventListener("touchend", s);
                    }
                    function s(e) {
                      (e.target.nodeName &&
                        "html" === e.target.nodeName.toLowerCase()) ||
                        ((t = !1),
                        document.removeEventListener("mousemove", s),
                        document.removeEventListener("mousedown", s),
                        document.removeEventListener("mouseup", s),
                        document.removeEventListener("pointermove", s),
                        document.removeEventListener("pointerdown", s),
                        document.removeEventListener("pointerup", s),
                        document.removeEventListener("touchmove", s),
                        document.removeEventListener("touchstart", s),
                        document.removeEventListener("touchend", s));
                    }
                    document.addEventListener(
                      "keydown",
                      function (a) {
                        a.metaKey ||
                          a.altKey ||
                          a.ctrlKey ||
                          (l(e.activeElement) && d(e.activeElement), (t = !0));
                      },
                      !0
                    ),
                      document.addEventListener("mousedown", o, !0),
                      document.addEventListener("pointerdown", o, !0),
                      document.addEventListener("touchstart", o, !0),
                      document.addEventListener(
                        "visibilitychange",
                        function () {
                          "hidden" === document.visibilityState &&
                            (a && (t = !0), c());
                        },
                        !0
                      ),
                      c(),
                      e.addEventListener(
                        "focus",
                        function (e) {
                          if (l(e.target)) {
                            var a, n, o;
                            (t ||
                              ((n = (a = e.target).type),
                              ("INPUT" === (o = a.tagName) &&
                                i[n] &&
                                !a.readOnly) ||
                                ("TEXTAREA" === o && !a.readOnly) ||
                                a.isContentEditable ||
                                0)) &&
                              d(e.target);
                          }
                        },
                        !0
                      ),
                      e.addEventListener(
                        "blur",
                        function (e) {
                          if (
                            l(e.target) &&
                            e.target.hasAttribute("data-wf-focus-visible")
                          ) {
                            var t;
                            (a = !0),
                              window.clearTimeout(n),
                              (n = window.setTimeout(function () {
                                a = !1;
                              }, 100)),
                              (t = e.target).getAttribute(
                                "data-wf-focus-visible"
                              ) && t.removeAttribute("data-wf-focus-visible");
                          }
                        },
                        !0
                      );
                  })(document);
                }
            },
          };
        })
      );
    },
    8334: function (e, t, a) {
      "use strict";
      var n = a(3949);
      n.define(
        "focus",
        (e.exports = function () {
          var e = [],
            t = !1;
          function a(a) {
            t &&
              (a.preventDefault(),
              a.stopPropagation(),
              a.stopImmediatePropagation(),
              e.unshift(a));
          }
          function i(a) {
            var n, i;
            (i = (n = a.target).tagName),
              ((/^a$/i.test(i) && null != n.href) ||
                (/^(button|textarea)$/i.test(i) && !0 !== n.disabled) ||
                (/^input$/i.test(i) &&
                  /^(button|reset|submit|radio|checkbox)$/i.test(n.type) &&
                  !n.disabled) ||
                (!/^(button|input|textarea|select|a)$/i.test(i) &&
                  !Number.isNaN(Number.parseFloat(n.tabIndex))) ||
                /^audio$/i.test(i) ||
                (/^video$/i.test(i) && !0 === n.controls)) &&
                ((t = !0),
                setTimeout(() => {
                  for (t = !1, a.target.focus(); e.length > 0; ) {
                    var n = e.pop();
                    n.target.dispatchEvent(new MouseEvent(n.type, n));
                  }
                }, 0));
          }
          return {
            ready: function () {
              "undefined" != typeof document &&
                document.body.hasAttribute("data-wf-focus-within") &&
                n.env.safari &&
                (document.addEventListener("mousedown", i, !0),
                document.addEventListener("mouseup", a, !0),
                document.addEventListener("click", a, !0));
            },
          };
        })
      );
    },
    7199: function (e) {
      "use strict";
      var t = window.jQuery,
        a = {},
        n = [],
        i = ".w-ix",
        l = {
          reset: function (e, t) {
            t.__wf_intro = null;
          },
          intro: function (e, n) {
            n.__wf_intro ||
              ((n.__wf_intro = !0), t(n).triggerHandler(a.types.INTRO));
          },
          outro: function (e, n) {
            n.__wf_intro &&
              ((n.__wf_intro = null), t(n).triggerHandler(a.types.OUTRO));
          },
        };
      (a.triggers = {}),
        (a.types = { INTRO: "w-ix-intro" + i, OUTRO: "w-ix-outro" + i }),
        (a.init = function () {
          for (var e = n.length, i = 0; i < e; i++) {
            var d = n[i];
            d[0](0, d[1]);
          }
          (n = []), t.extend(a.triggers, l);
        }),
        (a.async = function () {
          for (var e in l) {
            var t = l[e];
            l.hasOwnProperty(e) &&
              (a.triggers[e] = function (e, a) {
                n.push([t, a]);
              });
          }
        }),
        a.async(),
        (e.exports = a);
    },
    5134: function (e, t, a) {
      "use strict";
      var n = a(7199);
      function i(e, t, a) {
        var n = document.createEvent("CustomEvent");
        n.initCustomEvent(t, !0, !0, a || null), e.dispatchEvent(n);
      }
      var l = window.jQuery,
        d = {},
        o = ".w-ix";
      (d.triggers = {}),
        (d.types = { INTRO: "w-ix-intro" + o, OUTRO: "w-ix-outro" + o }),
        l.extend(d.triggers, {
          reset: function (e, t) {
            n.triggers.reset(e, t);
          },
          intro: function (e, t) {
            n.triggers.intro(e, t), i(t, "COMPONENT_ACTIVE");
          },
          outro: function (e, t) {
            n.triggers.outro(e, t), i(t, "COMPONENT_INACTIVE");
          },
        }),
        (d.dispatchCustomEvent = i),
        (e.exports = d);
    },
    941: function (e, t, a) {
      "use strict";
      var n = a(3949),
        i = a(6011);
      i.setEnv(n.env),
        n.define(
          "ix2",
          (e.exports = function () {
            return i;
          })
        );
    },
    3949: function (e, t, a) {
      "use strict";
      var n,
        i,
        l = {},
        d = {},
        o = [],
        c = window.Webflow || [],
        s = window.jQuery,
        r = s(window),
        f = s(document),
        u = s.isFunction,
        p = (l._ = a(5756)),
        E = (l.tram = a(5487) && s.tram),
        T = !1,
        I = !1;
      function y(e) {
        l.env() &&
          (u(e.design) && r.on("__wf_design", e.design),
          u(e.preview) && r.on("__wf_preview", e.preview)),
          u(e.destroy) && r.on("__wf_destroy", e.destroy),
          e.ready &&
            u(e.ready) &&
            (function (e) {
              if (T) return e.ready();
              p.contains(o, e.ready) || o.push(e.ready);
            })(e);
      }
      function m(e) {
        var t;
        u(e.design) && r.off("__wf_design", e.design),
          u(e.preview) && r.off("__wf_preview", e.preview),
          u(e.destroy) && r.off("__wf_destroy", e.destroy),
          e.ready &&
            u(e.ready) &&
            ((t = e),
            (o = p.filter(o, function (e) {
              return e !== t.ready;
            })));
      }
      (E.config.hideBackface = !1),
        (E.config.keepInherited = !0),
        (l.define = function (e, t, a) {
          d[e] && m(d[e]);
          var n = (d[e] = t(s, p, a) || {});
          return y(n), n;
        }),
        (l.require = function (e) {
          return d[e];
        }),
        (l.push = function (e) {
          if (T) {
            u(e) && e();
            return;
          }
          c.push(e);
        }),
        (l.env = function (e) {
          var t = window.__wf_design,
            a = void 0 !== t;
          return e
            ? "design" === e
              ? a && t
              : "preview" === e
              ? a && !t
              : "slug" === e
              ? a && window.__wf_slug
              : "editor" === e
              ? window.WebflowEditor
              : "test" === e
              ? window.__wf_test
              : "frame" === e
              ? window !== window.top
              : void 0
            : a;
        });
      var g = navigator.userAgent.toLowerCase(),
        b = (l.env.touch =
          "ontouchstart" in window ||
          (window.DocumentTouch && document instanceof window.DocumentTouch)),
        O = (l.env.chrome =
          /chrome/.test(g) &&
          /Google/.test(navigator.vendor) &&
          parseInt(g.match(/chrome\/(\d+)\./)[1], 10)),
        v = (l.env.ios = /(ipod|iphone|ipad)/.test(g));
      (l.env.safari = /safari/.test(g) && !O && !v),
        b &&
          f.on("touchstart mousedown", function (e) {
            n = e.target;
          }),
        (l.validClick = b
          ? function (e) {
              return e === n || s.contains(e, n);
            }
          : function () {
              return !0;
            });
      var R = "resize.webflow orientationchange.webflow load.webflow",
        L = "scroll.webflow " + R;
      function _(e, t) {
        var a = [],
          n = {};
        return (
          (n.up = p.throttle(function (e) {
            p.each(a, function (t) {
              t(e);
            });
          })),
          e && t && e.on(t, n.up),
          (n.on = function (e) {
            "function" == typeof e && (p.contains(a, e) || a.push(e));
          }),
          (n.off = function (e) {
            if (!arguments.length) {
              a = [];
              return;
            }
            a = p.filter(a, function (t) {
              return t !== e;
            });
          }),
          n
        );
      }
      function N(e) {
        u(e) && e();
      }
      function A() {
        i && (i.reject(), r.off("load", i.resolve)),
          (i = new s.Deferred()),
          r.on("load", i.resolve);
      }
      (l.resize = _(r, R)),
        (l.scroll = _(r, L)),
        (l.redraw = _()),
        (l.location = function (e) {
          window.location = e;
        }),
        l.env() && (l.location = function () {}),
        (l.ready = function () {
          (T = !0),
            I ? ((I = !1), p.each(d, y)) : p.each(o, N),
            p.each(c, N),
            l.resize.up();
        }),
        (l.load = function (e) {
          i.then(e);
        }),
        (l.destroy = function (e) {
          (e = e || {}),
            (I = !0),
            r.triggerHandler("__wf_destroy"),
            null != e.domready && (T = e.domready),
            p.each(d, m),
            l.resize.off(),
            l.scroll.off(),
            l.redraw.off(),
            (o = []),
            (c = []),
            "pending" === i.state() && A();
        }),
        s(l.ready),
        A(),
        (e.exports = window.Webflow = l);
    },
    7624: function (e, t, a) {
      "use strict";
      var n = a(3949);
      n.define(
        "links",
        (e.exports = function (e, t) {
          var a,
            i,
            l,
            d = {},
            o = e(window),
            c = n.env(),
            s = window.location,
            r = document.createElement("a"),
            f = "w--current",
            u = /index\.(html|php)$/,
            p = /\/$/;
          function E() {
            var e = o.scrollTop(),
              a = o.height();
            t.each(i, function (t) {
              if (!t.link.attr("hreflang")) {
                var n = t.link,
                  i = t.sec,
                  l = i.offset().top,
                  d = i.outerHeight(),
                  o = 0.5 * a,
                  c = i.is(":visible") && l + d - o >= e && l + o <= e + a;
                t.active !== c && ((t.active = c), T(n, f, c));
              }
            });
          }
          function T(e, t, a) {
            var n = e.hasClass(t);
            (!a || !n) && (a || n) && (a ? e.addClass(t) : e.removeClass(t));
          }
          return (
            (d.ready =
              d.design =
              d.preview =
                function () {
                  (a = c && n.env("design")),
                    (l = n.env("slug") || s.pathname || ""),
                    n.scroll.off(E),
                    (i = []);
                  for (var t = document.links, d = 0; d < t.length; ++d)
                    !(function (t) {
                      if (!t.getAttribute("hreflang")) {
                        var n =
                          (a && t.getAttribute("href-disabled")) ||
                          t.getAttribute("href");
                        if (((r.href = n), !(n.indexOf(":") >= 0))) {
                          var d = e(t);
                          if (
                            r.hash.length > 1 &&
                            r.host + r.pathname === s.host + s.pathname
                          ) {
                            if (!/^#[a-zA-Z0-9\-\_]+$/.test(r.hash)) return;
                            var o = e(r.hash);
                            o.length && i.push({ link: d, sec: o, active: !1 });
                            return;
                          }
                          "#" !== n &&
                            "" !== n &&
                            T(
                              d,
                              f,
                              (!c && r.href === s.href) ||
                                n === l ||
                                (u.test(n) && p.test(l))
                            );
                        }
                      }
                    })(t[d]);
                  i.length && (n.scroll.on(E), E());
                }),
            d
          );
        })
      );
    },
    286: function (e, t, a) {
      "use strict";
      var n = a(3949);
      n.define(
        "scroll",
        (e.exports = function (e) {
          var t = {
              WF_CLICK_EMPTY: "click.wf-empty-link",
              WF_CLICK_SCROLL: "click.wf-scroll",
            },
            a = window.location,
            i = !(function () {
              try {
                return !!window.frameElement;
              } catch (e) {
                return !0;
              }
            })()
              ? window.history
              : null,
            l = e(window),
            d = e(document),
            o = e(document.body),
            c =
              window.requestAnimationFrame ||
              window.mozRequestAnimationFrame ||
              window.webkitRequestAnimationFrame ||
              function (e) {
                window.setTimeout(e, 15);
              },
            s = n.env("editor") ? ".w-editor-body" : "body",
            r =
              "header, " +
              s +
              " > .header, " +
              s +
              " > .w-nav:not([data-no-scroll])",
            f = 'a[href="#"]',
            u = 'a[href*="#"]:not(.w-tab-link):not(' + f + ")",
            p = document.createElement("style");
          p.appendChild(
            document.createTextNode(
              '.wf-force-outline-none[tabindex="-1"]:focus{outline:none;}'
            )
          );
          var E = /^#[a-zA-Z0-9][\w:.-]*$/;
          let T =
            "function" == typeof window.matchMedia &&
            window.matchMedia("(prefers-reduced-motion: reduce)");
          function I(e, t) {
            var a;
            switch (t) {
              case "add":
                (a = e.attr("tabindex"))
                  ? e.attr("data-wf-tabindex-swap", a)
                  : e.attr("tabindex", "-1");
                break;
              case "remove":
                (a = e.attr("data-wf-tabindex-swap"))
                  ? (e.attr("tabindex", a),
                    e.removeAttr("data-wf-tabindex-swap"))
                  : e.removeAttr("tabindex");
            }
            e.toggleClass("wf-force-outline-none", "add" === t);
          }
          function y(t) {
            var d = t.currentTarget;
            if (
              !(
                n.env("design") ||
                (window.$.mobile && /(?:^|\s)ui-link(?:$|\s)/.test(d.className))
              )
            ) {
              var s =
                E.test(d.hash) && d.host + d.pathname === a.host + a.pathname
                  ? d.hash
                  : "";
              if ("" !== s) {
                var f,
                  u = e(s);
                u.length &&
                  (t && (t.preventDefault(), t.stopPropagation()),
                  (f = s),
                  a.hash !== f &&
                    i &&
                    i.pushState &&
                    !(n.env.chrome && "file:" === a.protocol) &&
                    (i.state && i.state.hash) !== f &&
                    i.pushState({ hash: f }, "", f),
                  window.setTimeout(function () {
                    !(function (t, a) {
                      var n = l.scrollTop(),
                        i = (function (t) {
                          var a = e(r),
                            n =
                              "fixed" === a.css("position")
                                ? a.outerHeight()
                                : 0,
                            i = t.offset().top - n;
                          if ("mid" === t.data("scroll")) {
                            var d = l.height() - n,
                              o = t.outerHeight();
                            o < d && (i -= Math.round((d - o) / 2));
                          }
                          return i;
                        })(t);
                      if (n !== i) {
                        var d = (function (e, t, a) {
                            if (
                              "none" ===
                                document.body.getAttribute(
                                  "data-wf-scroll-motion"
                                ) ||
                              T.matches
                            )
                              return 0;
                            var n = 1;
                            return (
                              o.add(e).each(function (e, t) {
                                var a = parseFloat(
                                  t.getAttribute("data-scroll-time")
                                );
                                !isNaN(a) && a >= 0 && (n = a);
                              }),
                              (472.143 * Math.log(Math.abs(t - a) + 125) -
                                2e3) *
                                n
                            );
                          })(t, n, i),
                          s = Date.now(),
                          f = function () {
                            var e,
                              t,
                              l,
                              o,
                              r,
                              u = Date.now() - s;
                            window.scroll(
                              0,
                              ((e = n),
                              (t = i),
                              (l = u) > (o = d)
                                ? t
                                : e +
                                  (t - e) *
                                    ((r = l / o) < 0.5
                                      ? 4 * r * r * r
                                      : (r - 1) * (2 * r - 2) * (2 * r - 2) +
                                        1))
                            ),
                              u <= d ? c(f) : "function" == typeof a && a();
                          };
                        c(f);
                      }
                    })(u, function () {
                      I(u, "add"),
                        u.get(0).focus({ preventScroll: !0 }),
                        I(u, "remove");
                    });
                  }, 300 * !t));
              }
            }
          }
          return {
            ready: function () {
              var { WF_CLICK_EMPTY: e, WF_CLICK_SCROLL: a } = t;
              d.on(a, u, y),
                d.on(e, f, function (e) {
                  e.preventDefault();
                }),
                document.head.insertBefore(p, document.head.firstChild);
            },
          };
        })
      );
    },
    3695: function (e, t, a) {
      "use strict";
      a(3949).define(
        "touch",
        (e.exports = function (e) {
          var t = {},
            a = window.getSelection;
          function n(t) {
            var n,
              i,
              l = !1,
              d = !1,
              o = Math.min(Math.round(0.04 * window.innerWidth), 40);
            function c(e) {
              var t = e.touches;
              (t && t.length > 1) ||
                ((l = !0),
                t ? ((d = !0), (n = t[0].clientX)) : (n = e.clientX),
                (i = n));
            }
            function s(t) {
              if (l) {
                if (d && "mousemove" === t.type) {
                  t.preventDefault(), t.stopPropagation();
                  return;
                }
                var n,
                  c,
                  s,
                  r,
                  u = t.touches,
                  p = u ? u[0].clientX : t.clientX,
                  E = p - i;
                (i = p),
                  Math.abs(E) > o &&
                    a &&
                    "" === String(a()) &&
                    ((n = "swipe"),
                    (c = t),
                    (s = { direction: E > 0 ? "right" : "left" }),
                    (r = e.Event(n, { originalEvent: c })),
                    e(c.target).trigger(r, s),
                    f());
              }
            }
            function r(e) {
              if (l && ((l = !1), d && "mouseup" === e.type)) {
                e.preventDefault(), e.stopPropagation(), (d = !1);
                return;
              }
            }
            function f() {
              l = !1;
            }
            t.addEventListener("touchstart", c, !1),
              t.addEventListener("touchmove", s, !1),
              t.addEventListener("touchend", r, !1),
              t.addEventListener("touchcancel", f, !1),
              t.addEventListener("mousedown", c, !1),
              t.addEventListener("mousemove", s, !1),
              t.addEventListener("mouseup", r, !1),
              t.addEventListener("mouseout", f, !1),
              (this.destroy = function () {
                t.removeEventListener("touchstart", c, !1),
                  t.removeEventListener("touchmove", s, !1),
                  t.removeEventListener("touchend", r, !1),
                  t.removeEventListener("touchcancel", f, !1),
                  t.removeEventListener("mousedown", c, !1),
                  t.removeEventListener("mousemove", s, !1),
                  t.removeEventListener("mouseup", r, !1),
                  t.removeEventListener("mouseout", f, !1),
                  (t = null);
              });
          }
          return (
            (e.event.special.tap = {
              bindType: "click",
              delegateType: "click",
            }),
            (t.init = function (t) {
              return (t = "string" == typeof t ? e(t).get(0) : t)
                ? new n(t)
                : null;
            }),
            (t.instance = t.init(document)),
            t
          );
        })
      );
    },
    9858: function (e, t, a) {
      "use strict";
      var n = a(3949),
        i = a(5134);
      let l = {
        ARROW_LEFT: 37,
        ARROW_UP: 38,
        ARROW_RIGHT: 39,
        ARROW_DOWN: 40,
        ESCAPE: 27,
        SPACE: 32,
        ENTER: 13,
        HOME: 36,
        END: 35,
      };
      function d(e, t) {
        i.dispatchCustomEvent(e, "IX3_COMPONENT_STATE_CHANGE", {
          component: "dropdown",
          state: t,
        });
      }
      let o = /^#[a-zA-Z0-9\-_]+$/;
      n.define(
        "dropdown",
        (e.exports = function (e, t) {
          var a,
            c,
            s = t.debounce,
            r = {},
            f = n.env(),
            u = !1,
            p = n.env.touch,
            E = ".w-dropdown",
            T = "w--open",
            I = i.triggers,
            y = "focusout" + E,
            m = "keydown" + E,
            g = "mouseenter" + E,
            b = "mousemove" + E,
            O = "mouseleave" + E,
            v = (p ? "click" : "mouseup") + E,
            R = "w-close" + E,
            L = "setting" + E,
            _ = e(document);
          function N() {
            (a = f && n.env("design")), (c = _.find(E)).each(A);
          }
          function A(t, i) {
            var d,
              c,
              r,
              u,
              p,
              I,
              b,
              O,
              N,
              A,
              k = e(i),
              w = e.data(i, E);
            w ||
              (w = e.data(i, E, {
                open: !1,
                el: k,
                config: {},
                selectedIdx: -1,
              })),
              (w.toggle = w.el.children(".w-dropdown-toggle")),
              (w.list = w.el.children(".w-dropdown-list")),
              (w.links = w.list.find("a:not(.w-dropdown .w-dropdown a)")),
              (w.complete =
                ((d = w),
                function () {
                  d.list.removeClass(T),
                    d.toggle.removeClass(T),
                    d.manageZ && d.el.css("z-index", "");
                })),
              (w.mouseLeave =
                ((c = w),
                function () {
                  (c.hovering = !1), c.links.is(":focus") || C(c);
                })),
              (w.mouseUpOutside =
                ((r = w).mouseUpOutside && _.off(v, r.mouseUpOutside),
                s(function (t) {
                  if (r.open) {
                    var a = e(t.target);
                    if (!a.closest(".w-dropdown-toggle").length) {
                      var i = -1 === e.inArray(r.el[0], a.parents(E)),
                        l = n.env("editor");
                      if (i) {
                        if (l) {
                          var d =
                              1 === a.parents().length &&
                              1 === a.parents("svg").length,
                            o = a.parents(
                              ".w-editor-bem-EditorHoverControls"
                            ).length;
                          if (d || o) return;
                        }
                        C(r);
                      }
                    }
                  }
                }))),
              (w.mouseMoveOutside =
                ((u = w),
                s(function (t) {
                  if (u.open) {
                    var a = e(t.target);
                    if (-1 === e.inArray(u.el[0], a.parents(E))) {
                      var n = a.parents(
                          ".w-editor-bem-EditorHoverControls"
                        ).length,
                        i = a.parents(".w-editor-bem-RTToolbar").length,
                        l = e(".w-editor-bem-EditorOverlay"),
                        d =
                          l.find(".w-editor-edit-outline").length ||
                          l.find(".w-editor-bem-RTToolbar").length;
                      if (n || i || d) return;
                      (u.hovering = !1), C(u);
                    }
                  }
                }))),
              S(w);
            var G = w.toggle.attr("id"),
              B = w.list.attr("id");
            G || (G = "w-dropdown-toggle-" + t),
              B || (B = "w-dropdown-list-" + t),
              w.toggle.attr("id", G),
              w.toggle.attr("aria-controls", B),
              w.toggle.attr("aria-haspopup", "menu"),
              w.toggle.attr("aria-expanded", "false"),
              w.toggle
                .find(".w-icon-dropdown-toggle")
                .attr("aria-hidden", "true"),
              "BUTTON" !== w.toggle.prop("tagName") &&
                (w.toggle.attr("role", "button"),
                w.toggle.attr("tabindex") || w.toggle.attr("tabindex", "0")),
              w.list.attr("id", B),
              w.list.attr("aria-labelledby", G),
              w.links.each(function (e, t) {
                t.hasAttribute("tabindex") || t.setAttribute("tabindex", "0"),
                  o.test(t.hash) &&
                    t.addEventListener("click", C.bind(null, w));
              }),
              w.el.off(E),
              w.toggle.off(E),
              w.nav && w.nav.off(E);
            var V = h(w, !0);
            a &&
              w.el.on(
                L,
                ((p = w),
                function (e, t) {
                  (t = t || {}),
                    S(p),
                    !0 === t.open && M(p),
                    !1 === t.open && C(p, { immediate: !0 });
                })
              ),
              a ||
                (f && ((w.hovering = !1), C(w)),
                w.config.hover &&
                  w.toggle.on(
                    g,
                    ((I = w),
                    function () {
                      (I.hovering = !0), M(I);
                    })
                  ),
                w.el.on(R, V),
                w.el.on(
                  m,
                  ((b = w),
                  function (e) {
                    if (!a && b.open)
                      switch (
                        ((b.selectedIdx = b.links.index(
                          document.activeElement
                        )),
                        e.keyCode)
                      ) {
                        case l.HOME:
                          if (!b.open) return;
                          return (b.selectedIdx = 0), U(b), e.preventDefault();
                        case l.END:
                          if (!b.open) return;
                          return (
                            (b.selectedIdx = b.links.length - 1),
                            U(b),
                            e.preventDefault()
                          );
                        case l.ESCAPE:
                          return C(b), b.toggle.focus(), e.stopPropagation();
                        case l.ARROW_RIGHT:
                        case l.ARROW_DOWN:
                          return (
                            (b.selectedIdx = Math.min(
                              b.links.length - 1,
                              b.selectedIdx + 1
                            )),
                            U(b),
                            e.preventDefault()
                          );
                        case l.ARROW_LEFT:
                        case l.ARROW_UP:
                          return (
                            (b.selectedIdx = Math.max(-1, b.selectedIdx - 1)),
                            U(b),
                            e.preventDefault()
                          );
                      }
                  })
                ),
                w.el.on(
                  y,
                  ((O = w),
                  s(function (e) {
                    var { relatedTarget: t, target: a } = e,
                      n = O.el[0];
                    return (
                      n.contains(t) || n.contains(a) || C(O),
                      e.stopPropagation()
                    );
                  }))
                ),
                w.toggle.on(v, V),
                w.toggle.on(
                  m,
                  ((A = h((N = w), !0)),
                  function (e) {
                    if (!a) {
                      if (!N.open)
                        switch (e.keyCode) {
                          case l.ARROW_UP:
                          case l.ARROW_DOWN:
                            return e.stopPropagation();
                        }
                      switch (e.keyCode) {
                        case l.SPACE:
                        case l.ENTER:
                          return A(), e.stopPropagation(), e.preventDefault();
                      }
                    }
                  })
                ),
                (w.nav = w.el.closest(".w-nav")),
                w.nav.on(R, V));
          }
          function S(e) {
            var t = Number(e.el.css("z-index"));
            (e.manageZ = 900 === t || 901 === t),
              (e.config = {
                hover: "true" === e.el.attr("data-hover") && !p,
                delay: e.el.attr("data-delay"),
              });
          }
          function h(e, t) {
            return s(function (a) {
              if (e.open || (a && "w-close" === a.type))
                return C(e, { forceClose: t });
              M(e);
            });
          }
          function M(t) {
            if (!t.open) {
              (i = t.el[0]),
                c.each(function (t, a) {
                  var n = e(a);
                  n.is(i) || n.has(i).length || n.triggerHandler(R);
                }),
                (t.open = !0),
                t.list.addClass(T),
                t.toggle.addClass(T),
                t.toggle.attr("aria-expanded", "true"),
                I.intro(0, t.el[0]),
                d(t.el[0], "open"),
                n.redraw.up(),
                t.manageZ && t.el.css("z-index", 901);
              var i,
                l = n.env("editor");
              a || _.on(v, t.mouseUpOutside),
                t.hovering && !l && t.el.on(O, t.mouseLeave),
                t.hovering && l && _.on(b, t.mouseMoveOutside),
                window.clearTimeout(t.delayId);
            }
          }
          function C(e, { immediate: t, forceClose: a } = {}) {
            if (e.open && (!e.config.hover || !e.hovering || a)) {
              e.toggle.attr("aria-expanded", "false"), (e.open = !1);
              var n = e.config;
              if (
                (I.outro(0, e.el[0]),
                d(e.el[0], "close"),
                _.off(v, e.mouseUpOutside),
                _.off(b, e.mouseMoveOutside),
                e.el.off(O, e.mouseLeave),
                window.clearTimeout(e.delayId),
                !n.delay || t)
              )
                return e.complete();
              e.delayId = window.setTimeout(e.complete, n.delay);
            }
          }
          function U(e) {
            e.links[e.selectedIdx] && e.links[e.selectedIdx].focus();
          }
          return (
            (r.ready = N),
            (r.design = function () {
              u &&
                _.find(E).each(function (t, a) {
                  e(a).triggerHandler(R);
                }),
                (u = !1),
                N();
            }),
            (r.preview = function () {
              (u = !0), N();
            }),
            r
          );
        })
      );
    },
    6524: function (e, t) {
      "use strict";
      function a(e, t, a, n, i, l, d, o, c, s, r, f, u) {
        return function (p) {
          e(p);
          var E = p.form,
            T = {
              name: E.attr("data-name") || E.attr("name") || "Untitled Form",
              pageId: E.attr("data-wf-page-id") || "",
              elementId: E.attr("data-wf-element-id") || "",
              domain: f("html").attr("data-wf-domain") || null,
              collectionId: f("html").attr("data-wf-collection") || null,
              itemSlug: f("html").attr("data-wf-item-slug") || null,
              source: t.href,
              test: a.env(),
              fields: {},
              fileUploads: {},
              dolphin: /pass[\s-_]?(word|code)|secret|login|credentials/i.test(
                E.html()
              ),
              trackingCookies: n(),
            };
          let I = E.attr("data-wf-flow");
          I && (T.wfFlow = I);
          let y = E.attr("data-wf-locale-id");
          y && (T.localeId = y), i(p);
          var m = l(E, T.fields);
          return m
            ? d(m)
            : ((T.fileUploads = o(E)), c(p), s)
            ? void f
                .ajax({
                  url: u,
                  type: "POST",
                  data: T,
                  dataType: "json",
                  crossDomain: !0,
                })
                .done(function (e) {
                  e && 200 === e.code && (p.success = !0), r(p);
                })
                .fail(function () {
                  r(p);
                })
            : void r(p);
        };
      }
      Object.defineProperty(t, "default", {
        enumerable: !0,
        get: function () {
          return a;
        },
      });
    },
    7527: function (e, t, a) {
      "use strict";
      var n = a(3949);
      let i = (e, t, a, n) => {
        let i = document.createElement("div");
        t.appendChild(i),
          turnstile.render(i, {
            sitekey: e,
            callback: function (e) {
              a(e);
            },
            "error-callback": function () {
              n();
            },
          });
      };
      n.define(
        "forms",
        (e.exports = function (e, t) {
          let l,
            d = "TURNSTILE_LOADED";
          var o,
            c,
            s,
            r,
            f,
            u = {},
            p = e(document),
            E = window.location,
            T = window.XDomainRequest && !window.atob,
            I = ".w-form",
            y = /e(-)?mail/i,
            m = /^\S+@\S+$/,
            g = window.alert,
            b = n.env();
          let O = p.find("[data-turnstile-sitekey]").data("turnstile-sitekey");
          var v = /list-manage[1-9]?.com/i,
            R = t.debounce(function () {
              console.warn(
                "Oops! This page has improperly configured forms. Please contact your website administrator to fix this issue."
              );
            }, 100);
          function L(t, l) {
            var o = e(l),
              s = e.data(l, I);
            s || (s = e.data(l, I, { form: o })), _(s);
            var u = o.closest("div.w-form");
            (s.done = u.find("> .w-form-done")),
              (s.fail = u.find("> .w-form-fail")),
              (s.fileUploads = u.find(".w-file-upload")),
              s.fileUploads.each(function (t) {
                !(function (t, a) {
                  if (a.fileUploads && a.fileUploads[t]) {
                    var n,
                      i = e(a.fileUploads[t]),
                      l = i.find("> .w-file-upload-default"),
                      d = i.find("> .w-file-upload-uploading"),
                      o = i.find("> .w-file-upload-success"),
                      c = i.find("> .w-file-upload-error"),
                      s = l.find(".w-file-upload-input"),
                      r = l.find(".w-file-upload-label"),
                      u = r.children(),
                      p = c.find(".w-file-upload-error-msg"),
                      E = o.find(".w-file-upload-file"),
                      T = o.find(".w-file-remove-link"),
                      I = E.find(".w-file-upload-file-name"),
                      y = p.attr("data-w-size-error"),
                      m = p.attr("data-w-type-error"),
                      g = p.attr("data-w-generic-error");
                    if (
                      (b ||
                        r.on("click keydown", function (e) {
                          ("keydown" !== e.type ||
                            13 === e.which ||
                            32 === e.which) &&
                            (e.preventDefault(), s.click());
                        }),
                      r
                        .find(".w-icon-file-upload-icon")
                        .attr("aria-hidden", "true"),
                      T.find(".w-icon-file-upload-remove").attr(
                        "aria-hidden",
                        "true"
                      ),
                      b)
                    )
                      s.on("click", function (e) {
                        e.preventDefault();
                      }),
                        r.on("click", function (e) {
                          e.preventDefault();
                        }),
                        u.on("click", function (e) {
                          e.preventDefault();
                        });
                    else {
                      T.on("click keydown", function (e) {
                        if ("keydown" === e.type) {
                          if (13 !== e.which && 32 !== e.which) return;
                          e.preventDefault();
                        }
                        s.removeAttr("data-value"),
                          s.val(""),
                          I.html(""),
                          l.toggle(!0),
                          o.toggle(!1),
                          r.focus();
                      }),
                        s.on("change", function (i) {
                          var o, s, r;
                          (n =
                            i.target && i.target.files && i.target.files[0]) &&
                            (l.toggle(!1),
                            c.toggle(!1),
                            d.toggle(!0),
                            d.focus(),
                            I.text(n.name),
                            A() || N(a),
                            (a.fileUploads[t].uploading = !0),
                            (o = n),
                            (s = R),
                            (r = new URLSearchParams({
                              name: o.name,
                              size: o.size,
                            })),
                            e
                              .ajax({
                                type: "GET",
                                url: `${f}?${r}`,
                                crossDomain: !0,
                              })
                              .done(function (e) {
                                s(null, e);
                              })
                              .fail(function (e) {
                                s(e);
                              }));
                        });
                      var O = r.outerHeight();
                      s.height(O), s.width(1);
                    }
                  }
                  function v(e) {
                    var n = e.responseJSON && e.responseJSON.msg,
                      i = g;
                    "string" == typeof n &&
                    0 === n.indexOf("InvalidFileTypeError")
                      ? (i = m)
                      : "string" == typeof n &&
                        0 === n.indexOf("MaxFileSizeError") &&
                        (i = y),
                      p.text(i),
                      s.removeAttr("data-value"),
                      s.val(""),
                      d.toggle(!1),
                      l.toggle(!0),
                      c.toggle(!0),
                      c.focus(),
                      (a.fileUploads[t].uploading = !1),
                      A() || _(a);
                  }
                  function R(t, a) {
                    if (t) return v(t);
                    var i = a.fileName,
                      l = a.postData,
                      d = a.fileId,
                      o = a.s3Url;
                    s.attr("data-value", d),
                      (function (t, a, n, i, l) {
                        var d = new FormData();
                        for (var o in a) d.append(o, a[o]);
                        d.append("file", n, i),
                          e
                            .ajax({
                              type: "POST",
                              url: t,
                              data: d,
                              processData: !1,
                              contentType: !1,
                            })
                            .done(function () {
                              l(null);
                            })
                            .fail(function (e) {
                              l(e);
                            });
                      })(o, l, n, i, L);
                  }
                  function L(e) {
                    if (e) return v(e);
                    d.toggle(!1),
                      o.css("display", "inline-block"),
                      o.focus(),
                      (a.fileUploads[t].uploading = !1),
                      A() || _(a);
                  }
                  function A() {
                    return (
                      (a.fileUploads && a.fileUploads.toArray()) ||
                      []
                    ).some(function (e) {
                      return e.uploading;
                    });
                  }
                })(t, s);
              }),
              O &&
                !o.is("[data-wf-no-turnstile]") &&
                ((function (e) {
                  let t = e.btn || e.form.find(':input[type="submit"]');
                  e.btn || (e.btn = t),
                    t.prop("disabled", !0),
                    t.addClass("w-form-loading");
                })(s),
                A(o, !0),
                p.on(
                  "undefined" != typeof turnstile ? "ready" : d,
                  function () {
                    function e() {
                      i(
                        O,
                        l,
                        (e) => {
                          (s.turnstileToken = e), _(s), A(o, !1);
                        },
                        () => {
                          _(s), s.btn && s.btn.prop("disabled", !0), A(o, !1);
                        }
                      );
                    }
                    if ("undefined" != typeof IntersectionObserver) {
                      var t = new IntersectionObserver(
                        function (a) {
                          a[0].isIntersecting && (t.disconnect(), e());
                        },
                        { rootMargin: "200px" }
                      );
                      t.observe(l);
                    } else e();
                  }
                ));
            var T =
              s.form.attr("aria-label") || s.form.attr("data-name") || "Form";
            s.done.attr("aria-label") || s.form.attr("aria-label", T),
              s.done.attr("tabindex", "-1"),
              s.done.attr("role", "region"),
              s.done.attr("aria-label") ||
                s.done.attr("aria-label", T + " success"),
              s.fail.attr("tabindex", "-1"),
              s.fail.attr("role", "region"),
              s.fail.attr("aria-label") ||
                s.fail.attr("aria-label", T + " failure");
            var y = (s.action = o.attr("action"));
            if (
              ((s.handler = null),
              (s.redirect = o.attr("data-redirect")),
              v.test(y))
            ) {
              s.handler = U;
              return;
            }
            if (!y) {
              if (c) {
                s.handler = (0, a(6524).default)(
                  _,
                  E,
                  n,
                  C,
                  w,
                  S,
                  g,
                  h,
                  N,
                  c,
                  k,
                  e,
                  r
                );
                return;
              }
              R();
            }
          }
          function _(e) {
            var t = (e.btn = e.form.find(':input[type="submit"]'));
            (e.wait = e.btn.attr("data-wait") || null), (e.success = !1);
            let a = !!(O && !e.turnstileToken);
            t.prop("disabled", a),
              t.removeClass("w-form-loading"),
              e.label && t.val(e.label);
          }
          function N(e) {
            var t = e.btn,
              a = e.wait;
            t.prop("disabled", !0), a && ((e.label = t.val()), t.val(a));
          }
          function A(e, t) {
            let a = e.closest(".w-form");
            t ? a.addClass("w-form-loading") : a.removeClass("w-form-loading");
          }
          function S(t, a) {
            var n = null;
            return (
              (a = a || {}),
              t
                .find(
                  ':input:not([type="submit"]):not([type="file"]):not([type="button"])'
                )
                .each(function (i, l) {
                  var d,
                    o,
                    c,
                    s,
                    r,
                    f = e(l),
                    u = f.attr("type"),
                    p =
                      f.attr("data-name") ||
                      f.attr("name") ||
                      "Field " + (i + 1);
                  p = encodeURIComponent(p);
                  var E = f.val();
                  if ("checkbox" === u) E = f.is(":checked");
                  else if ("radio" === u) {
                    if (null === a[p] || "string" == typeof a[p]) return;
                    E =
                      t
                        .find('input[name="' + f.attr("name") + '"]:checked')
                        .val() || null;
                  }
                  "string" == typeof E && (E = e.trim(E)),
                    (a[p] = E),
                    (n =
                      n ||
                      ((d = f),
                      (o = u),
                      (c = p),
                      (s = E),
                      (r = null),
                      "password" === o
                        ? (r = "Passwords cannot be submitted.")
                        : d.attr("required")
                        ? s
                          ? y.test(d.attr("type")) &&
                            !m.test(s) &&
                            (r = "Please enter a valid email address for: " + c)
                          : (r = "Please fill out the required field: " + c)
                        : "g-recaptcha-response" !== c ||
                          s ||
                          (r = "Please confirm you're not a robot."),
                      r));
                }),
              n
            );
          }
          function h(t) {
            var a = {};
            return (
              t.find(':input[type="file"]').each(function (t, n) {
                var i = e(n),
                  l =
                    i.attr("data-name") || i.attr("name") || "File " + (t + 1),
                  d = i.attr("data-value");
                "string" == typeof d && (d = e.trim(d)), (a[l] = d);
              }),
              a
            );
          }
          u.ready =
            u.design =
            u.preview =
              function () {
                (function () {
                  if (O) {
                    let e = () => {
                      ((l = document.createElement("script")).src =
                        "https://challenges.cloudflare.com/turnstile/v0/api.js"),
                        document.head.appendChild(l),
                        (l.onload = () => {
                          p.trigger(d);
                        });
                    };
                    "function" == typeof requestIdleCallback
                      ? window.requestIdleCallback(e)
                      : setTimeout(e, 200);
                  }
                })(),
                  (r =
                    "https://webflow.com/api/v1/form/" +
                    (c = e("html").attr("data-wf-site"))),
                  T &&
                    r.indexOf("https://webflow.com") >= 0 &&
                    (r = r.replace(
                      "https://webflow.com",
                      "https://formdata.webflow.com"
                    )),
                  (f = `${r}/signFile`),
                  (o = e(I + " form")).length && o.each(L),
                  (!b || n.env("preview")) &&
                    !s &&
                    (function () {
                      (s = !0),
                        p.on("submit", I + " form", function (t) {
                          var a = e.data(this, I);
                          a.handler && ((a.evt = t), a.handler(a));
                        });
                      let t = ".w-checkbox-input",
                        a = ".w-radio-input",
                        n = "w--redirected-checked",
                        i = "w--redirected-focus",
                        l = "w--redirected-focus-visible",
                        d = [
                          ["checkbox", t],
                          ["radio", a],
                        ];
                      p.on(
                        "change",
                        I + ' form input[type="checkbox"]:not(' + t + ")",
                        (a) => {
                          e(a.target).siblings(t).toggleClass(n);
                        }
                      ),
                        p.on("change", I + ' form input[type="radio"]', (i) => {
                          e(`input[name="${i.target.name}"]:not(${t})`).map(
                            (t, i) => e(i).siblings(a).removeClass(n)
                          );
                          let l = e(i.target);
                          l.hasClass("w-radio-input") ||
                            l.siblings(a).addClass(n);
                        }),
                        d.forEach(([t, a]) => {
                          p.on(
                            "focus",
                            I + ` form input[type="${t}"]:not(` + a + ")",
                            (t) => {
                              e(t.target).siblings(a).addClass(i),
                                e(t.target)
                                  .filter(
                                    ":focus-visible, [data-wf-focus-visible]"
                                  )
                                  .siblings(a)
                                  .addClass(l);
                            }
                          ),
                            p.on(
                              "blur",
                              I + ` form input[type="${t}"]:not(` + a + ")",
                              (t) => {
                                e(t.target)
                                  .siblings(a)
                                  .removeClass(`${i} ${l}`);
                              }
                            );
                        });
                    })();
              };
          let M = { _mkto_trk: "marketo" };
          function C() {
            return document.cookie.split("; ").reduce(function (e, t) {
              let a = t.split("="),
                n = a[0];
              if (n in M) {
                let t = M[n],
                  i = a.slice(1).join("=");
                e[t] = i;
              }
              return e;
            }, {});
          }
          function U(a) {
            _(a);
            var n,
              i = a.form,
              l = {};
            if (/^https/.test(E.href) && !/^https/.test(a.action))
              return void i.attr("method", "post");
            w(a);
            var d = S(i, l);
            if (d) return g(d);
            N(a),
              t.each(l, function (e, t) {
                y.test(t) && (l.EMAIL = e),
                  /^((full[ _-]?)?name)$/i.test(t) && (n = e),
                  /^(first[ _-]?name)$/i.test(t) && (l.FNAME = e),
                  /^(last[ _-]?name)$/i.test(t) && (l.LNAME = e);
              }),
              n &&
                !l.FNAME &&
                ((l.FNAME = (n = n.split(" "))[0]),
                (l.LNAME = l.LNAME || n[1]));
            var o = a.action.replace("/post?", "/post-json?") + "&c=?",
              c = o.indexOf("u=") + 2;
            c = o.substring(c, o.indexOf("&", c));
            var s = o.indexOf("id=") + 3;
            (l["b_" + c + "_" + (s = o.substring(s, o.indexOf("&", s)))] = ""),
              e
                .ajax({ url: o, data: l, dataType: "jsonp" })
                .done(function (e) {
                  (a.success = "success" === e.result || /already/.test(e.msg)),
                    a.success || console.info("MailChimp error: " + e.msg),
                    k(a);
                })
                .fail(function () {
                  k(a);
                });
          }
          function k(e) {
            var t = e.form,
              a = e.redirect,
              i = e.success;
            if (i && a) return void n.location(a);
            e.done.toggle(i),
              e.fail.toggle(!i),
              i ? e.done.focus() : e.fail.focus(),
              t.toggle(!i),
              _(e);
          }
          function w(e) {
            e.evt && e.evt.preventDefault(), (e.evt = null);
          }
          return u;
        })
      );
    },
    1655: function (e, t, a) {
      "use strict";
      var n = a(3949),
        i = a(5134);
      let l = {
        ARROW_LEFT: 37,
        ARROW_UP: 38,
        ARROW_RIGHT: 39,
        ARROW_DOWN: 40,
        ESCAPE: 27,
        SPACE: 32,
        ENTER: 13,
        HOME: 36,
        END: 35,
      };
      function d(e, t) {
        i.dispatchCustomEvent(e, "IX3_COMPONENT_STATE_CHANGE", {
          component: "navbar",
          state: t,
        });
      }
      n.define(
        "navbar",
        (e.exports = function (e, t) {
          var a,
            o,
            c,
            s,
            r = {},
            f = e.tram,
            u = e(window),
            p = e(document),
            E = t.debounce,
            T = n.env(),
            I = ".w-nav",
            y = "w--open",
            m = "w--nav-dropdown-open",
            g = "w--nav-dropdown-toggle-open",
            b = "w--nav-dropdown-list-open",
            O = "w--nav-link-open",
            v = i.triggers,
            R = e();
          function L() {
            n.resize.off(_);
          }
          function _() {
            o.each(G);
          }
          function N(a, n) {
            var i,
              d,
              o,
              r,
              f,
              E = e(n),
              T = e.data(n, I);
            T ||
              (T = e.data(n, I, {
                open: !1,
                el: E,
                config: {},
                selectedIdx: -1,
              })),
              (T.menu = E.find(".w-nav-menu")),
              (T.links = T.menu.find(".w-nav-link")),
              (T.dropdowns = T.menu.find(".w-dropdown")),
              (T.dropdownToggle = T.menu.find(".w-dropdown-toggle")),
              (T.dropdownList = T.menu.find(".w-dropdown-list")),
              (T.button = E.find(".w-nav-button")),
              (T.container = E.find(".w-container")),
              (T.overlayContainerId = "w-nav-overlay-" + a),
              (T.outside =
                ((i = T).outside && p.off("click" + I, i.outside),
                function (t) {
                  var a = e(t.target);
                  (s && a.closest(".w-editor-bem-EditorOverlay").length) ||
                    w(i, a);
                }));
            var y = E.find(".w-nav-brand");
            y &&
              "/" === y.attr("href") &&
              null == y.attr("aria-label") &&
              y.attr("aria-label", "home"),
              T.button.attr("style", "-webkit-user-select: text;"),
              null == T.button.attr("aria-label") &&
                T.button.attr("aria-label", "menu"),
              T.button.attr("role", "button"),
              T.button.attr("tabindex", "0"),
              T.button.attr("aria-controls", T.overlayContainerId),
              T.button.attr("aria-haspopup", "menu"),
              T.button.attr("aria-expanded", "false"),
              T.el.off(I),
              T.button.off(I),
              T.menu.off(I),
              h(T),
              c
                ? (S(T),
                  T.el.on(
                    "setting" + I,
                    ((d = T),
                    function (e, a) {
                      a = a || {};
                      var n = u.width();
                      h(d),
                        !0 === a.open && P(d, !0),
                        !1 === a.open && F(d, !0),
                        d.open &&
                          t.defer(function () {
                            n !== u.width() && C(d);
                          });
                    })
                  ))
                : ((o = T).overlay ||
                    ((o.overlay = e(
                      '<div class="w-nav-overlay" data-wf-ignore />'
                    ).appendTo(o.el)),
                    o.overlay.attr("id", o.overlayContainerId),
                    (o.parent = o.menu.parent()),
                    F(o, !0)),
                  T.button.on("click" + I, U(T)),
                  T.menu.on("click" + I, "a", k(T)),
                  T.button.on(
                    "keydown" + I,
                    ((r = T),
                    function (e) {
                      switch (e.keyCode) {
                        case l.SPACE:
                        case l.ENTER:
                          return (
                            U(r)(), e.preventDefault(), e.stopPropagation()
                          );
                        case l.ESCAPE:
                          return F(r), e.preventDefault(), e.stopPropagation();
                        case l.ARROW_RIGHT:
                        case l.ARROW_DOWN:
                        case l.HOME:
                        case l.END:
                          if (!r.open)
                            return e.preventDefault(), e.stopPropagation();
                          return (
                            e.keyCode === l.END
                              ? (r.selectedIdx = r.links.length - 1)
                              : (r.selectedIdx = 0),
                            M(r),
                            e.preventDefault(),
                            e.stopPropagation()
                          );
                      }
                    })
                  ),
                  T.el.on(
                    "keydown" + I,
                    ((f = T),
                    function (e) {
                      if (f.open)
                        switch (
                          ((f.selectedIdx = f.links.index(
                            document.activeElement
                          )),
                          e.keyCode)
                        ) {
                          case l.HOME:
                          case l.END:
                            return (
                              e.keyCode === l.END
                                ? (f.selectedIdx = f.links.length - 1)
                                : (f.selectedIdx = 0),
                              M(f),
                              e.preventDefault(),
                              e.stopPropagation()
                            );
                          case l.ESCAPE:
                            return (
                              F(f),
                              f.button.focus(),
                              e.preventDefault(),
                              e.stopPropagation()
                            );
                          case l.ARROW_LEFT:
                          case l.ARROW_UP:
                            return (
                              (f.selectedIdx = Math.max(-1, f.selectedIdx - 1)),
                              M(f),
                              e.preventDefault(),
                              e.stopPropagation()
                            );
                          case l.ARROW_RIGHT:
                          case l.ARROW_DOWN:
                            return (
                              (f.selectedIdx = Math.min(
                                f.links.length - 1,
                                f.selectedIdx + 1
                              )),
                              M(f),
                              e.preventDefault(),
                              e.stopPropagation()
                            );
                        }
                    })
                  )),
              G(a, n);
          }
          function A(t, a) {
            var n = e.data(a, I);
            n && (S(n), e.removeData(a, I));
          }
          function S(e) {
            e.overlay && (F(e, !0), e.overlay.remove(), (e.overlay = null));
          }
          function h(e) {
            var a = {},
              n = e.config || {},
              i = (a.animation = e.el.attr("data-animation") || "default");
            (a.animOver = /^over/.test(i)),
              (a.animDirect = /left$/.test(i) ? -1 : 1),
              n.animation !== i && e.open && t.defer(C, e),
              (a.easing = e.el.attr("data-easing") || "ease"),
              (a.easing2 = e.el.attr("data-easing2") || "ease");
            var l = e.el.attr("data-duration");
            (a.duration = null != l ? Number(l) : 400),
              (a.docHeight = e.el.attr("data-doc-height")),
              (e.config = a);
          }
          function M(e) {
            if (e.links[e.selectedIdx]) {
              var t = e.links[e.selectedIdx];
              t.focus(), k(t);
            }
          }
          function C(e) {
            e.open && (F(e, !0), P(e, !0));
          }
          function U(e) {
            return E(function () {
              e.open ? F(e) : P(e);
            });
          }
          function k(t) {
            return function (a) {
              var i = e(this).attr("href");
              if (!n.validClick(a.currentTarget))
                return void a.preventDefault();
              i && 0 === i.indexOf("#") && t.open && F(t);
            };
          }
          (r.ready =
            r.design =
            r.preview =
              function () {
                (c = T && n.env("design")),
                  (s = n.env("editor")),
                  (a = e(document.body)),
                  (o = p.find(I)).length && (o.each(N), L(), n.resize.on(_));
              }),
            (r.destroy = function () {
              (R = e()), L(), o && o.length && o.each(A);
            });
          var w = E(function (e, t) {
            if (e.open) {
              var a = t.closest(".w-nav-menu");
              e.menu.is(a) || F(e);
            }
          });
          function G(t, a) {
            var n = e.data(a, I),
              i = (n.collapsed = "none" !== n.button.css("display"));
            if ((!n.open || i || c || F(n, !0), n.container.length)) {
              var l,
                d =
                  ("none" === (l = n.container.css(B)) && (l = ""),
                  function (t, a) {
                    (a = e(a)).css(B, ""), "none" === a.css(B) && a.css(B, l);
                  });
              n.links.each(d), n.dropdowns.each(d);
            }
            n.open && D(n);
          }
          var B = "max-width";
          function V(e, t) {
            t.setAttribute("data-nav-menu-open", "");
          }
          function x(e, t) {
            t.removeAttribute("data-nav-menu-open");
          }
          function P(e, t) {
            if (!e.open) {
              (e.open = !0),
                e.menu.each(V),
                e.links.addClass(O),
                e.dropdowns.addClass(m),
                e.dropdownToggle.addClass(g),
                e.dropdownList.addClass(b),
                e.button.addClass(y);
              var a = e.config;
              ("none" === a.animation ||
                !f.support.transform ||
                a.duration <= 0) &&
                (t = !0);
              var i = D(e),
                l = e.menu.outerHeight(!0),
                o = e.menu.outerWidth(!0),
                s = e.el.height(),
                r = e.el[0];
              if (
                (G(0, r),
                v.intro(0, r),
                d(r, "open"),
                n.redraw.up(),
                c || p.on("click" + I, e.outside),
                t)
              )
                return void E();
              var u = "transform " + a.duration + "ms " + a.easing;
              if (
                (e.overlay &&
                  ((R = e.menu.prev()), e.overlay.show().append(e.menu)),
                a.animOver)
              ) {
                f(e.menu)
                  .add(u)
                  .set({ x: a.animDirect * o, height: i })
                  .start({ x: 0 })
                  .then(E),
                  e.overlay && e.overlay.width(o);
                return;
              }
              f(e.menu)
                .add(u)
                .set({ y: -(s + l) })
                .start({ y: 0 })
                .then(E);
            }
            function E() {
              e.button.attr("aria-expanded", "true");
            }
          }
          function D(e) {
            var t = e.config,
              n = t.docHeight ? p.height() : a.height();
            return (
              t.animOver
                ? e.menu.height(n)
                : "fixed" !== e.el.css("position") &&
                  (n -= e.el.outerHeight(!0)),
              e.overlay && e.overlay.height(n),
              n
            );
          }
          function F(e, t) {
            if (e.open) {
              (e.open = !1), e.button.removeClass(y);
              var a = e.config;
              if (
                (("none" === a.animation ||
                  !f.support.transform ||
                  a.duration <= 0) &&
                  (t = !0),
                v.outro(0, e.el[0]),
                d(e.el[0], "close"),
                p.off("click" + I, e.outside),
                t)
              ) {
                f(e.menu).stop(), c();
                return;
              }
              var n = "transform " + a.duration + "ms " + a.easing2,
                i = e.menu.outerHeight(!0),
                l = e.menu.outerWidth(!0),
                o = e.el.height();
              if (a.animOver)
                return void f(e.menu)
                  .add(n)
                  .start({ x: l * a.animDirect })
                  .then(c);
              f(e.menu)
                .add(n)
                .start({ y: -(o + i) })
                .then(c);
            }
            function c() {
              e.menu.height(""),
                f(e.menu).set({ x: 0, y: 0 }),
                e.menu.each(x),
                e.links.removeClass(O),
                e.dropdowns.removeClass(m),
                e.dropdownToggle.removeClass(g),
                e.dropdownList.removeClass(b),
                e.overlay &&
                  e.overlay.children().length &&
                  (R.length
                    ? e.menu.insertAfter(R)
                    : e.menu.prependTo(e.parent),
                  e.overlay.attr("style", "").hide()),
                e.el.triggerHandler("w-close"),
                e.button.attr("aria-expanded", "false");
            }
          }
          return r;
        })
      );
    },
    9078: function (e, t, a) {
      "use strict";
      var n = a(3949),
        i = a(5134);
      n.define(
        "tabs",
        (e.exports = function (e) {
          var t,
            a,
            l = {},
            d = e.tram,
            o = e(document),
            c = n.env,
            s = c.safari,
            r = c(),
            f = "data-w-tab",
            u = ".w-tabs",
            p = "w--current",
            E = "w--tab-active",
            T = i.triggers,
            I = !1;
          function y() {
            (a = r && n.env("design")),
              (t = o.find(u)).length &&
                (t.each(b),
                n.env("preview") && !I && t.each(g),
                m(),
                n.redraw.on(l.redraw));
          }
          function m() {
            n.redraw.off(l.redraw);
          }
          function g(t, a) {
            var n = e.data(a, u);
            n &&
              (n.links && n.links.each(T.reset),
              n.panes && n.panes.each(T.reset));
          }
          function b(t, n) {
            var i = u.substr(1) + "-" + t,
              l = e(n),
              d = e.data(n, u);
            if (
              (d || (d = e.data(n, u, { el: l, config: {} })),
              (d.current = null),
              (d.tabIdentifier = i + "-" + f),
              (d.paneIdentifier = i + "-data-w-pane"),
              (d.menu = l.children(".w-tab-menu")),
              (d.links = d.menu.children(".w-tab-link")),
              (d.content = l.children(".w-tab-content")),
              (d.panes = d.content.children(".w-tab-pane")),
              d.el.off(u),
              d.links.off(u),
              d.menu.attr("role", "tablist"),
              d.links.attr("tabindex", "-1"),
              ((c = {}).easing = (o = d).el.attr("data-easing") || "ease"),
              (s = c.intro =
                (s = parseInt(o.el.attr("data-duration-in"), 10)) == s ? s : 0),
              (r = c.outro =
                (r = parseInt(o.el.attr("data-duration-out"), 10)) == r
                  ? r
                  : 0),
              (c.immediate = !s && !r),
              (o.config = c),
              !a)
            ) {
              d.links.on(
                "click" + u,
                ((E = d),
                function (e) {
                  e.preventDefault();
                  var t = e.currentTarget.getAttribute(f);
                  t && O(E, { tab: t });
                })
              ),
                d.links.on(
                  "keydown" + u,
                  ((T = d),
                  function (e) {
                    var t,
                      a =
                        ((t = T.current),
                        Array.prototype.findIndex.call(
                          T.links,
                          (e) => e.getAttribute(f) === t,
                          null
                        )),
                      n = e.key,
                      i = {
                        ArrowLeft: a - 1,
                        ArrowUp: a - 1,
                        ArrowRight: a + 1,
                        ArrowDown: a + 1,
                        End: T.links.length - 1,
                        Home: 0,
                      };
                    if (n in i) {
                      e.preventDefault();
                      var l = i[n];
                      -1 === l && (l = T.links.length - 1),
                        l === T.links.length && (l = 0);
                      var d = T.links[l].getAttribute(f);
                      d && O(T, { tab: d });
                    }
                  })
                );
              var o,
                c,
                s,
                r,
                E,
                T,
                I = d.links.filter("." + p).attr(f);
              I && O(d, { tab: I, immediate: !0 });
            }
          }
          function O(t, a) {
            a = a || {};
            var i,
              l = t.config,
              o = l.easing,
              c = a.tab;
            if (c !== t.current) {
              (t.current = c),
                t.links.each(function (n, d) {
                  var o = e(d);
                  if (a.immediate || l.immediate) {
                    var s = t.panes[n];
                    d.id || (d.id = t.tabIdentifier + "-" + n),
                      s.id || (s.id = t.paneIdentifier + "-" + n),
                      (d.href = "#" + s.id),
                      d.setAttribute("role", "tab"),
                      d.setAttribute("aria-controls", s.id),
                      d.setAttribute("aria-selected", "false"),
                      s.setAttribute("role", "tabpanel"),
                      s.setAttribute("aria-labelledby", d.id);
                  }
                  d.getAttribute(f) === c
                    ? ((i = d),
                      o
                        .addClass(p)
                        .removeAttr("tabindex")
                        .attr({ "aria-selected": "true" })
                        .each(T.intro))
                    : o.hasClass(p) &&
                      o
                        .removeClass(p)
                        .attr({ tabindex: "-1", "aria-selected": "false" })
                        .each(T.outro);
                });
              var r = [],
                u = [];
              t.panes.each(function (t, a) {
                var n = e(a);
                a.getAttribute(f) === c
                  ? r.push(a)
                  : n.hasClass(E) && u.push(a);
              });
              var y = e(r),
                m = e(u);
              if (a.immediate || l.immediate) {
                y.addClass(E).each(T.intro),
                  m.removeClass(E),
                  I || n.redraw.up();
                return;
              }
              var g = window.scrollX,
                b = window.scrollY;
              i.focus(),
                window.scrollTo(g, b),
                m.length && l.outro
                  ? (m.each(T.outro),
                    d(m)
                      .add("opacity " + l.outro + "ms " + o, { fallback: s })
                      .start({ opacity: 0 })
                      .then(() => v(l, m, y)))
                  : v(l, m, y);
            }
          }
          function v(e, t, a) {
            if (
              (t
                .removeClass(E)
                .css({
                  opacity: "",
                  transition: "",
                  transform: "",
                  width: "",
                  height: "",
                }),
              a.addClass(E).each(T.intro),
              n.redraw.up(),
              !e.intro)
            )
              return d(a).set({ opacity: 1 });
            d(a)
              .set({ opacity: 0 })
              .redraw()
              .add("opacity " + e.intro + "ms " + e.easing, { fallback: s })
              .start({ opacity: 1 });
          }
          return (
            (l.ready = l.design = l.preview = y),
            (l.redraw = function () {
              (I = !0), y(), (I = !1);
            }),
            (l.destroy = function () {
              (t = o.find(u)).length && (t.each(g), m());
            }),
            l
          );
        })
      );
    },
    3946: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        actionListPlaybackChanged: function () {
          return W;
        },
        animationFrameChanged: function () {
          return P;
        },
        clearRequested: function () {
          return G;
        },
        elementStateChanged: function () {
          return H;
        },
        eventListenerAdded: function () {
          return B;
        },
        eventStateChanged: function () {
          return x;
        },
        instanceAdded: function () {
          return F;
        },
        instanceRemoved: function () {
          return Y;
        },
        instanceStarted: function () {
          return Q;
        },
        mediaQueriesDefined: function () {
          return X;
        },
        parameterChanged: function () {
          return D;
        },
        playbackRequested: function () {
          return k;
        },
        previewRequested: function () {
          return U;
        },
        rawDataImported: function () {
          return S;
        },
        sessionInitialized: function () {
          return h;
        },
        sessionStarted: function () {
          return M;
        },
        sessionStopped: function () {
          return C;
        },
        stopRequested: function () {
          return w;
        },
        testFrameRendered: function () {
          return V;
        },
        viewportWidthChanged: function () {
          return j;
        },
      };
      for (var i in n)
        Object.defineProperty(t, i, { enumerable: !0, get: n[i] });
      let l = a(7087),
        d = a(9468),
        {
          IX2_RAW_DATA_IMPORTED: o,
          IX2_SESSION_INITIALIZED: c,
          IX2_SESSION_STARTED: s,
          IX2_SESSION_STOPPED: r,
          IX2_PREVIEW_REQUESTED: f,
          IX2_PLAYBACK_REQUESTED: u,
          IX2_STOP_REQUESTED: p,
          IX2_CLEAR_REQUESTED: E,
          IX2_EVENT_LISTENER_ADDED: T,
          IX2_TEST_FRAME_RENDERED: I,
          IX2_EVENT_STATE_CHANGED: y,
          IX2_ANIMATION_FRAME_CHANGED: m,
          IX2_PARAMETER_CHANGED: g,
          IX2_INSTANCE_ADDED: b,
          IX2_INSTANCE_STARTED: O,
          IX2_INSTANCE_REMOVED: v,
          IX2_ELEMENT_STATE_CHANGED: R,
          IX2_ACTION_LIST_PLAYBACK_CHANGED: L,
          IX2_VIEWPORT_WIDTH_CHANGED: _,
          IX2_MEDIA_QUERIES_DEFINED: N,
        } = l.IX2EngineActionTypes,
        { reifyState: A } = d.IX2VanillaUtils,
        S = (e) => ({ type: o, payload: { ...A(e) } }),
        h = ({ hasBoundaryNodes: e, reducedMotion: t }) => ({
          type: c,
          payload: { hasBoundaryNodes: e, reducedMotion: t },
        }),
        M = () => ({ type: s }),
        C = () => ({ type: r }),
        U = ({ rawData: e, defer: t }) => ({
          type: f,
          payload: { defer: t, rawData: e },
        }),
        k = ({
          actionTypeId: e = l.ActionTypeConsts.GENERAL_START_ACTION,
          actionListId: t,
          actionItemId: a,
          eventId: n,
          allowEvents: i,
          immediate: d,
          testManual: o,
          verbose: c,
          rawData: s,
        }) => ({
          type: u,
          payload: {
            actionTypeId: e,
            actionListId: t,
            actionItemId: a,
            testManual: o,
            eventId: n,
            allowEvents: i,
            immediate: d,
            verbose: c,
            rawData: s,
          },
        }),
        w = (e) => ({ type: p, payload: { actionListId: e } }),
        G = () => ({ type: E }),
        B = (e, t) => ({ type: T, payload: { target: e, listenerParams: t } }),
        V = (e = 1) => ({ type: I, payload: { step: e } }),
        x = (e, t) => ({ type: y, payload: { stateKey: e, newState: t } }),
        P = (e, t) => ({ type: m, payload: { now: e, parameters: t } }),
        D = (e, t) => ({ type: g, payload: { key: e, value: t } }),
        F = (e) => ({ type: b, payload: { ...e } }),
        Q = (e, t) => ({ type: O, payload: { instanceId: e, time: t } }),
        Y = (e) => ({ type: v, payload: { instanceId: e } }),
        H = (e, t, a, n) => ({
          type: R,
          payload: { elementId: e, actionTypeId: t, current: a, actionItem: n },
        }),
        W = ({ actionListId: e, isPlaying: t }) => ({
          type: L,
          payload: { actionListId: e, isPlaying: t },
        }),
        j = ({ width: e, mediaQueries: t }) => ({
          type: _,
          payload: { width: e, mediaQueries: t },
        }),
        X = () => ({ type: N });
    },
    6011: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n,
        i = {
          actions: function () {
            return s;
          },
          destroy: function () {
            return E;
          },
          init: function () {
            return p;
          },
          setEnv: function () {
            return u;
          },
          store: function () {
            return f;
          },
        };
      for (var l in i)
        Object.defineProperty(t, l, { enumerable: !0, get: i[l] });
      let d = a(9516),
        o = (n = a(7243)) && n.__esModule ? n : { default: n },
        c = a(1970),
        s = (function (e, t) {
          if (e && e.__esModule) return e;
          if (null === e || ("object" != typeof e && "function" != typeof e))
            return { default: e };
          var a = r(t);
          if (a && a.has(e)) return a.get(e);
          var n = { __proto__: null },
            i = Object.defineProperty && Object.getOwnPropertyDescriptor;
          for (var l in e)
            if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
              var d = i ? Object.getOwnPropertyDescriptor(e, l) : null;
              d && (d.get || d.set)
                ? Object.defineProperty(n, l, d)
                : (n[l] = e[l]);
            }
          return (n.default = e), a && a.set(e, n), n;
        })(a(3946));
      function r(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          a = new WeakMap();
        return (r = function (e) {
          return e ? a : t;
        })(e);
      }
      let f = (0, d.createStore)(o.default);
      function u(e) {
        e() && (0, c.observeRequests)(f);
      }
      function p(e) {
        E(), (0, c.startEngine)({ store: f, rawData: e, allowEvents: !0 });
      }
      function E() {
        (0, c.stopEngine)(f);
      }
    },
    5012: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        elementContains: function () {
          return g;
        },
        getChildElements: function () {
          return O;
        },
        getClosestElement: function () {
          return R;
        },
        getProperty: function () {
          return E;
        },
        getQuerySelector: function () {
          return I;
        },
        getRefType: function () {
          return L;
        },
        getSiblingElements: function () {
          return v;
        },
        getStyle: function () {
          return p;
        },
        getValidDocument: function () {
          return y;
        },
        isSiblingNode: function () {
          return b;
        },
        matchSelector: function () {
          return T;
        },
        queryDocument: function () {
          return m;
        },
        setStyle: function () {
          return u;
        },
      };
      for (var i in n)
        Object.defineProperty(t, i, { enumerable: !0, get: n[i] });
      let l = a(9468),
        d = a(7087),
        { ELEMENT_MATCHES: o } = l.IX2BrowserSupport,
        {
          IX2_ID_DELIMITER: c,
          HTML_ELEMENT: s,
          PLAIN_OBJECT: r,
          WF_PAGE: f,
        } = d.IX2EngineConstants;
      function u(e, t, a) {
        e.style[t] = a;
      }
      function p(e, t) {
        return t.startsWith("--")
          ? window
              .getComputedStyle(document.documentElement)
              .getPropertyValue(t)
          : e.style instanceof CSSStyleDeclaration
          ? e.style[t]
          : void 0;
      }
      function E(e, t) {
        return e[t];
      }
      function T(e) {
        return (t) => t[o](e);
      }
      function I({ id: e, selector: t }) {
        if (e) {
          let t = e;
          if (-1 !== e.indexOf(c)) {
            let a = e.split(c),
              n = a[0];
            if (((t = a[1]), n !== document.documentElement.getAttribute(f)))
              return null;
          }
          return `[data-w-id="${t}"], [data-w-id^="${t}_instance"]`;
        }
        return t;
      }
      function y(e) {
        return null == e || e === document.documentElement.getAttribute(f)
          ? document
          : null;
      }
      function m(e, t) {
        return Array.prototype.slice.call(
          document.querySelectorAll(t ? e + " " + t : e)
        );
      }
      function g(e, t) {
        return e.contains(t);
      }
      function b(e, t) {
        return e !== t && e.parentNode === t.parentNode;
      }
      function O(e) {
        let t = [];
        for (let a = 0, { length: n } = e || []; a < n; a++) {
          let { children: n } = e[a],
            { length: i } = n;
          if (i) for (let e = 0; e < i; e++) t.push(n[e]);
        }
        return t;
      }
      function v(e = []) {
        let t = [],
          a = [];
        for (let n = 0, { length: i } = e; n < i; n++) {
          let { parentNode: i } = e[n];
          if (!i || !i.children || !i.children.length || -1 !== a.indexOf(i))
            continue;
          a.push(i);
          let l = i.firstElementChild;
          for (; null != l; )
            -1 === e.indexOf(l) && t.push(l), (l = l.nextElementSibling);
        }
        return t;
      }
      let R = Element.prototype.closest
        ? (e, t) => (document.documentElement.contains(e) ? e.closest(t) : null)
        : (e, t) => {
            if (!document.documentElement.contains(e)) return null;
            let a = e;
            do {
              if (a[o] && a[o](t)) return a;
              a = a.parentNode;
            } while (null != a);
            return null;
          };
      function L(e) {
        return null != e && "object" == typeof e
          ? e instanceof Element
            ? s
            : r
          : null;
      }
    },
    1970: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        observeRequests: function () {
          return K;
        },
        startActionGroup: function () {
          return eE;
        },
        startEngine: function () {
          return en;
        },
        stopActionGroup: function () {
          return ep;
        },
        stopAllActionGroups: function () {
          return eu;
        },
        stopEngine: function () {
          return ei;
        },
      };
      for (var i in n)
        Object.defineProperty(t, i, { enumerable: !0, get: n[i] });
      let l = m(a(9777)),
        d = m(a(4738)),
        o = m(a(4659)),
        c = m(a(3452)),
        s = m(a(6633)),
        r = m(a(3729)),
        f = m(a(2397)),
        u = m(a(5082)),
        p = a(7087),
        E = a(9468),
        T = a(3946),
        I = (function (e, t) {
          if (e && e.__esModule) return e;
          if (null === e || ("object" != typeof e && "function" != typeof e))
            return { default: e };
          var a = g(t);
          if (a && a.has(e)) return a.get(e);
          var n = { __proto__: null },
            i = Object.defineProperty && Object.getOwnPropertyDescriptor;
          for (var l in e)
            if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
              var d = i ? Object.getOwnPropertyDescriptor(e, l) : null;
              d && (d.get || d.set)
                ? Object.defineProperty(n, l, d)
                : (n[l] = e[l]);
            }
          return (n.default = e), a && a.set(e, n), n;
        })(a(5012)),
        y = m(a(8955));
      function m(e) {
        return e && e.__esModule ? e : { default: e };
      }
      function g(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          a = new WeakMap();
        return (g = function (e) {
          return e ? a : t;
        })(e);
      }
      let b = Object.keys(p.QuickEffectIds),
        O = (e) => b.includes(e),
        {
          COLON_DELIMITER: v,
          BOUNDARY_SELECTOR: R,
          HTML_ELEMENT: L,
          RENDER_GENERAL: _,
          W_MOD_IX: N,
        } = p.IX2EngineConstants,
        {
          getAffectedElements: A,
          getElementId: S,
          getDestinationValues: h,
          observeStore: M,
          getInstanceId: C,
          renderHTMLElement: U,
          clearAllStyles: k,
          getMaxDurationItemIndex: w,
          getComputedStyle: G,
          getInstanceOrigin: B,
          reduceListToGroup: V,
          shouldNamespaceEventParameter: x,
          getNamespacedParameterId: P,
          shouldAllowMediaQuery: D,
          cleanupHTMLElement: F,
          clearObjectCache: Q,
          stringifyTarget: Y,
          mediaQueriesEqual: H,
          shallowEqual: W,
        } = E.IX2VanillaUtils,
        {
          isPluginType: j,
          createPluginInstance: X,
          getPluginDuration: z,
        } = E.IX2VanillaPlugins,
        $ = navigator.userAgent,
        q = $.match(/iPad/i) || $.match(/iPhone/);
      function K(e) {
        M({ store: e, select: ({ ixRequest: e }) => e.preview, onChange: Z }),
          M({
            store: e,
            select: ({ ixRequest: e }) => e.playback,
            onChange: ee,
          }),
          M({ store: e, select: ({ ixRequest: e }) => e.stop, onChange: et }),
          M({ store: e, select: ({ ixRequest: e }) => e.clear, onChange: ea });
      }
      function Z({ rawData: e, defer: t }, a) {
        let n = () => {
          en({ store: a, rawData: e, allowEvents: !0 }), J();
        };
        t ? setTimeout(n, 0) : n();
      }
      function J() {
        document.dispatchEvent(new CustomEvent("IX2_PAGE_UPDATE"));
      }
      function ee(e, t) {
        let {
            actionTypeId: a,
            actionListId: n,
            actionItemId: i,
            eventId: l,
            allowEvents: d,
            immediate: o,
            testManual: c,
            verbose: s = !0,
          } = e,
          { rawData: r } = e;
        if (n && i && r && o) {
          let e = r.actionLists[n];
          e && (r = V({ actionList: e, actionItemId: i, rawData: r }));
        }
        if (
          (en({ store: t, rawData: r, allowEvents: d, testManual: c }),
          (n && a === p.ActionTypeConsts.GENERAL_START_ACTION) || O(a))
        ) {
          ep({ store: t, actionListId: n }),
            ef({ store: t, actionListId: n, eventId: l });
          let e = eE({
            store: t,
            eventId: l,
            actionListId: n,
            immediate: o,
            verbose: s,
          });
          s &&
            e &&
            t.dispatch(
              (0, T.actionListPlaybackChanged)({
                actionListId: n,
                isPlaying: !o,
              })
            );
        }
      }
      function et({ actionListId: e }, t) {
        e ? ep({ store: t, actionListId: e }) : eu({ store: t }), ei(t);
      }
      function ea(e, t) {
        ei(t), k({ store: t, elementApi: I });
      }
      function en({ store: e, rawData: t, allowEvents: a, testManual: n }) {
        let { ixSession: i } = e.getState();
        if ((t && e.dispatch((0, T.rawDataImported)(t)), !i.active)) {
          (e.dispatch(
            (0, T.sessionInitialized)({
              hasBoundaryNodes: !!document.querySelector(R),
              reducedMotion:
                document.body.hasAttribute("data-wf-ix-vacation") &&
                window.matchMedia("(prefers-reduced-motion)").matches,
            })
          ),
          a) &&
            ((function (e) {
              let { ixData: t } = e.getState(),
                { eventTypeMap: a } = t;
              eo(e),
                (0, f.default)(a, (t, a) => {
                  let n = y.default[a];
                  if (!n)
                    return void console.warn(
                      `IX2 event type not configured: ${a}`
                    );
                  !(function ({ logic: e, store: t, events: a }) {
                    !(function (e) {
                      if (!q) return;
                      let t = {},
                        a = "";
                      for (let n in e) {
                        let { eventTypeId: i, target: l } = e[n],
                          d = I.getQuerySelector(l);
                        t[d] ||
                          ((i === p.EventTypeConsts.MOUSE_CLICK ||
                            i === p.EventTypeConsts.MOUSE_SECOND_CLICK) &&
                            ((t[d] = !0),
                            (a +=
                              d +
                              "{cursor: pointer;touch-action: manipulation;}")));
                      }
                      if (a) {
                        let e = document.createElement("style");
                        (e.textContent = a), document.body.appendChild(e);
                      }
                    })(a);
                    let { types: n, handler: i } = e,
                      { ixData: c } = t.getState(),
                      { actionLists: s } = c,
                      r = ec(a, er);
                    if (!(0, o.default)(r)) return;
                    (0, f.default)(r, (e, n) => {
                      let i = a[n],
                        {
                          action: o,
                          id: r,
                          mediaQueries: f = c.mediaQueryKeys,
                        } = i,
                        { actionListId: u } = o.config;
                      H(f, c.mediaQueryKeys) ||
                        t.dispatch((0, T.mediaQueriesDefined)()),
                        o.actionTypeId ===
                          p.ActionTypeConsts.GENERAL_CONTINUOUS_ACTION &&
                          (Array.isArray(i.config)
                            ? i.config
                            : [i.config]
                          ).forEach((a) => {
                            let { continuousParameterGroupId: n } = a,
                              i = (0, d.default)(
                                s,
                                `${u}.continuousParameterGroups`,
                                []
                              ),
                              o = (0, l.default)(i, ({ id: e }) => e === n),
                              c = (a.smoothing || 0) / 100,
                              f = (a.restingState || 0) / 100;
                            o &&
                              e.forEach((e, n) => {
                                !(function ({
                                  store: e,
                                  eventStateKey: t,
                                  eventTarget: a,
                                  eventId: n,
                                  eventConfig: i,
                                  actionListId: l,
                                  parameterGroup: o,
                                  smoothing: c,
                                  restingValue: s,
                                }) {
                                  let { ixData: r, ixSession: f } =
                                      e.getState(),
                                    { events: u } = r,
                                    E = u[n],
                                    { eventTypeId: T } = E,
                                    y = {},
                                    m = {},
                                    g = [],
                                    { continuousActionGroups: b } = o,
                                    { id: O } = o;
                                  x(T, i) && (O = P(t, O));
                                  let L =
                                    f.hasBoundaryNodes && a
                                      ? I.getClosestElement(a, R)
                                      : null;
                                  b.forEach((e) => {
                                    let { keyframe: t, actionItems: n } = e;
                                    n.forEach((e) => {
                                      let { actionTypeId: n } = e,
                                        { target: i } = e.config;
                                      if (!i) return;
                                      let l = i.boundaryMode ? L : null,
                                        d = Y(i) + v + n;
                                      if (
                                        ((m[d] = (function (e = [], t, a) {
                                          let n,
                                            i = [...e];
                                          return (
                                            i.some(
                                              (e, a) =>
                                                e.keyframe === t &&
                                                ((n = a), !0)
                                            ),
                                            null == n &&
                                              ((n = i.length),
                                              i.push({
                                                keyframe: t,
                                                actionItems: [],
                                              })),
                                            i[n].actionItems.push(a),
                                            i
                                          );
                                        })(m[d], t, e)),
                                        !y[d])
                                      ) {
                                        y[d] = !0;
                                        let { config: t } = e;
                                        A({
                                          config: t,
                                          event: E,
                                          eventTarget: a,
                                          elementRoot: l,
                                          elementApi: I,
                                        }).forEach((e) => {
                                          g.push({ element: e, key: d });
                                        });
                                      }
                                    });
                                  }),
                                    g.forEach(({ element: t, key: a }) => {
                                      let i = m[a],
                                        o = (0, d.default)(
                                          i,
                                          "[0].actionItems[0]",
                                          {}
                                        ),
                                        { actionTypeId: r } = o,
                                        f = (
                                          r === p.ActionTypeConsts.PLUGIN_RIVE
                                            ? 0 ===
                                              (
                                                o.config?.target
                                                  ?.selectorGuids || []
                                              ).length
                                            : j(r)
                                        )
                                          ? X(r)?.(t, o)
                                          : null,
                                        u = h(
                                          {
                                            element: t,
                                            actionItem: o,
                                            elementApi: I,
                                          },
                                          f
                                        );
                                      eT({
                                        store: e,
                                        element: t,
                                        eventId: n,
                                        actionListId: l,
                                        actionItem: o,
                                        destination: u,
                                        continuous: !0,
                                        parameterId: O,
                                        actionGroups: i,
                                        smoothing: c,
                                        restingValue: s,
                                        pluginInstance: f,
                                      });
                                    });
                                })({
                                  store: t,
                                  eventStateKey: r + v + n,
                                  eventTarget: e,
                                  eventId: r,
                                  eventConfig: a,
                                  actionListId: u,
                                  parameterGroup: o,
                                  smoothing: c,
                                  restingValue: f,
                                });
                              });
                          }),
                        (o.actionTypeId ===
                          p.ActionTypeConsts.GENERAL_START_ACTION ||
                          O(o.actionTypeId)) &&
                          ef({ store: t, actionListId: u, eventId: r });
                    });
                    let E = (e) => {
                        let { ixSession: n } = t.getState();
                        es(r, (l, d, o) => {
                          let s = a[d],
                            r = n.eventState[o],
                            { action: f, mediaQueries: u = c.mediaQueryKeys } =
                              s;
                          if (!D(u, n.mediaQueryKey)) return;
                          let E = (a = {}) => {
                            let n = i(
                              {
                                store: t,
                                element: l,
                                event: s,
                                eventConfig: a,
                                nativeEvent: e,
                                eventStateKey: o,
                              },
                              r
                            );
                            W(n, r) ||
                              t.dispatch((0, T.eventStateChanged)(o, n));
                          };
                          f.actionTypeId ===
                          p.ActionTypeConsts.GENERAL_CONTINUOUS_ACTION
                            ? (Array.isArray(s.config)
                                ? s.config
                                : [s.config]
                              ).forEach(E)
                            : E();
                        });
                      },
                      y = (0, u.default)(E, 12),
                      m = ({ target: e = document, types: a, throttle: n }) => {
                        a.split(" ")
                          .filter(Boolean)
                          .forEach((a) => {
                            let i = n ? y : E;
                            e.addEventListener(a, i),
                              t.dispatch((0, T.eventListenerAdded)(e, [a, i]));
                          });
                      };
                    Array.isArray(n)
                      ? n.forEach(m)
                      : "string" == typeof n && m(e);
                  })({ logic: n, store: e, events: t });
                });
              let { ixSession: n } = e.getState();
              n.eventListeners.length &&
                (function (e) {
                  let t = () => {
                    eo(e);
                  };
                  ed.forEach((a) => {
                    window.addEventListener(a, t),
                      e.dispatch((0, T.eventListenerAdded)(window, [a, t]));
                  }),
                    t();
                })(e);
            })(e),
            (function () {
              let { documentElement: e } = document;
              -1 === e.className.indexOf(N) && (e.className += ` ${N}`);
            })(),
            e.getState().ixSession.hasDefinedMediaQueries &&
              M({
                store: e,
                select: ({ ixSession: e }) => e.mediaQueryKey,
                onChange: () => {
                  ei(e),
                    k({ store: e, elementApi: I }),
                    en({ store: e, allowEvents: !0 }),
                    J();
                },
              }));
          e.dispatch((0, T.sessionStarted)()),
            (function (e, t) {
              let a = (n) => {
                let { ixSession: i, ixParameters: l } = e.getState();
                if (i.active)
                  if ((e.dispatch((0, T.animationFrameChanged)(n, l)), t)) {
                    let t = M({
                      store: e,
                      select: ({ ixSession: e }) => e.tick,
                      onChange: (e) => {
                        a(e), t();
                      },
                    });
                  } else requestAnimationFrame(a);
              };
              a(window.performance.now());
            })(e, n);
        }
      }
      function ei(e) {
        let { ixSession: t } = e.getState();
        if (t.active) {
          let { eventListeners: a } = t;
          a.forEach(el), Q(), e.dispatch((0, T.sessionStopped)());
        }
      }
      function el({ target: e, listenerParams: t }) {
        e.removeEventListener.apply(e, t);
      }
      let ed = ["resize", "orientationchange"];
      function eo(e) {
        let { ixSession: t, ixData: a } = e.getState(),
          n = window.innerWidth;
        if (n !== t.viewportWidth) {
          let { mediaQueries: t } = a;
          e.dispatch(
            (0, T.viewportWidthChanged)({ width: n, mediaQueries: t })
          );
        }
      }
      let ec = (e, t) => (0, c.default)((0, r.default)(e, t), s.default),
        es = (e, t) => {
          (0, f.default)(e, (e, a) => {
            e.forEach((e, n) => {
              t(e, a, a + v + n);
            });
          });
        },
        er = (e) =>
          A({
            config: { target: e.target, targets: e.targets },
            elementApi: I,
          });
      function ef({ store: e, actionListId: t, eventId: a }) {
        let { ixData: n, ixSession: i } = e.getState(),
          { actionLists: l, events: o } = n,
          c = o[a],
          s = l[t];
        if (s && s.useFirstGroupAsInitialState) {
          let l = (0, d.default)(s, "actionItemGroups[0].actionItems", []);
          if (
            !D(
              (0, d.default)(c, "mediaQueries", n.mediaQueryKeys),
              i.mediaQueryKey
            )
          )
            return;
          l.forEach((n) => {
            let { config: i, actionTypeId: l } = n,
              d = A({
                config:
                  i?.target?.useEventTarget === !0 &&
                  i?.target?.objectId == null
                    ? { target: c.target, targets: c.targets }
                    : i,
                event: c,
                elementApi: I,
              }),
              o = j(l);
            d.forEach((i) => {
              let d = o ? X(l)?.(i, n) : null;
              eT({
                destination: h({ element: i, actionItem: n, elementApi: I }, d),
                immediate: !0,
                store: e,
                element: i,
                eventId: a,
                actionItem: n,
                actionListId: t,
                pluginInstance: d,
              });
            });
          });
        }
      }
      function eu({ store: e }) {
        let { ixInstances: t } = e.getState();
        (0, f.default)(t, (t) => {
          if (!t.continuous) {
            let { actionListId: a, verbose: n } = t;
            eI(t, e),
              n &&
                e.dispatch(
                  (0, T.actionListPlaybackChanged)({
                    actionListId: a,
                    isPlaying: !1,
                  })
                );
          }
        });
      }
      function ep({
        store: e,
        eventId: t,
        eventTarget: a,
        eventStateKey: n,
        actionListId: i,
      }) {
        let { ixInstances: l, ixSession: o } = e.getState(),
          c = o.hasBoundaryNodes && a ? I.getClosestElement(a, R) : null;
        (0, f.default)(l, (a) => {
          let l = (0, d.default)(a, "actionItem.config.target.boundaryMode"),
            o = !n || a.eventStateKey === n;
          if (a.actionListId === i && a.eventId === t && o) {
            if (c && l && !I.elementContains(c, a.element)) return;
            eI(a, e),
              a.verbose &&
                e.dispatch(
                  (0, T.actionListPlaybackChanged)({
                    actionListId: i,
                    isPlaying: !1,
                  })
                );
          }
        });
      }
      function eE({
        store: e,
        eventId: t,
        eventTarget: a,
        eventStateKey: n,
        actionListId: i,
        groupIndex: l = 0,
        immediate: o,
        verbose: c,
      }) {
        let { ixData: s, ixSession: r } = e.getState(),
          { events: f } = s,
          u = f[t] || {},
          { mediaQueries: p = s.mediaQueryKeys } = u,
          { actionItemGroups: E, useFirstGroupAsInitialState: T } = (0,
          d.default)(s, `actionLists.${i}`, {});
        if (!E || !E.length) return !1;
        l >= E.length && (0, d.default)(u, "config.loop") && (l = 0),
          0 === l && T && l++;
        let y =
            (0 === l || (1 === l && T)) && O(u.action?.actionTypeId)
              ? u.config.delay
              : void 0,
          m = (0, d.default)(E, [l, "actionItems"], []);
        if (!m.length || !D(p, r.mediaQueryKey)) return !1;
        let g = r.hasBoundaryNodes && a ? I.getClosestElement(a, R) : null,
          b = w(m),
          v = !1;
        return (
          m.forEach((d, s) => {
            let { config: r, actionTypeId: f } = d,
              p = j(f),
              { target: E } = r;
            E &&
              A({
                config: r,
                event: u,
                eventTarget: a,
                elementRoot: E.boundaryMode ? g : null,
                elementApi: I,
              }).forEach((r, u) => {
                let E = p ? X(f)?.(r, d) : null,
                  T = p ? z(f)(r, d) : null;
                v = !0;
                let m = G({ element: r, actionItem: d }),
                  g = h({ element: r, actionItem: d, elementApi: I }, E);
                eT({
                  store: e,
                  element: r,
                  actionItem: d,
                  eventId: t,
                  eventTarget: a,
                  eventStateKey: n,
                  actionListId: i,
                  groupIndex: l,
                  isCarrier: b === s && 0 === u,
                  computedStyle: m,
                  destination: g,
                  immediate: o,
                  verbose: c,
                  pluginInstance: E,
                  pluginDuration: T,
                  instanceDelay: y,
                });
              });
          }),
          v
        );
      }
      function eT(e) {
        let t,
          { store: a, computedStyle: n, ...i } = e,
          {
            element: l,
            actionItem: d,
            immediate: o,
            pluginInstance: c,
            continuous: s,
            restingValue: r,
            eventId: f,
          } = i,
          u = C(),
          { ixElements: E, ixSession: y, ixData: m } = a.getState(),
          g = S(E, l),
          { refState: b } = E[g] || {},
          O = I.getRefType(l),
          v = y.reducedMotion && p.ReducedMotionTypes[d.actionTypeId];
        if (v && s)
          switch (m.events[f]?.eventTypeId) {
            case p.EventTypeConsts.MOUSE_MOVE:
            case p.EventTypeConsts.MOUSE_MOVE_IN_VIEWPORT:
              t = r;
              break;
            default:
              t = 0.5;
          }
        let R = B(l, b, n, d, I, c);
        if (
          (a.dispatch(
            (0, T.instanceAdded)({
              instanceId: u,
              elementId: g,
              origin: R,
              refType: O,
              skipMotion: v,
              skipToValue: t,
              ...i,
            })
          ),
          ey(document.body, "ix2-animation-started", u),
          o)
        )
          return void (function (e, t) {
            let { ixParameters: a } = e.getState();
            e.dispatch((0, T.instanceStarted)(t, 0)),
              e.dispatch((0, T.animationFrameChanged)(performance.now(), a));
            let { ixInstances: n } = e.getState();
            em(n[t], e);
          })(a, u);
        M({ store: a, select: ({ ixInstances: e }) => e[u], onChange: em }),
          s || a.dispatch((0, T.instanceStarted)(u, y.tick));
      }
      function eI(e, t) {
        ey(document.body, "ix2-animation-stopping", {
          instanceId: e.id,
          state: t.getState(),
        });
        let { elementId: a, actionItem: n } = e,
          { ixElements: i } = t.getState(),
          { ref: l, refType: d } = i[a] || {};
        d === L && F(l, n, I), t.dispatch((0, T.instanceRemoved)(e.id));
      }
      function ey(e, t, a) {
        let n = document.createEvent("CustomEvent");
        n.initCustomEvent(t, !0, !0, a), e.dispatchEvent(n);
      }
      function em(e, t) {
        let {
            active: a,
            continuous: n,
            complete: i,
            elementId: l,
            actionItem: d,
            actionTypeId: o,
            renderType: c,
            current: s,
            groupIndex: r,
            eventId: f,
            eventTarget: u,
            eventStateKey: p,
            actionListId: E,
            isCarrier: y,
            styleProp: m,
            verbose: g,
            pluginInstance: b,
          } = e,
          { ixData: O, ixSession: v } = t.getState(),
          { events: R } = O,
          { mediaQueries: N = O.mediaQueryKeys } = R && R[f] ? R[f] : {};
        if (D(N, v.mediaQueryKey) && (n || a || i)) {
          if (s || (c === _ && i)) {
            t.dispatch((0, T.elementStateChanged)(l, o, s, d));
            let { ixElements: e } = t.getState(),
              { ref: a, refType: n, refState: i } = e[l] || {},
              r = i && i[o];
            (n === L || j(o)) && U(a, i, r, f, d, m, I, c, b);
          }
          if (i) {
            if (y) {
              let e = eE({
                store: t,
                eventId: f,
                eventTarget: u,
                eventStateKey: p,
                actionListId: E,
                groupIndex: r + 1,
                verbose: g,
              });
              g &&
                !e &&
                t.dispatch(
                  (0, T.actionListPlaybackChanged)({
                    actionListId: E,
                    isPlaying: !1,
                  })
                );
            }
            eI(e, t);
          }
        }
      }
    },
    8955: function (e, t, a) {
      "use strict";
      let n;
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "default", {
          enumerable: !0,
          get: function () {
            return ep;
          },
        });
      let i = f(a(5801)),
        l = f(a(4738)),
        d = f(a(3789)),
        o = a(7087),
        c = a(1970),
        s = a(3946),
        r = a(9468);
      function f(e) {
        return e && e.__esModule ? e : { default: e };
      }
      let {
          MOUSE_CLICK: u,
          MOUSE_SECOND_CLICK: p,
          MOUSE_DOWN: E,
          MOUSE_UP: T,
          MOUSE_OVER: I,
          MOUSE_OUT: y,
          DROPDOWN_CLOSE: m,
          DROPDOWN_OPEN: g,
          SLIDER_ACTIVE: b,
          SLIDER_INACTIVE: O,
          TAB_ACTIVE: v,
          TAB_INACTIVE: R,
          NAVBAR_CLOSE: L,
          NAVBAR_OPEN: _,
          MOUSE_MOVE: N,
          PAGE_SCROLL_DOWN: A,
          SCROLL_INTO_VIEW: S,
          SCROLL_OUT_OF_VIEW: h,
          PAGE_SCROLL_UP: M,
          SCROLLING_IN_VIEW: C,
          PAGE_FINISH: U,
          ECOMMERCE_CART_CLOSE: k,
          ECOMMERCE_CART_OPEN: w,
          PAGE_START: G,
          PAGE_SCROLL: B,
        } = o.EventTypeConsts,
        V = "COMPONENT_ACTIVE",
        x = "COMPONENT_INACTIVE",
        { COLON_DELIMITER: P } = o.IX2EngineConstants,
        { getNamespacedParameterId: D } = r.IX2VanillaUtils,
        F = (e) => (t) => !!("object" == typeof t && e(t)) || t,
        Q = F(({ element: e, nativeEvent: t }) => e === t.target),
        Y = F(({ element: e, nativeEvent: t }) => e.contains(t.target)),
        H = (0, i.default)([Q, Y]),
        W = (e, t) => {
          if (t) {
            let { ixData: a } = e.getState(),
              { events: n } = a,
              i = n[t];
            if (i && !ee[i.eventTypeId]) return i;
          }
          return null;
        },
        j = ({ store: e, event: t }) => {
          let { action: a } = t,
            { autoStopEventId: n } = a.config;
          return !!W(e, n);
        },
        X = ({ store: e, event: t, element: a, eventStateKey: n }, i) => {
          let { action: d, id: o } = t,
            { actionListId: s, autoStopEventId: r } = d.config,
            f = W(e, r);
          return (
            f &&
              (0, c.stopActionGroup)({
                store: e,
                eventId: r,
                eventTarget: a,
                eventStateKey: r + P + n.split(P)[1],
                actionListId: (0, l.default)(f, "action.config.actionListId"),
              }),
            (0, c.stopActionGroup)({
              store: e,
              eventId: o,
              eventTarget: a,
              eventStateKey: n,
              actionListId: s,
            }),
            (0, c.startActionGroup)({
              store: e,
              eventId: o,
              eventTarget: a,
              eventStateKey: n,
              actionListId: s,
            }),
            i
          );
        },
        z = (e, t) => (a, n) => !0 === e(a, n) ? t(a, n) : n,
        $ = { handler: z(H, X) },
        q = { ...$, types: [V, x].join(" ") },
        K = [
          { target: window, types: "resize orientationchange", throttle: !0 },
          {
            target: document,
            types: "scroll wheel readystatechange IX2_PAGE_UPDATE",
            throttle: !0,
          },
        ],
        Z = "mouseover mouseout",
        J = { types: K },
        ee = { PAGE_START: G, PAGE_FINISH: U },
        et = (() => {
          let e = void 0 !== window.pageXOffset,
            t =
              "CSS1Compat" === document.compatMode
                ? document.documentElement
                : document.body;
          return () => ({
            scrollLeft: e ? window.pageXOffset : t.scrollLeft,
            scrollTop: e ? window.pageYOffset : t.scrollTop,
            stiffScrollTop: (0, d.default)(
              e ? window.pageYOffset : t.scrollTop,
              0,
              t.scrollHeight - window.innerHeight
            ),
            scrollWidth: t.scrollWidth,
            scrollHeight: t.scrollHeight,
            clientWidth: t.clientWidth,
            clientHeight: t.clientHeight,
            innerWidth: window.innerWidth,
            innerHeight: window.innerHeight,
          });
        })(),
        ea = (e, t) =>
          !(
            e.left > t.right ||
            e.right < t.left ||
            e.top > t.bottom ||
            e.bottom < t.top
          ),
        en = ({ element: e, nativeEvent: t }) => {
          let { type: a, target: n, relatedTarget: i } = t,
            l = e.contains(n);
          if ("mouseover" === a && l) return !0;
          let d = e.contains(i);
          return "mouseout" === a && !!l && !!d;
        },
        ei = (e) => {
          let {
              element: t,
              event: { config: a },
            } = e,
            { clientWidth: n, clientHeight: i } = et(),
            l = a.scrollOffsetValue,
            d = "PX" === a.scrollOffsetUnit ? l : (i * (l || 0)) / 100;
          return ea(t.getBoundingClientRect(), {
            left: 0,
            top: d,
            right: n,
            bottom: i - d,
          });
        },
        el = (e) => (t, a) => {
          let { type: n } = t.nativeEvent,
            i = -1 !== [V, x].indexOf(n) ? n === V : a.isActive,
            l = { ...a, isActive: i };
          return ((!a || l.isActive !== a.isActive) && e(t, l)) || l;
        },
        ed = (e) => (t, a) => {
          let n = { elementHovered: en(t) };
          return (
            ((a ? n.elementHovered !== a.elementHovered : n.elementHovered) &&
              e(t, n)) ||
            n
          );
        },
        eo =
          (e) =>
          (t, a = {}) => {
            let n,
              i,
              { stiffScrollTop: l, scrollHeight: d, innerHeight: o } = et(),
              {
                event: { config: c, eventTypeId: s },
              } = t,
              { scrollOffsetValue: r, scrollOffsetUnit: f } = c,
              u = d - o,
              p = Number((l / u).toFixed(2));
            if (a && a.percentTop === p) return a;
            let E = ("PX" === f ? r : (o * (r || 0)) / 100) / u,
              T = 0;
            a &&
              ((n = p > a.percentTop),
              (T = (i = a.scrollingDown !== n) ? p : a.anchorTop));
            let I = s === A ? p >= T + E : p <= T - E,
              y = {
                ...a,
                percentTop: p,
                inBounds: I,
                anchorTop: T,
                scrollingDown: n,
              };
            return (a && I && (i || y.inBounds !== a.inBounds) && e(t, y)) || y;
          },
        ec = (e, t) =>
          e.left > t.left &&
          e.left < t.right &&
          e.top > t.top &&
          e.top < t.bottom,
        es =
          (e) =>
          (t, a = { clickCount: 0 }) => {
            let n = { clickCount: (a.clickCount % 2) + 1 };
            return (n.clickCount !== a.clickCount && e(t, n)) || n;
          },
        er = (e = !0) => ({
          ...q,
          handler: z(
            e ? H : Q,
            el((e, t) => (t.isActive ? $.handler(e, t) : t))
          ),
        }),
        ef = (e = !0) => ({
          ...q,
          handler: z(
            e ? H : Q,
            el((e, t) => (t.isActive ? t : $.handler(e, t)))
          ),
        }),
        eu = {
          ...J,
          handler:
            ((n = (e, t) => {
              let { elementVisible: a } = t,
                { event: n, store: i } = e,
                { ixData: l } = i.getState(),
                { events: d } = l;
              return !d[n.action.config.autoStopEventId] && t.triggered
                ? t
                : (n.eventTypeId === S) === a
                ? (X(e), { ...t, triggered: !0 })
                : t;
            }),
            (e, t) => {
              let a = { ...t, elementVisible: ei(e) };
              return (
                ((t
                  ? a.elementVisible !== t.elementVisible
                  : a.elementVisible) &&
                  n(e, a)) ||
                a
              );
            }),
        },
        ep = {
          [b]: er(),
          [O]: ef(),
          [g]: er(),
          [m]: ef(),
          [_]: er(!1),
          [L]: ef(!1),
          [v]: er(),
          [R]: ef(),
          [w]: { types: "ecommerce-cart-open", handler: z(H, X) },
          [k]: { types: "ecommerce-cart-close", handler: z(H, X) },
          [u]: {
            types: "click",
            handler: z(
              H,
              es((e, { clickCount: t }) => {
                j(e) ? 1 === t && X(e) : X(e);
              })
            ),
          },
          [p]: {
            types: "click",
            handler: z(
              H,
              es((e, { clickCount: t }) => {
                2 === t && X(e);
              })
            ),
          },
          [E]: { ...$, types: "mousedown" },
          [T]: { ...$, types: "mouseup" },
          [I]: {
            types: Z,
            handler: z(
              H,
              ed((e, t) => {
                t.elementHovered && X(e);
              })
            ),
          },
          [y]: {
            types: Z,
            handler: z(
              H,
              ed((e, t) => {
                t.elementHovered || X(e);
              })
            ),
          },
          [N]: {
            types: "mousemove mouseout scroll",
            handler: (
              {
                store: e,
                element: t,
                eventConfig: a,
                nativeEvent: n,
                eventStateKey: i,
              },
              l = { clientX: 0, clientY: 0, pageX: 0, pageY: 0 }
            ) => {
              let {
                  basedOn: d,
                  selectedAxis: c,
                  continuousParameterGroupId: r,
                  reverse: f,
                  restingState: u = 0,
                } = a,
                {
                  clientX: p = l.clientX,
                  clientY: E = l.clientY,
                  pageX: T = l.pageX,
                  pageY: I = l.pageY,
                } = n,
                y = "X_AXIS" === c,
                m = "mouseout" === n.type,
                g = u / 100,
                b = r,
                O = !1;
              switch (d) {
                case o.EventBasedOn.VIEWPORT:
                  g = y
                    ? Math.min(p, window.innerWidth) / window.innerWidth
                    : Math.min(E, window.innerHeight) / window.innerHeight;
                  break;
                case o.EventBasedOn.PAGE: {
                  let {
                    scrollLeft: e,
                    scrollTop: t,
                    scrollWidth: a,
                    scrollHeight: n,
                  } = et();
                  g = y ? Math.min(e + T, a) / a : Math.min(t + I, n) / n;
                  break;
                }
                case o.EventBasedOn.ELEMENT:
                default: {
                  b = D(i, r);
                  let e = 0 === n.type.indexOf("mouse");
                  if (e && !0 !== H({ element: t, nativeEvent: n })) break;
                  let a = t.getBoundingClientRect(),
                    { left: l, top: d, width: o, height: c } = a;
                  if (!e && !ec({ left: p, top: E }, a)) break;
                  (O = !0), (g = y ? (p - l) / o : (E - d) / c);
                }
              }
              return (
                m && (g > 0.95 || g < 0.05) && (g = Math.round(g)),
                (d !== o.EventBasedOn.ELEMENT || O || O !== l.elementHovered) &&
                  ((g = f ? 1 - g : g),
                  e.dispatch((0, s.parameterChanged)(b, g))),
                {
                  elementHovered: O,
                  clientX: p,
                  clientY: E,
                  pageX: T,
                  pageY: I,
                }
              );
            },
          },
          [B]: {
            types: K,
            handler: ({ store: e, eventConfig: t }) => {
              let { continuousParameterGroupId: a, reverse: n } = t,
                { scrollTop: i, scrollHeight: l, clientHeight: d } = et(),
                o = i / (l - d);
              (o = n ? 1 - o : o), e.dispatch((0, s.parameterChanged)(a, o));
            },
          },
          [C]: {
            types: K,
            handler: (
              { element: e, store: t, eventConfig: a, eventStateKey: n },
              i = { scrollPercent: 0 }
            ) => {
              let {
                  scrollLeft: l,
                  scrollTop: d,
                  scrollWidth: c,
                  scrollHeight: r,
                  clientHeight: f,
                } = et(),
                {
                  basedOn: u,
                  selectedAxis: p,
                  continuousParameterGroupId: E,
                  startsEntering: T,
                  startsExiting: I,
                  addEndOffset: y,
                  addStartOffset: m,
                  addOffsetValue: g = 0,
                  endOffsetValue: b = 0,
                } = a;
              if (u === o.EventBasedOn.VIEWPORT) {
                let e = "X_AXIS" === p ? l / c : d / r;
                return (
                  e !== i.scrollPercent &&
                    t.dispatch((0, s.parameterChanged)(E, e)),
                  { scrollPercent: e }
                );
              }
              {
                let a = D(n, E),
                  l = e.getBoundingClientRect(),
                  d = (m ? g : 0) / 100,
                  o = (y ? b : 0) / 100;
                (d = T ? d : 1 - d), (o = I ? o : 1 - o);
                let c = l.top + Math.min(l.height * d, f),
                  u = Math.min(f + (l.top + l.height * o - c), r),
                  p = Math.min(Math.max(0, f - c), u) / u;
                return (
                  p !== i.scrollPercent &&
                    t.dispatch((0, s.parameterChanged)(a, p)),
                  { scrollPercent: p }
                );
              }
            },
          },
          [S]: eu,
          [h]: eu,
          [A]: {
            ...J,
            handler: eo((e, t) => {
              t.scrollingDown && X(e);
            }),
          },
          [M]: {
            ...J,
            handler: eo((e, t) => {
              t.scrollingDown || X(e);
            }),
          },
          [U]: {
            types: "readystatechange IX2_PAGE_UPDATE",
            handler: z(Q, (e, t) => {
              let a = { finished: "complete" === document.readyState };
              return a.finished && !(t && t.finshed) && X(e), a;
            }),
          },
          [G]: {
            types: "readystatechange IX2_PAGE_UPDATE",
            handler: z(Q, (e, t) => (t || X(e), { started: !0 })),
          },
        };
    },
    4609: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixData", {
          enumerable: !0,
          get: function () {
            return i;
          },
        });
      let { IX2_RAW_DATA_IMPORTED: n } = a(7087).IX2EngineActionTypes,
        i = (e = Object.freeze({}), t) =>
          t.type === n ? t.payload.ixData || Object.freeze({}) : e;
    },
    7718: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixInstances", {
          enumerable: !0,
          get: function () {
            return O;
          },
        });
      let n = a(7087),
        i = a(9468),
        l = a(1185),
        {
          IX2_RAW_DATA_IMPORTED: d,
          IX2_SESSION_STOPPED: o,
          IX2_INSTANCE_ADDED: c,
          IX2_INSTANCE_STARTED: s,
          IX2_INSTANCE_REMOVED: r,
          IX2_ANIMATION_FRAME_CHANGED: f,
        } = n.IX2EngineActionTypes,
        {
          optimizeFloat: u,
          applyEasing: p,
          createBezierEasing: E,
        } = i.IX2EasingUtils,
        { RENDER_GENERAL: T } = n.IX2EngineConstants,
        {
          getItemConfigByKey: I,
          getRenderType: y,
          getStyleProp: m,
        } = i.IX2VanillaUtils,
        g = (e, t) => {
          let a,
            n,
            i,
            d,
            {
              position: o,
              parameterId: c,
              actionGroups: s,
              destinationKeys: r,
              smoothing: f,
              restingValue: E,
              actionTypeId: T,
              customEasingFn: y,
              skipMotion: m,
              skipToValue: g,
            } = e,
            { parameters: b } = t.payload,
            O = Math.max(1 - f, 0.01),
            v = b[c];
          null == v && ((O = 1), (v = E));
          let R = u((Math.max(v, 0) || 0) - o),
            L = m ? g : u(o + R * O),
            _ = 100 * L;
          if (L === o && e.current) return e;
          for (let e = 0, { length: t } = s; e < t; e++) {
            let { keyframe: t, actionItems: l } = s[e];
            if ((0 === e && (a = l[0]), _ >= t)) {
              a = l[0];
              let o = s[e + 1],
                c = o && _ !== t;
              (n = c ? o.actionItems[0] : null),
                c && ((i = t / 100), (d = (o.keyframe - t) / 100));
            }
          }
          let N = {};
          if (a && !n)
            for (let e = 0, { length: t } = r; e < t; e++) {
              let t = r[e];
              N[t] = I(T, t, a.config);
            }
          else if (a && n && void 0 !== i && void 0 !== d) {
            let e = (L - i) / d,
              t = p(a.config.easing, e, y);
            for (let e = 0, { length: i } = r; e < i; e++) {
              let i = r[e],
                l = I(T, i, a.config),
                d = (I(T, i, n.config) - l) * t + l;
              N[i] = d;
            }
          }
          return (0, l.merge)(e, { position: L, current: N });
        },
        b = (e, t) => {
          let {
              active: a,
              origin: n,
              start: i,
              immediate: d,
              renderType: o,
              verbose: c,
              actionItem: s,
              destination: r,
              destinationKeys: f,
              pluginDuration: E,
              instanceDelay: I,
              customEasingFn: y,
              skipMotion: m,
            } = e,
            g = s.config.easing,
            { duration: b, delay: O } = s.config;
          null != E && (b = E),
            (O = null != I ? I : O),
            o === T ? (b = 0) : (d || m) && (b = O = 0);
          let { now: v } = t.payload;
          if (a && n) {
            let t = v - (i + O);
            if (c) {
              let t = b + O,
                a = u(Math.min(Math.max(0, (v - i) / t), 1));
              e = (0, l.set)(e, "verboseTimeElapsed", t * a);
            }
            if (t < 0) return e;
            let a = u(Math.min(Math.max(0, t / b), 1)),
              d = p(g, a, y),
              o = {},
              s = null;
            return (
              f.length &&
                (s = f.reduce((e, t) => {
                  let a = r[t],
                    i = parseFloat(n[t]) || 0,
                    l = parseFloat(a) - i;
                  return (e[t] = l * d + i), e;
                }, {})),
              (o.current = s),
              (o.position = a),
              1 === a && ((o.active = !1), (o.complete = !0)),
              (0, l.merge)(e, o)
            );
          }
          return e;
        },
        O = (e = Object.freeze({}), t) => {
          switch (t.type) {
            case d:
              return t.payload.ixInstances || Object.freeze({});
            case o:
              return Object.freeze({});
            case c: {
              let {
                  instanceId: a,
                  elementId: n,
                  actionItem: i,
                  eventId: d,
                  eventTarget: o,
                  eventStateKey: c,
                  actionListId: s,
                  groupIndex: r,
                  isCarrier: f,
                  origin: u,
                  destination: p,
                  immediate: T,
                  verbose: I,
                  continuous: g,
                  parameterId: b,
                  actionGroups: O,
                  smoothing: v,
                  restingValue: R,
                  pluginInstance: L,
                  pluginDuration: _,
                  instanceDelay: N,
                  skipMotion: A,
                  skipToValue: S,
                } = t.payload,
                { actionTypeId: h } = i,
                M = y(h),
                C = m(M, h),
                U = Object.keys(p).filter(
                  (e) => null != p[e] && "string" != typeof p[e]
                ),
                { easing: k } = i.config;
              return (0, l.set)(e, a, {
                id: a,
                elementId: n,
                active: !1,
                position: 0,
                start: 0,
                origin: u,
                destination: p,
                destinationKeys: U,
                immediate: T,
                verbose: I,
                current: null,
                actionItem: i,
                actionTypeId: h,
                eventId: d,
                eventTarget: o,
                eventStateKey: c,
                actionListId: s,
                groupIndex: r,
                renderType: M,
                isCarrier: f,
                styleProp: C,
                continuous: g,
                parameterId: b,
                actionGroups: O,
                smoothing: v,
                restingValue: R,
                pluginInstance: L,
                pluginDuration: _,
                instanceDelay: N,
                skipMotion: A,
                skipToValue: S,
                customEasingFn:
                  Array.isArray(k) && 4 === k.length ? E(k) : void 0,
              });
            }
            case s: {
              let { instanceId: a, time: n } = t.payload;
              return (0, l.mergeIn)(e, [a], {
                active: !0,
                complete: !1,
                start: n,
              });
            }
            case r: {
              let { instanceId: a } = t.payload;
              if (!e[a]) return e;
              let n = {},
                i = Object.keys(e),
                { length: l } = i;
              for (let t = 0; t < l; t++) {
                let l = i[t];
                l !== a && (n[l] = e[l]);
              }
              return n;
            }
            case f: {
              let a = e,
                n = Object.keys(e),
                { length: i } = n;
              for (let d = 0; d < i; d++) {
                let i = n[d],
                  o = e[i],
                  c = o.continuous ? g : b;
                a = (0, l.set)(a, i, c(o, t));
              }
              return a;
            }
            default:
              return e;
          }
        };
    },
    1540: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixParameters", {
          enumerable: !0,
          get: function () {
            return d;
          },
        });
      let {
          IX2_RAW_DATA_IMPORTED: n,
          IX2_SESSION_STOPPED: i,
          IX2_PARAMETER_CHANGED: l,
        } = a(7087).IX2EngineActionTypes,
        d = (e = {}, t) => {
          switch (t.type) {
            case n:
              return t.payload.ixParameters || {};
            case i:
              return {};
            case l: {
              let { key: a, value: n } = t.payload;
              return (e[a] = n), e;
            }
            default:
              return e;
          }
        };
    },
    7243: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "default", {
          enumerable: !0,
          get: function () {
            return f;
          },
        });
      let n = a(9516),
        i = a(4609),
        l = a(628),
        d = a(5862),
        o = a(9468),
        c = a(7718),
        s = a(1540),
        { ixElements: r } = o.IX2ElementsReducer,
        f = (0, n.combineReducers)({
          ixData: i.ixData,
          ixRequest: l.ixRequest,
          ixSession: d.ixSession,
          ixElements: r,
          ixInstances: c.ixInstances,
          ixParameters: s.ixParameters,
        });
    },
    628: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixRequest", {
          enumerable: !0,
          get: function () {
            return f;
          },
        });
      let n = a(7087),
        i = a(1185),
        {
          IX2_PREVIEW_REQUESTED: l,
          IX2_PLAYBACK_REQUESTED: d,
          IX2_STOP_REQUESTED: o,
          IX2_CLEAR_REQUESTED: c,
        } = n.IX2EngineActionTypes,
        s = { preview: {}, playback: {}, stop: {}, clear: {} },
        r = Object.create(null, {
          [l]: { value: "preview" },
          [d]: { value: "playback" },
          [o]: { value: "stop" },
          [c]: { value: "clear" },
        }),
        f = (e = s, t) => {
          if (t.type in r) {
            let a = [r[t.type]];
            return (0, i.setIn)(e, [a], { ...t.payload });
          }
          return e;
        };
    },
    5862: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixSession", {
          enumerable: !0,
          get: function () {
            return I;
          },
        });
      let n = a(7087),
        i = a(1185),
        {
          IX2_SESSION_INITIALIZED: l,
          IX2_SESSION_STARTED: d,
          IX2_TEST_FRAME_RENDERED: o,
          IX2_SESSION_STOPPED: c,
          IX2_EVENT_LISTENER_ADDED: s,
          IX2_EVENT_STATE_CHANGED: r,
          IX2_ANIMATION_FRAME_CHANGED: f,
          IX2_ACTION_LIST_PLAYBACK_CHANGED: u,
          IX2_VIEWPORT_WIDTH_CHANGED: p,
          IX2_MEDIA_QUERIES_DEFINED: E,
        } = n.IX2EngineActionTypes,
        T = {
          active: !1,
          tick: 0,
          eventListeners: [],
          eventState: {},
          playbackState: {},
          viewportWidth: 0,
          mediaQueryKey: null,
          hasBoundaryNodes: !1,
          hasDefinedMediaQueries: !1,
          reducedMotion: !1,
        },
        I = (e = T, t) => {
          switch (t.type) {
            case l: {
              let { hasBoundaryNodes: a, reducedMotion: n } = t.payload;
              return (0, i.merge)(e, { hasBoundaryNodes: a, reducedMotion: n });
            }
            case d:
              return (0, i.set)(e, "active", !0);
            case o: {
              let {
                payload: { step: a = 20 },
              } = t;
              return (0, i.set)(e, "tick", e.tick + a);
            }
            case c:
              return T;
            case f: {
              let {
                payload: { now: a },
              } = t;
              return (0, i.set)(e, "tick", a);
            }
            case s: {
              let a = (0, i.addLast)(e.eventListeners, t.payload);
              return (0, i.set)(e, "eventListeners", a);
            }
            case r: {
              let { stateKey: a, newState: n } = t.payload;
              return (0, i.setIn)(e, ["eventState", a], n);
            }
            case u: {
              let { actionListId: a, isPlaying: n } = t.payload;
              return (0, i.setIn)(e, ["playbackState", a], n);
            }
            case p: {
              let { width: a, mediaQueries: n } = t.payload,
                l = n.length,
                d = null;
              for (let e = 0; e < l; e++) {
                let { key: t, min: i, max: l } = n[e];
                if (a >= i && a <= l) {
                  d = t;
                  break;
                }
              }
              return (0, i.merge)(e, { viewportWidth: a, mediaQueryKey: d });
            }
            case E:
              return (0, i.set)(e, "hasDefinedMediaQueries", !0);
            default:
              return e;
          }
        };
    },
    7377: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        clearPlugin: function () {
          return r;
        },
        createPluginInstance: function () {
          return c;
        },
        getPluginConfig: function () {
          return i;
        },
        getPluginDestination: function () {
          return o;
        },
        getPluginDuration: function () {
          return l;
        },
        getPluginOrigin: function () {
          return d;
        },
        renderPlugin: function () {
          return s;
        },
      };
      for (var n in a)
        Object.defineProperty(t, n, { enumerable: !0, get: a[n] });
      let i = (e) => e.value,
        l = (e, t) => {
          if ("auto" !== t.config.duration) return null;
          let a = parseFloat(e.getAttribute("data-duration"));
          return a > 0
            ? 1e3 * a
            : 1e3 * parseFloat(e.getAttribute("data-default-duration"));
        },
        d = (e) => e || { value: 0 },
        o = (e) => ({ value: e.value }),
        c = (e) => {
          let t = window.Webflow.require("lottie");
          if (!t) return null;
          let a = t.createInstance(e);
          return a.stop(), a.setSubframe(!0), a;
        },
        s = (e, t, a) => {
          if (!e) return;
          let n = t[a.actionTypeId].value / 100;
          e.goToFrame(e.frames * n);
        },
        r = (e) => {
          let t = window.Webflow.require("lottie");
          t && t.createInstance(e).stop();
        };
    },
    2570: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        clearPlugin: function () {
          return E;
        },
        createPluginInstance: function () {
          return u;
        },
        getPluginConfig: function () {
          return c;
        },
        getPluginDestination: function () {
          return f;
        },
        getPluginDuration: function () {
          return s;
        },
        getPluginOrigin: function () {
          return r;
        },
        renderPlugin: function () {
          return p;
        },
      };
      for (var n in a)
        Object.defineProperty(t, n, { enumerable: !0, get: a[n] });
      let i = "--wf-rive-fit",
        l = "--wf-rive-alignment",
        d = (e) => document.querySelector(`[data-w-id="${e}"]`),
        o = () => window.Webflow.require("rive"),
        c = (e, t) => e.value.inputs[t],
        s = () => null,
        r = (e, t) => {
          if (e) return e;
          let a = {},
            { inputs: n = {} } = t.config.value;
          for (let e in n) null == n[e] && (a[e] = 0);
          return a;
        },
        f = (e) => e.value.inputs ?? {},
        u = (e, t) => {
          if ((t.config?.target?.selectorGuids || []).length > 0) return e;
          let a = t?.config?.target?.pluginElement;
          return a ? d(a) : null;
        },
        p = (e, { PLUGIN_RIVE: t }, a) => {
          let n = o();
          if (!n) return;
          let d = n.getInstance(e),
            c = n.rive.StateMachineInputType,
            { name: s, inputs: r = {} } = a.config.value || {};
          function f(e) {
            if (e.loaded) a();
            else {
              let t = () => {
                a(), e?.off("load", t);
              };
              e?.on("load", t);
            }
            function a() {
              let a = e.stateMachineInputs(s);
              if (null != a) {
                if ((e.isPlaying || e.play(s, !1), i in r || l in r)) {
                  let t = e.layout,
                    a = r[i] ?? t.fit,
                    n = r[l] ?? t.alignment;
                  (a !== t.fit || n !== t.alignment) &&
                    (e.layout = t.copyWith({ fit: a, alignment: n }));
                }
                for (let e in r) {
                  if (e === i || e === l) continue;
                  let n = a.find((t) => t.name === e);
                  if (null != n)
                    switch (n.type) {
                      case c.Boolean:
                        null != r[e] && (n.value = !!r[e]);
                        break;
                      case c.Number: {
                        let a = t[e];
                        null != a && (n.value = a);
                        break;
                      }
                      case c.Trigger:
                        r[e] && n.fire();
                    }
                }
              }
            }
          }
          d?.rive ? f(d.rive) : n.setLoadHandler(e, f);
        },
        E = (e, t) => null;
    },
    2866: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        clearPlugin: function () {
          return E;
        },
        createPluginInstance: function () {
          return u;
        },
        getPluginConfig: function () {
          return o;
        },
        getPluginDestination: function () {
          return f;
        },
        getPluginDuration: function () {
          return c;
        },
        getPluginOrigin: function () {
          return r;
        },
        renderPlugin: function () {
          return p;
        },
      };
      for (var n in a)
        Object.defineProperty(t, n, { enumerable: !0, get: a[n] });
      let i = (e) => document.querySelector(`[data-w-id="${e}"]`),
        l = () => window.Webflow.require("spline"),
        d = (e, t) => e.filter((e) => !t.includes(e)),
        o = (e, t) => e.value[t],
        c = () => null,
        s = Object.freeze({
          positionX: 0,
          positionY: 0,
          positionZ: 0,
          rotationX: 0,
          rotationY: 0,
          rotationZ: 0,
          scaleX: 1,
          scaleY: 1,
          scaleZ: 1,
        }),
        r = (e, t) => {
          let a = Object.keys(t.config.value);
          if (e) {
            let t = d(a, Object.keys(e));
            return t.length ? t.reduce((e, t) => ((e[t] = s[t]), e), e) : e;
          }
          return a.reduce((e, t) => ((e[t] = s[t]), e), {});
        },
        f = (e) => e.value,
        u = (e, t) => {
          let a = t?.config?.target?.pluginElement;
          return a ? i(a) : null;
        },
        p = (e, t, a) => {
          let n = l();
          if (!n) return;
          let i = n.getInstance(e),
            d = a.config.target.objectId,
            o = (e) => {
              if (!e) throw Error("Invalid spline app passed to renderSpline");
              let a = d && e.findObjectById(d);
              if (!a) return;
              let { PLUGIN_SPLINE: n } = t;
              null != n.positionX && (a.position.x = n.positionX),
                null != n.positionY && (a.position.y = n.positionY),
                null != n.positionZ && (a.position.z = n.positionZ),
                null != n.rotationX && (a.rotation.x = n.rotationX),
                null != n.rotationY && (a.rotation.y = n.rotationY),
                null != n.rotationZ && (a.rotation.z = n.rotationZ),
                null != n.scaleX && (a.scale.x = n.scaleX),
                null != n.scaleY && (a.scale.y = n.scaleY),
                null != n.scaleZ && (a.scale.z = n.scaleZ);
            };
          i ? o(i.spline) : n.setLoadHandler(e, o);
        },
        E = () => null;
    },
    1407: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        clearPlugin: function () {
          return p;
        },
        createPluginInstance: function () {
          return r;
        },
        getPluginConfig: function () {
          return d;
        },
        getPluginDestination: function () {
          return s;
        },
        getPluginDuration: function () {
          return o;
        },
        getPluginOrigin: function () {
          return c;
        },
        renderPlugin: function () {
          return u;
        },
      };
      for (var i in n)
        Object.defineProperty(t, i, { enumerable: !0, get: n[i] });
      let l = a(380),
        d = (e, t) => e.value[t],
        o = () => null,
        c = (e, t) => {
          if (e) return e;
          let a = t.config.value,
            n = t.config.target.objectId,
            i = getComputedStyle(document.documentElement).getPropertyValue(n);
          return null != a.size
            ? { size: parseInt(i, 10) }
            : "%" === a.unit || "-" === a.unit
            ? { size: parseFloat(i) }
            : null != a.red && null != a.green && null != a.blue
            ? (0, l.normalizeColor)(i)
            : void 0;
        },
        s = (e) => e.value,
        r = () => null,
        f = {
          color: {
            match: ({ red: e, green: t, blue: a, alpha: n }) =>
              [e, t, a, n].every((e) => null != e),
            getValue: ({ red: e, green: t, blue: a, alpha: n }) =>
              `rgba(${e}, ${t}, ${a}, ${n})`,
          },
          size: {
            match: ({ size: e }) => null != e,
            getValue: ({ size: e }, t) => ("-" === t ? e : `${e}${t}`),
          },
        },
        u = (e, t, a) => {
          let {
              target: { objectId: n },
              value: { unit: i },
            } = a.config,
            l = t.PLUGIN_VARIABLE,
            d = Object.values(f).find((e) => e.match(l, i));
          d && document.documentElement.style.setProperty(n, d.getValue(l, i));
        },
        p = (e, t) => {
          let a = t.config.target.objectId;
          document.documentElement.style.removeProperty(a);
        };
    },
    3690: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "pluginMethodMap", {
          enumerable: !0,
          get: function () {
            return r;
          },
        });
      let n = a(7087),
        i = s(a(7377)),
        l = s(a(2866)),
        d = s(a(2570)),
        o = s(a(1407));
      function c(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          a = new WeakMap();
        return (c = function (e) {
          return e ? a : t;
        })(e);
      }
      function s(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || ("object" != typeof e && "function" != typeof e))
          return { default: e };
        var a = c(t);
        if (a && a.has(e)) return a.get(e);
        var n = { __proto__: null },
          i = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var l in e)
          if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
            var d = i ? Object.getOwnPropertyDescriptor(e, l) : null;
            d && (d.get || d.set)
              ? Object.defineProperty(n, l, d)
              : (n[l] = e[l]);
          }
        return (n.default = e), a && a.set(e, n), n;
      }
      let r = new Map([
        [n.ActionTypeConsts.PLUGIN_LOTTIE, { ...i }],
        [n.ActionTypeConsts.PLUGIN_SPLINE, { ...l }],
        [n.ActionTypeConsts.PLUGIN_RIVE, { ...d }],
        [n.ActionTypeConsts.PLUGIN_VARIABLE, { ...o }],
      ]);
    },
    8023: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        IX2_ACTION_LIST_PLAYBACK_CHANGED: function () {
          return b;
        },
        IX2_ANIMATION_FRAME_CHANGED: function () {
          return E;
        },
        IX2_CLEAR_REQUESTED: function () {
          return f;
        },
        IX2_ELEMENT_STATE_CHANGED: function () {
          return g;
        },
        IX2_EVENT_LISTENER_ADDED: function () {
          return u;
        },
        IX2_EVENT_STATE_CHANGED: function () {
          return p;
        },
        IX2_INSTANCE_ADDED: function () {
          return I;
        },
        IX2_INSTANCE_REMOVED: function () {
          return m;
        },
        IX2_INSTANCE_STARTED: function () {
          return y;
        },
        IX2_MEDIA_QUERIES_DEFINED: function () {
          return v;
        },
        IX2_PARAMETER_CHANGED: function () {
          return T;
        },
        IX2_PLAYBACK_REQUESTED: function () {
          return s;
        },
        IX2_PREVIEW_REQUESTED: function () {
          return c;
        },
        IX2_RAW_DATA_IMPORTED: function () {
          return i;
        },
        IX2_SESSION_INITIALIZED: function () {
          return l;
        },
        IX2_SESSION_STARTED: function () {
          return d;
        },
        IX2_SESSION_STOPPED: function () {
          return o;
        },
        IX2_STOP_REQUESTED: function () {
          return r;
        },
        IX2_TEST_FRAME_RENDERED: function () {
          return R;
        },
        IX2_VIEWPORT_WIDTH_CHANGED: function () {
          return O;
        },
      };
      for (var n in a)
        Object.defineProperty(t, n, { enumerable: !0, get: a[n] });
      let i = "IX2_RAW_DATA_IMPORTED",
        l = "IX2_SESSION_INITIALIZED",
        d = "IX2_SESSION_STARTED",
        o = "IX2_SESSION_STOPPED",
        c = "IX2_PREVIEW_REQUESTED",
        s = "IX2_PLAYBACK_REQUESTED",
        r = "IX2_STOP_REQUESTED",
        f = "IX2_CLEAR_REQUESTED",
        u = "IX2_EVENT_LISTENER_ADDED",
        p = "IX2_EVENT_STATE_CHANGED",
        E = "IX2_ANIMATION_FRAME_CHANGED",
        T = "IX2_PARAMETER_CHANGED",
        I = "IX2_INSTANCE_ADDED",
        y = "IX2_INSTANCE_STARTED",
        m = "IX2_INSTANCE_REMOVED",
        g = "IX2_ELEMENT_STATE_CHANGED",
        b = "IX2_ACTION_LIST_PLAYBACK_CHANGED",
        O = "IX2_VIEWPORT_WIDTH_CHANGED",
        v = "IX2_MEDIA_QUERIES_DEFINED",
        R = "IX2_TEST_FRAME_RENDERED";
    },
    2686: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        AUTO: function () {
          return H;
        },
        BACKGROUND: function () {
          return x;
        },
        BACKGROUND_COLOR: function () {
          return V;
        },
        BAR_DELIMITER: function () {
          return X;
        },
        BORDER_COLOR: function () {
          return P;
        },
        BOUNDARY_SELECTOR: function () {
          return c;
        },
        CHILDREN: function () {
          return z;
        },
        COLON_DELIMITER: function () {
          return j;
        },
        COLOR: function () {
          return D;
        },
        COMMA_DELIMITER: function () {
          return W;
        },
        CONFIG_UNIT: function () {
          return I;
        },
        CONFIG_VALUE: function () {
          return u;
        },
        CONFIG_X_UNIT: function () {
          return p;
        },
        CONFIG_X_VALUE: function () {
          return s;
        },
        CONFIG_Y_UNIT: function () {
          return E;
        },
        CONFIG_Y_VALUE: function () {
          return r;
        },
        CONFIG_Z_UNIT: function () {
          return T;
        },
        CONFIG_Z_VALUE: function () {
          return f;
        },
        DISPLAY: function () {
          return F;
        },
        EXPRESSION_ELEMENT: function () {
          return et;
        },
        FILTER: function () {
          return k;
        },
        FLEX: function () {
          return Q;
        },
        FONT_VARIATION_SETTINGS: function () {
          return w;
        },
        HEIGHT: function () {
          return B;
        },
        HTML_ELEMENT: function () {
          return J;
        },
        IMMEDIATE_CHILDREN: function () {
          return $;
        },
        IX2_ID_DELIMITER: function () {
          return i;
        },
        OPACITY: function () {
          return U;
        },
        PARENT: function () {
          return K;
        },
        PLAIN_OBJECT: function () {
          return ee;
        },
        PRESERVE_3D: function () {
          return Z;
        },
        RENDER_GENERAL: function () {
          return en;
        },
        RENDER_PLUGIN: function () {
          return el;
        },
        RENDER_STYLE: function () {
          return ei;
        },
        RENDER_TRANSFORM: function () {
          return ea;
        },
        ROTATE_X: function () {
          return N;
        },
        ROTATE_Y: function () {
          return A;
        },
        ROTATE_Z: function () {
          return S;
        },
        SCALE_3D: function () {
          return _;
        },
        SCALE_X: function () {
          return v;
        },
        SCALE_Y: function () {
          return R;
        },
        SCALE_Z: function () {
          return L;
        },
        SIBLINGS: function () {
          return q;
        },
        SKEW: function () {
          return h;
        },
        SKEW_X: function () {
          return M;
        },
        SKEW_Y: function () {
          return C;
        },
        TRANSFORM: function () {
          return y;
        },
        TRANSLATE_3D: function () {
          return O;
        },
        TRANSLATE_X: function () {
          return m;
        },
        TRANSLATE_Y: function () {
          return g;
        },
        TRANSLATE_Z: function () {
          return b;
        },
        WF_PAGE: function () {
          return l;
        },
        WIDTH: function () {
          return G;
        },
        WILL_CHANGE: function () {
          return Y;
        },
        W_MOD_IX: function () {
          return o;
        },
        W_MOD_JS: function () {
          return d;
        },
      };
      for (var n in a)
        Object.defineProperty(t, n, { enumerable: !0, get: a[n] });
      let i = "|",
        l = "data-wf-page",
        d = "w-mod-js",
        o = "w-mod-ix",
        c = ".w-dyn-item",
        s = "xValue",
        r = "yValue",
        f = "zValue",
        u = "value",
        p = "xUnit",
        E = "yUnit",
        T = "zUnit",
        I = "unit",
        y = "transform",
        m = "translateX",
        g = "translateY",
        b = "translateZ",
        O = "translate3d",
        v = "scaleX",
        R = "scaleY",
        L = "scaleZ",
        _ = "scale3d",
        N = "rotateX",
        A = "rotateY",
        S = "rotateZ",
        h = "skew",
        M = "skewX",
        C = "skewY",
        U = "opacity",
        k = "filter",
        w = "font-variation-settings",
        G = "width",
        B = "height",
        V = "backgroundColor",
        x = "background",
        P = "borderColor",
        D = "color",
        F = "display",
        Q = "flex",
        Y = "willChange",
        H = "AUTO",
        W = ",",
        j = ":",
        X = "|",
        z = "CHILDREN",
        $ = "IMMEDIATE_CHILDREN",
        q = "SIBLINGS",
        K = "PARENT",
        Z = "preserve-3d",
        J = "HTML_ELEMENT",
        ee = "PLAIN_OBJECT",
        et = "EXPRESSION_ELEMENT",
        ea = "RENDER_TRANSFORM",
        en = "RENDER_GENERAL",
        ei = "RENDER_STYLE",
        el = "RENDER_PLUGIN";
    },
    262: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        ActionAppliesTo: function () {
          return l;
        },
        ActionTypeConsts: function () {
          return i;
        },
      };
      for (var n in a)
        Object.defineProperty(t, n, { enumerable: !0, get: a[n] });
      let i = {
          TRANSFORM_MOVE: "TRANSFORM_MOVE",
          TRANSFORM_SCALE: "TRANSFORM_SCALE",
          TRANSFORM_ROTATE: "TRANSFORM_ROTATE",
          TRANSFORM_SKEW: "TRANSFORM_SKEW",
          STYLE_OPACITY: "STYLE_OPACITY",
          STYLE_SIZE: "STYLE_SIZE",
          STYLE_FILTER: "STYLE_FILTER",
          STYLE_FONT_VARIATION: "STYLE_FONT_VARIATION",
          STYLE_BACKGROUND_COLOR: "STYLE_BACKGROUND_COLOR",
          STYLE_BORDER: "STYLE_BORDER",
          STYLE_TEXT_COLOR: "STYLE_TEXT_COLOR",
          OBJECT_VALUE: "OBJECT_VALUE",
          PLUGIN_LOTTIE: "PLUGIN_LOTTIE",
          PLUGIN_SPLINE: "PLUGIN_SPLINE",
          PLUGIN_RIVE: "PLUGIN_RIVE",
          PLUGIN_VARIABLE: "PLUGIN_VARIABLE",
          GENERAL_DISPLAY: "GENERAL_DISPLAY",
          GENERAL_START_ACTION: "GENERAL_START_ACTION",
          GENERAL_CONTINUOUS_ACTION: "GENERAL_CONTINUOUS_ACTION",
          GENERAL_COMBO_CLASS: "GENERAL_COMBO_CLASS",
          GENERAL_STOP_ACTION: "GENERAL_STOP_ACTION",
          GENERAL_LOOP: "GENERAL_LOOP",
          STYLE_BOX_SHADOW: "STYLE_BOX_SHADOW",
        },
        l = {
          ELEMENT: "ELEMENT",
          ELEMENT_CLASS: "ELEMENT_CLASS",
          TRIGGER_ELEMENT: "TRIGGER_ELEMENT",
        };
    },
    7087: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        ActionTypeConsts: function () {
          return d.ActionTypeConsts;
        },
        IX2EngineActionTypes: function () {
          return o;
        },
        IX2EngineConstants: function () {
          return c;
        },
        QuickEffectIds: function () {
          return l.QuickEffectIds;
        },
      };
      for (var i in n)
        Object.defineProperty(t, i, { enumerable: !0, get: n[i] });
      let l = s(a(1833), t),
        d = s(a(262), t);
      s(a(8704), t), s(a(3213), t);
      let o = f(a(8023)),
        c = f(a(2686));
      function s(e, t) {
        return (
          Object.keys(e).forEach(function (a) {
            "default" === a ||
              Object.prototype.hasOwnProperty.call(t, a) ||
              Object.defineProperty(t, a, {
                enumerable: !0,
                get: function () {
                  return e[a];
                },
              });
          }),
          e
        );
      }
      function r(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          a = new WeakMap();
        return (r = function (e) {
          return e ? a : t;
        })(e);
      }
      function f(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || ("object" != typeof e && "function" != typeof e))
          return { default: e };
        var a = r(t);
        if (a && a.has(e)) return a.get(e);
        var n = { __proto__: null },
          i = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var l in e)
          if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
            var d = i ? Object.getOwnPropertyDescriptor(e, l) : null;
            d && (d.get || d.set)
              ? Object.defineProperty(n, l, d)
              : (n[l] = e[l]);
          }
        return (n.default = e), a && a.set(e, n), n;
      }
    },
    3213: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ReducedMotionTypes", {
          enumerable: !0,
          get: function () {
            return r;
          },
        });
      let {
          TRANSFORM_MOVE: n,
          TRANSFORM_SCALE: i,
          TRANSFORM_ROTATE: l,
          TRANSFORM_SKEW: d,
          STYLE_SIZE: o,
          STYLE_FILTER: c,
          STYLE_FONT_VARIATION: s,
        } = a(262).ActionTypeConsts,
        r = { [n]: !0, [i]: !0, [l]: !0, [d]: !0, [o]: !0, [c]: !0, [s]: !0 };
    },
    1833: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        EventAppliesTo: function () {
          return l;
        },
        EventBasedOn: function () {
          return d;
        },
        EventContinuousMouseAxes: function () {
          return o;
        },
        EventLimitAffectedElements: function () {
          return c;
        },
        EventTypeConsts: function () {
          return i;
        },
        QuickEffectDirectionConsts: function () {
          return r;
        },
        QuickEffectIds: function () {
          return s;
        },
      };
      for (var n in a)
        Object.defineProperty(t, n, { enumerable: !0, get: a[n] });
      let i = {
          NAVBAR_OPEN: "NAVBAR_OPEN",
          NAVBAR_CLOSE: "NAVBAR_CLOSE",
          TAB_ACTIVE: "TAB_ACTIVE",
          TAB_INACTIVE: "TAB_INACTIVE",
          SLIDER_ACTIVE: "SLIDER_ACTIVE",
          SLIDER_INACTIVE: "SLIDER_INACTIVE",
          DROPDOWN_OPEN: "DROPDOWN_OPEN",
          DROPDOWN_CLOSE: "DROPDOWN_CLOSE",
          MOUSE_CLICK: "MOUSE_CLICK",
          MOUSE_SECOND_CLICK: "MOUSE_SECOND_CLICK",
          MOUSE_DOWN: "MOUSE_DOWN",
          MOUSE_UP: "MOUSE_UP",
          MOUSE_OVER: "MOUSE_OVER",
          MOUSE_OUT: "MOUSE_OUT",
          MOUSE_MOVE: "MOUSE_MOVE",
          MOUSE_MOVE_IN_VIEWPORT: "MOUSE_MOVE_IN_VIEWPORT",
          SCROLL_INTO_VIEW: "SCROLL_INTO_VIEW",
          SCROLL_OUT_OF_VIEW: "SCROLL_OUT_OF_VIEW",
          SCROLLING_IN_VIEW: "SCROLLING_IN_VIEW",
          ECOMMERCE_CART_OPEN: "ECOMMERCE_CART_OPEN",
          ECOMMERCE_CART_CLOSE: "ECOMMERCE_CART_CLOSE",
          PAGE_START: "PAGE_START",
          PAGE_FINISH: "PAGE_FINISH",
          PAGE_SCROLL_UP: "PAGE_SCROLL_UP",
          PAGE_SCROLL_DOWN: "PAGE_SCROLL_DOWN",
          PAGE_SCROLL: "PAGE_SCROLL",
        },
        l = { ELEMENT: "ELEMENT", CLASS: "CLASS", PAGE: "PAGE" },
        d = { ELEMENT: "ELEMENT", VIEWPORT: "VIEWPORT" },
        o = { X_AXIS: "X_AXIS", Y_AXIS: "Y_AXIS" },
        c = {
          CHILDREN: "CHILDREN",
          SIBLINGS: "SIBLINGS",
          IMMEDIATE_CHILDREN: "IMMEDIATE_CHILDREN",
        },
        s = {
          FADE_EFFECT: "FADE_EFFECT",
          SLIDE_EFFECT: "SLIDE_EFFECT",
          GROW_EFFECT: "GROW_EFFECT",
          SHRINK_EFFECT: "SHRINK_EFFECT",
          SPIN_EFFECT: "SPIN_EFFECT",
          FLY_EFFECT: "FLY_EFFECT",
          POP_EFFECT: "POP_EFFECT",
          FLIP_EFFECT: "FLIP_EFFECT",
          JIGGLE_EFFECT: "JIGGLE_EFFECT",
          PULSE_EFFECT: "PULSE_EFFECT",
          DROP_EFFECT: "DROP_EFFECT",
          BLINK_EFFECT: "BLINK_EFFECT",
          BOUNCE_EFFECT: "BOUNCE_EFFECT",
          FLIP_LEFT_TO_RIGHT_EFFECT: "FLIP_LEFT_TO_RIGHT_EFFECT",
          FLIP_RIGHT_TO_LEFT_EFFECT: "FLIP_RIGHT_TO_LEFT_EFFECT",
          RUBBER_BAND_EFFECT: "RUBBER_BAND_EFFECT",
          JELLO_EFFECT: "JELLO_EFFECT",
          GROW_BIG_EFFECT: "GROW_BIG_EFFECT",
          SHRINK_BIG_EFFECT: "SHRINK_BIG_EFFECT",
          PLUGIN_LOTTIE_EFFECT: "PLUGIN_LOTTIE_EFFECT",
        },
        r = {
          LEFT: "LEFT",
          RIGHT: "RIGHT",
          BOTTOM: "BOTTOM",
          TOP: "TOP",
          BOTTOM_LEFT: "BOTTOM_LEFT",
          BOTTOM_RIGHT: "BOTTOM_RIGHT",
          TOP_RIGHT: "TOP_RIGHT",
          TOP_LEFT: "TOP_LEFT",
          CLOCKWISE: "CLOCKWISE",
          COUNTER_CLOCKWISE: "COUNTER_CLOCKWISE",
        };
    },
    8704: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "InteractionTypeConsts", {
          enumerable: !0,
          get: function () {
            return a;
          },
        });
      let a = {
        MOUSE_CLICK_INTERACTION: "MOUSE_CLICK_INTERACTION",
        MOUSE_HOVER_INTERACTION: "MOUSE_HOVER_INTERACTION",
        MOUSE_MOVE_INTERACTION: "MOUSE_MOVE_INTERACTION",
        SCROLL_INTO_VIEW_INTERACTION: "SCROLL_INTO_VIEW_INTERACTION",
        SCROLLING_IN_VIEW_INTERACTION: "SCROLLING_IN_VIEW_INTERACTION",
        MOUSE_MOVE_IN_VIEWPORT_INTERACTION:
          "MOUSE_MOVE_IN_VIEWPORT_INTERACTION",
        PAGE_IS_SCROLLING_INTERACTION: "PAGE_IS_SCROLLING_INTERACTION",
        PAGE_LOAD_INTERACTION: "PAGE_LOAD_INTERACTION",
        PAGE_SCROLLED_INTERACTION: "PAGE_SCROLLED_INTERACTION",
        NAVBAR_INTERACTION: "NAVBAR_INTERACTION",
        DROPDOWN_INTERACTION: "DROPDOWN_INTERACTION",
        ECOMMERCE_CART_INTERACTION: "ECOMMERCE_CART_INTERACTION",
        TAB_INTERACTION: "TAB_INTERACTION",
        SLIDER_INTERACTION: "SLIDER_INTERACTION",
      };
    },
    380: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "normalizeColor", {
          enumerable: !0,
          get: function () {
            return n;
          },
        });
      let a = {
        aliceblue: "#F0F8FF",
        antiquewhite: "#FAEBD7",
        aqua: "#00FFFF",
        aquamarine: "#7FFFD4",
        azure: "#F0FFFF",
        beige: "#F5F5DC",
        bisque: "#FFE4C4",
        black: "#000000",
        blanchedalmond: "#FFEBCD",
        blue: "#0000FF",
        blueviolet: "#8A2BE2",
        brown: "#A52A2A",
        burlywood: "#DEB887",
        cadetblue: "#5F9EA0",
        chartreuse: "#7FFF00",
        chocolate: "#D2691E",
        coral: "#FF7F50",
        cornflowerblue: "#6495ED",
        cornsilk: "#FFF8DC",
        crimson: "#DC143C",
        cyan: "#00FFFF",
        darkblue: "#00008B",
        darkcyan: "#008B8B",
        darkgoldenrod: "#B8860B",
        darkgray: "#A9A9A9",
        darkgreen: "#006400",
        darkgrey: "#A9A9A9",
        darkkhaki: "#BDB76B",
        darkmagenta: "#8B008B",
        darkolivegreen: "#556B2F",
        darkorange: "#FF8C00",
        darkorchid: "#9932CC",
        darkred: "#8B0000",
        darksalmon: "#E9967A",
        darkseagreen: "#8FBC8F",
        darkslateblue: "#483D8B",
        darkslategray: "#2F4F4F",
        darkslategrey: "#2F4F4F",
        darkturquoise: "#00CED1",
        darkviolet: "#9400D3",
        deeppink: "#FF1493",
        deepskyblue: "#00BFFF",
        dimgray: "#696969",
        dimgrey: "#696969",
        dodgerblue: "#1E90FF",
        firebrick: "#B22222",
        floralwhite: "#FFFAF0",
        forestgreen: "#228B22",
        fuchsia: "#FF00FF",
        gainsboro: "#DCDCDC",
        ghostwhite: "#F8F8FF",
        gold: "#FFD700",
        goldenrod: "#DAA520",
        gray: "#808080",
        green: "#008000",
        greenyellow: "#ADFF2F",
        grey: "#808080",
        honeydew: "#F0FFF0",
        hotpink: "#FF69B4",
        indianred: "#CD5C5C",
        indigo: "#4B0082",
        ivory: "#FFFFF0",
        khaki: "#F0E68C",
        lavender: "#E6E6FA",
        lavenderblush: "#FFF0F5",
        lawngreen: "#7CFC00",
        lemonchiffon: "#FFFACD",
        lightblue: "#ADD8E6",
        lightcoral: "#F08080",
        lightcyan: "#E0FFFF",
        lightgoldenrodyellow: "#FAFAD2",
        lightgray: "#D3D3D3",
        lightgreen: "#90EE90",
        lightgrey: "#D3D3D3",
        lightpink: "#FFB6C1",
        lightsalmon: "#FFA07A",
        lightseagreen: "#20B2AA",
        lightskyblue: "#87CEFA",
        lightslategray: "#778899",
        lightslategrey: "#778899",
        lightsteelblue: "#B0C4DE",
        lightyellow: "#FFFFE0",
        lime: "#00FF00",
        limegreen: "#32CD32",
        linen: "#FAF0E6",
        magenta: "#FF00FF",
        maroon: "#800000",
        mediumaquamarine: "#66CDAA",
        mediumblue: "#0000CD",
        mediumorchid: "#BA55D3",
        mediumpurple: "#9370DB",
        mediumseagreen: "#3CB371",
        mediumslateblue: "#7B68EE",
        mediumspringgreen: "#00FA9A",
        mediumturquoise: "#48D1CC",
        mediumvioletred: "#C71585",
        midnightblue: "#191970",
        mintcream: "#F5FFFA",
        mistyrose: "#FFE4E1",
        moccasin: "#FFE4B5",
        navajowhite: "#FFDEAD",
        navy: "#000080",
        oldlace: "#FDF5E6",
        olive: "#808000",
        olivedrab: "#6B8E23",
        orange: "#FFA500",
        orangered: "#FF4500",
        orchid: "#DA70D6",
        palegoldenrod: "#EEE8AA",
        palegreen: "#98FB98",
        paleturquoise: "#AFEEEE",
        palevioletred: "#DB7093",
        papayawhip: "#FFEFD5",
        peachpuff: "#FFDAB9",
        peru: "#CD853F",
        pink: "#FFC0CB",
        plum: "#DDA0DD",
        powderblue: "#B0E0E6",
        purple: "#800080",
        rebeccapurple: "#663399",
        red: "#FF0000",
        rosybrown: "#BC8F8F",
        royalblue: "#4169E1",
        saddlebrown: "#8B4513",
        salmon: "#FA8072",
        sandybrown: "#F4A460",
        seagreen: "#2E8B57",
        seashell: "#FFF5EE",
        sienna: "#A0522D",
        silver: "#C0C0C0",
        skyblue: "#87CEEB",
        slateblue: "#6A5ACD",
        slategray: "#708090",
        slategrey: "#708090",
        snow: "#FFFAFA",
        springgreen: "#00FF7F",
        steelblue: "#4682B4",
        tan: "#D2B48C",
        teal: "#008080",
        thistle: "#D8BFD8",
        tomato: "#FF6347",
        turquoise: "#40E0D0",
        violet: "#EE82EE",
        wheat: "#F5DEB3",
        white: "#FFFFFF",
        whitesmoke: "#F5F5F5",
        yellow: "#FFFF00",
        yellowgreen: "#9ACD32",
      };
      function n(e) {
        let t,
          n,
          i,
          l = 1,
          d = e.replace(/\s/g, "").toLowerCase(),
          o = ("string" == typeof a[d] ? a[d].toLowerCase() : null) || d;
        if (o.startsWith("#")) {
          let e = o.substring(1);
          3 === e.length || 4 === e.length
            ? ((t = parseInt(e[0] + e[0], 16)),
              (n = parseInt(e[1] + e[1], 16)),
              (i = parseInt(e[2] + e[2], 16)),
              4 === e.length && (l = parseInt(e[3] + e[3], 16) / 255))
            : (6 === e.length || 8 === e.length) &&
              ((t = parseInt(e.substring(0, 2), 16)),
              (n = parseInt(e.substring(2, 4), 16)),
              (i = parseInt(e.substring(4, 6), 16)),
              8 === e.length && (l = parseInt(e.substring(6, 8), 16) / 255));
        } else if (o.startsWith("rgba")) {
          let e = o.match(/rgba\(([^)]+)\)/)[1].split(",");
          (t = parseInt(e[0], 10)),
            (n = parseInt(e[1], 10)),
            (i = parseInt(e[2], 10)),
            (l = parseFloat(e[3]));
        } else if (o.startsWith("rgb")) {
          let e = o.match(/rgb\(([^)]+)\)/)[1].split(",");
          (t = parseInt(e[0], 10)),
            (n = parseInt(e[1], 10)),
            (i = parseInt(e[2], 10));
        } else if (o.startsWith("hsla")) {
          let e,
            a,
            d,
            c = o.match(/hsla\(([^)]+)\)/)[1].split(","),
            s = parseFloat(c[0]),
            r = parseFloat(c[1].replace("%", "")) / 100,
            f = parseFloat(c[2].replace("%", "")) / 100;
          l = parseFloat(c[3]);
          let u = (1 - Math.abs(2 * f - 1)) * r,
            p = u * (1 - Math.abs(((s / 60) % 2) - 1)),
            E = f - u / 2;
          s >= 0 && s < 60
            ? ((e = u), (a = p), (d = 0))
            : s >= 60 && s < 120
            ? ((e = p), (a = u), (d = 0))
            : s >= 120 && s < 180
            ? ((e = 0), (a = u), (d = p))
            : s >= 180 && s < 240
            ? ((e = 0), (a = p), (d = u))
            : s >= 240 && s < 300
            ? ((e = p), (a = 0), (d = u))
            : ((e = u), (a = 0), (d = p)),
            (t = Math.round((e + E) * 255)),
            (n = Math.round((a + E) * 255)),
            (i = Math.round((d + E) * 255));
        } else if (o.startsWith("hsl")) {
          let e,
            a,
            l,
            d = o.match(/hsl\(([^)]+)\)/)[1].split(","),
            c = parseFloat(d[0]),
            s = parseFloat(d[1].replace("%", "")) / 100,
            r = parseFloat(d[2].replace("%", "")) / 100,
            f = (1 - Math.abs(2 * r - 1)) * s,
            u = f * (1 - Math.abs(((c / 60) % 2) - 1)),
            p = r - f / 2;
          c >= 0 && c < 60
            ? ((e = f), (a = u), (l = 0))
            : c >= 60 && c < 120
            ? ((e = u), (a = f), (l = 0))
            : c >= 120 && c < 180
            ? ((e = 0), (a = f), (l = u))
            : c >= 180 && c < 240
            ? ((e = 0), (a = u), (l = f))
            : c >= 240 && c < 300
            ? ((e = u), (a = 0), (l = f))
            : ((e = f), (a = 0), (l = u)),
            (t = Math.round((e + p) * 255)),
            (n = Math.round((a + p) * 255)),
            (i = Math.round((l + p) * 255));
        }
        if (Number.isNaN(t) || Number.isNaN(n) || Number.isNaN(i))
          throw Error(
            `Invalid color in [ix2/shared/utils/normalizeColor.js] '${e}'`
          );
        return { red: t, green: n, blue: i, alpha: l };
      }
    },
    9468: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        IX2BrowserSupport: function () {
          return l;
        },
        IX2EasingUtils: function () {
          return o;
        },
        IX2Easings: function () {
          return d;
        },
        IX2ElementsReducer: function () {
          return c;
        },
        IX2VanillaPlugins: function () {
          return s;
        },
        IX2VanillaUtils: function () {
          return r;
        },
      };
      for (var i in n)
        Object.defineProperty(t, i, { enumerable: !0, get: n[i] });
      let l = u(a(2662)),
        d = u(a(8686)),
        o = u(a(3767)),
        c = u(a(5861)),
        s = u(a(1799)),
        r = u(a(4124));
      function f(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          a = new WeakMap();
        return (f = function (e) {
          return e ? a : t;
        })(e);
      }
      function u(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || ("object" != typeof e && "function" != typeof e))
          return { default: e };
        var a = f(t);
        if (a && a.has(e)) return a.get(e);
        var n = { __proto__: null },
          i = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var l in e)
          if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
            var d = i ? Object.getOwnPropertyDescriptor(e, l) : null;
            d && (d.get || d.set)
              ? Object.defineProperty(n, l, d)
              : (n[l] = e[l]);
          }
        return (n.default = e), a && a.set(e, n), n;
      }
    },
    2662: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n,
        i = {
          ELEMENT_MATCHES: function () {
            return s;
          },
          FLEX_PREFIXED: function () {
            return r;
          },
          IS_BROWSER_ENV: function () {
            return o;
          },
          TRANSFORM_PREFIXED: function () {
            return f;
          },
          TRANSFORM_STYLE_PREFIXED: function () {
            return p;
          },
          withBrowser: function () {
            return c;
          },
        };
      for (var l in i)
        Object.defineProperty(t, l, { enumerable: !0, get: i[l] });
      let d = (n = a(9777)) && n.__esModule ? n : { default: n },
        o = "undefined" != typeof window,
        c = (e, t) => (o ? e() : t),
        s = c(() =>
          (0, d.default)(
            [
              "matches",
              "matchesSelector",
              "mozMatchesSelector",
              "msMatchesSelector",
              "oMatchesSelector",
              "webkitMatchesSelector",
            ],
            (e) => e in Element.prototype
          )
        ),
        r = c(() => {
          let e = document.createElement("i"),
            t = [
              "flex",
              "-webkit-flex",
              "-ms-flexbox",
              "-moz-box",
              "-webkit-box",
            ];
          try {
            let { length: a } = t;
            for (let n = 0; n < a; n++) {
              let a = t[n];
              if (((e.style.display = a), e.style.display === a)) return a;
            }
            return "";
          } catch (e) {
            return "";
          }
        }, "flex"),
        f = c(() => {
          let e = document.createElement("i");
          if (null == e.style.transform) {
            let t = ["Webkit", "Moz", "ms"],
              { length: a } = t;
            for (let n = 0; n < a; n++) {
              let a = t[n] + "Transform";
              if (void 0 !== e.style[a]) return a;
            }
          }
          return "transform";
        }, "transform"),
        u = f.split("transform")[0],
        p = u ? u + "TransformStyle" : "transformStyle";
    },
    3767: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n,
        i = {
          applyEasing: function () {
            return f;
          },
          createBezierEasing: function () {
            return r;
          },
          optimizeFloat: function () {
            return s;
          },
        };
      for (var l in i)
        Object.defineProperty(t, l, { enumerable: !0, get: i[l] });
      let d = (function (e, t) {
          if (e && e.__esModule) return e;
          if (null === e || ("object" != typeof e && "function" != typeof e))
            return { default: e };
          var a = c(t);
          if (a && a.has(e)) return a.get(e);
          var n = { __proto__: null },
            i = Object.defineProperty && Object.getOwnPropertyDescriptor;
          for (var l in e)
            if ("default" !== l && Object.prototype.hasOwnProperty.call(e, l)) {
              var d = i ? Object.getOwnPropertyDescriptor(e, l) : null;
              d && (d.get || d.set)
                ? Object.defineProperty(n, l, d)
                : (n[l] = e[l]);
            }
          return (n.default = e), a && a.set(e, n), n;
        })(a(8686)),
        o = (n = a(1361)) && n.__esModule ? n : { default: n };
      function c(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          a = new WeakMap();
        return (c = function (e) {
          return e ? a : t;
        })(e);
      }
      function s(e, t = 5, a = 10) {
        let n = Math.pow(a, t),
          i = Number(Math.round(e * n) / n);
        return Math.abs(i) > 1e-4 ? i : 0;
      }
      function r(e) {
        return (0, o.default)(...e);
      }
      function f(e, t, a) {
        return 0 === t
          ? 0
          : 1 === t
          ? 1
          : a
          ? s(t > 0 ? a(t) : t)
          : s(t > 0 && e && d[e] ? d[e](t) : t);
      }
    },
    8686: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n,
        i = {
          bounce: function () {
            return Q;
          },
          bouncePast: function () {
            return Y;
          },
          ease: function () {
            return o;
          },
          easeIn: function () {
            return c;
          },
          easeInOut: function () {
            return r;
          },
          easeOut: function () {
            return s;
          },
          inBack: function () {
            return k;
          },
          inCirc: function () {
            return h;
          },
          inCubic: function () {
            return E;
          },
          inElastic: function () {
            return B;
          },
          inExpo: function () {
            return N;
          },
          inOutBack: function () {
            return G;
          },
          inOutCirc: function () {
            return C;
          },
          inOutCubic: function () {
            return I;
          },
          inOutElastic: function () {
            return x;
          },
          inOutExpo: function () {
            return S;
          },
          inOutQuad: function () {
            return p;
          },
          inOutQuart: function () {
            return g;
          },
          inOutQuint: function () {
            return v;
          },
          inOutSine: function () {
            return _;
          },
          inQuad: function () {
            return f;
          },
          inQuart: function () {
            return y;
          },
          inQuint: function () {
            return b;
          },
          inSine: function () {
            return R;
          },
          outBack: function () {
            return w;
          },
          outBounce: function () {
            return U;
          },
          outCirc: function () {
            return M;
          },
          outCubic: function () {
            return T;
          },
          outElastic: function () {
            return V;
          },
          outExpo: function () {
            return A;
          },
          outQuad: function () {
            return u;
          },
          outQuart: function () {
            return m;
          },
          outQuint: function () {
            return O;
          },
          outSine: function () {
            return L;
          },
          swingFrom: function () {
            return D;
          },
          swingFromTo: function () {
            return P;
          },
          swingTo: function () {
            return F;
          },
        };
      for (var l in i)
        Object.defineProperty(t, l, { enumerable: !0, get: i[l] });
      let d = (n = a(1361)) && n.__esModule ? n : { default: n },
        o = (0, d.default)(0.25, 0.1, 0.25, 1),
        c = (0, d.default)(0.42, 0, 1, 1),
        s = (0, d.default)(0, 0, 0.58, 1),
        r = (0, d.default)(0.42, 0, 0.58, 1);
      function f(e) {
        return Math.pow(e, 2);
      }
      function u(e) {
        return -(Math.pow(e - 1, 2) - 1);
      }
      function p(e) {
        return (e /= 0.5) < 1
          ? 0.5 * Math.pow(e, 2)
          : -0.5 * ((e -= 2) * e - 2);
      }
      function E(e) {
        return Math.pow(e, 3);
      }
      function T(e) {
        return Math.pow(e - 1, 3) + 1;
      }
      function I(e) {
        return (e /= 0.5) < 1
          ? 0.5 * Math.pow(e, 3)
          : 0.5 * (Math.pow(e - 2, 3) + 2);
      }
      function y(e) {
        return Math.pow(e, 4);
      }
      function m(e) {
        return -(Math.pow(e - 1, 4) - 1);
      }
      function g(e) {
        return (e /= 0.5) < 1
          ? 0.5 * Math.pow(e, 4)
          : -0.5 * ((e -= 2) * Math.pow(e, 3) - 2);
      }
      function b(e) {
        return Math.pow(e, 5);
      }
      function O(e) {
        return Math.pow(e - 1, 5) + 1;
      }
      function v(e) {
        return (e /= 0.5) < 1
          ? 0.5 * Math.pow(e, 5)
          : 0.5 * (Math.pow(e - 2, 5) + 2);
      }
      function R(e) {
        return -Math.cos((Math.PI / 2) * e) + 1;
      }
      function L(e) {
        return Math.sin((Math.PI / 2) * e);
      }
      function _(e) {
        return -0.5 * (Math.cos(Math.PI * e) - 1);
      }
      function N(e) {
        return 0 === e ? 0 : Math.pow(2, 10 * (e - 1));
      }
      function A(e) {
        return 1 === e ? 1 : -Math.pow(2, -10 * e) + 1;
      }
      function S(e) {
        return 0 === e
          ? 0
          : 1 === e
          ? 1
          : (e /= 0.5) < 1
          ? 0.5 * Math.pow(2, 10 * (e - 1))
          : 0.5 * (-Math.pow(2, -10 * --e) + 2);
      }
      function h(e) {
        return -(Math.sqrt(1 - e * e) - 1);
      }
      function M(e) {
        return Math.sqrt(1 - Math.pow(e - 1, 2));
      }
      function C(e) {
        return (e /= 0.5) < 1
          ? -0.5 * (Math.sqrt(1 - e * e) - 1)
          : 0.5 * (Math.sqrt(1 - (e -= 2) * e) + 1);
      }
      function U(e) {
        return e < 1 / 2.75
          ? 7.5625 * e * e
          : e < 2 / 2.75
          ? 7.5625 * (e -= 1.5 / 2.75) * e + 0.75
          : e < 2.5 / 2.75
          ? 7.5625 * (e -= 2.25 / 2.75) * e + 0.9375
          : 7.5625 * (e -= 2.625 / 2.75) * e + 0.984375;
      }
      function k(e) {
        return e * e * (2.70158 * e - 1.70158);
      }
      function w(e) {
        return (e -= 1) * e * (2.70158 * e + 1.70158) + 1;
      }
      function G(e) {
        let t = 1.70158;
        return (e /= 0.5) < 1
          ? 0.5 * (e * e * (((t *= 1.525) + 1) * e - t))
          : 0.5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2);
      }
      function B(e) {
        let t = 1.70158,
          a = 0,
          n = 1;
        return 0 === e
          ? 0
          : 1 === e
          ? 1
          : (a || (a = 0.3),
            n < 1
              ? ((n = 1), (t = a / 4))
              : (t = (a / (2 * Math.PI)) * Math.asin(1 / n)),
            -(
              n *
              Math.pow(2, 10 * (e -= 1)) *
              Math.sin((2 * Math.PI * (e - t)) / a)
            ));
      }
      function V(e) {
        let t = 1.70158,
          a = 0,
          n = 1;
        return 0 === e
          ? 0
          : 1 === e
          ? 1
          : (a || (a = 0.3),
            n < 1
              ? ((n = 1), (t = a / 4))
              : (t = (a / (2 * Math.PI)) * Math.asin(1 / n)),
            n * Math.pow(2, -10 * e) * Math.sin((2 * Math.PI * (e - t)) / a) +
              1);
      }
      function x(e) {
        let t = 1.70158,
          a = 0,
          n = 1;
        return 0 === e
          ? 0
          : 2 == (e /= 0.5)
          ? 1
          : (a || (a = 0.3 * 1.5),
            n < 1
              ? ((n = 1), (t = a / 4))
              : (t = (a / (2 * Math.PI)) * Math.asin(1 / n)),
            e < 1)
          ? -0.5 *
            (n *
              Math.pow(2, 10 * (e -= 1)) *
              Math.sin((2 * Math.PI * (e - t)) / a))
          : n *
              Math.pow(2, -10 * (e -= 1)) *
              Math.sin((2 * Math.PI * (e - t)) / a) *
              0.5 +
            1;
      }
      function P(e) {
        let t = 1.70158;
        return (e /= 0.5) < 1
          ? 0.5 * (e * e * (((t *= 1.525) + 1) * e - t))
          : 0.5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2);
      }
      function D(e) {
        return e * e * (2.70158 * e - 1.70158);
      }
      function F(e) {
        return (e -= 1) * e * (2.70158 * e + 1.70158) + 1;
      }
      function Q(e) {
        return e < 1 / 2.75
          ? 7.5625 * e * e
          : e < 2 / 2.75
          ? 7.5625 * (e -= 1.5 / 2.75) * e + 0.75
          : e < 2.5 / 2.75
          ? 7.5625 * (e -= 2.25 / 2.75) * e + 0.9375
          : 7.5625 * (e -= 2.625 / 2.75) * e + 0.984375;
      }
      function Y(e) {
        return e < 1 / 2.75
          ? 7.5625 * e * e
          : e < 2 / 2.75
          ? 2 - (7.5625 * (e -= 1.5 / 2.75) * e + 0.75)
          : e < 2.5 / 2.75
          ? 2 - (7.5625 * (e -= 2.25 / 2.75) * e + 0.9375)
          : 2 - (7.5625 * (e -= 2.625 / 2.75) * e + 0.984375);
      }
    },
    1799: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        clearPlugin: function () {
          return T;
        },
        createPluginInstance: function () {
          return p;
        },
        getPluginConfig: function () {
          return s;
        },
        getPluginDestination: function () {
          return u;
        },
        getPluginDuration: function () {
          return f;
        },
        getPluginOrigin: function () {
          return r;
        },
        isPluginType: function () {
          return o;
        },
        renderPlugin: function () {
          return E;
        },
      };
      for (var i in n)
        Object.defineProperty(t, i, { enumerable: !0, get: n[i] });
      let l = a(2662),
        d = a(3690);
      function o(e) {
        return d.pluginMethodMap.has(e);
      }
      let c = (e) => (t) => {
          if (!l.IS_BROWSER_ENV) return () => null;
          let a = d.pluginMethodMap.get(t);
          if (!a) throw Error(`IX2 no plugin configured for: ${t}`);
          let n = a[e];
          if (!n) throw Error(`IX2 invalid plugin method: ${e}`);
          return n;
        },
        s = c("getPluginConfig"),
        r = c("getPluginOrigin"),
        f = c("getPluginDuration"),
        u = c("getPluginDestination"),
        p = c("createPluginInstance"),
        E = c("renderPlugin"),
        T = c("clearPlugin");
    },
    4124: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        cleanupHTMLElement: function () {
          return eW;
        },
        clearAllStyles: function () {
          return eQ;
        },
        clearObjectCache: function () {
          return ef;
        },
        getActionListProgress: function () {
          return e$;
        },
        getAffectedElements: function () {
          return eb;
        },
        getComputedStyle: function () {
          return eO;
        },
        getDestinationValues: function () {
          return eh;
        },
        getElementId: function () {
          return eT;
        },
        getInstanceId: function () {
          return ep;
        },
        getInstanceOrigin: function () {
          return e_;
        },
        getItemConfigByKey: function () {
          return eS;
        },
        getMaxDurationItemIndex: function () {
          return ez;
        },
        getNamespacedParameterId: function () {
          return eZ;
        },
        getRenderType: function () {
          return eM;
        },
        getStyleProp: function () {
          return eC;
        },
        mediaQueriesEqual: function () {
          return e0;
        },
        observeStore: function () {
          return em;
        },
        reduceListToGroup: function () {
          return eq;
        },
        reifyState: function () {
          return eI;
        },
        renderHTMLElement: function () {
          return eU;
        },
        shallowEqual: function () {
          return r.default;
        },
        shouldAllowMediaQuery: function () {
          return eJ;
        },
        shouldNamespaceEventParameter: function () {
          return eK;
        },
        stringifyTarget: function () {
          return e1;
        },
      };
      for (var i in n)
        Object.defineProperty(t, i, { enumerable: !0, get: n[i] });
      let l = T(a(4075)),
        d = T(a(1455)),
        o = T(a(5720)),
        c = a(1185),
        s = a(7087),
        r = T(a(7164)),
        f = a(3767),
        u = a(380),
        p = a(1799),
        E = a(2662);
      function T(e) {
        return e && e.__esModule ? e : { default: e };
      }
      let {
          BACKGROUND: I,
          TRANSFORM: y,
          TRANSLATE_3D: m,
          SCALE_3D: g,
          ROTATE_X: b,
          ROTATE_Y: O,
          ROTATE_Z: v,
          SKEW: R,
          PRESERVE_3D: L,
          FLEX: _,
          OPACITY: N,
          FILTER: A,
          FONT_VARIATION_SETTINGS: S,
          WIDTH: h,
          HEIGHT: M,
          BACKGROUND_COLOR: C,
          BORDER_COLOR: U,
          COLOR: k,
          CHILDREN: w,
          IMMEDIATE_CHILDREN: G,
          SIBLINGS: B,
          PARENT: V,
          DISPLAY: x,
          WILL_CHANGE: P,
          AUTO: D,
          COMMA_DELIMITER: F,
          COLON_DELIMITER: Q,
          BAR_DELIMITER: Y,
          RENDER_TRANSFORM: H,
          RENDER_GENERAL: W,
          RENDER_STYLE: j,
          RENDER_PLUGIN: X,
        } = s.IX2EngineConstants,
        {
          TRANSFORM_MOVE: z,
          TRANSFORM_SCALE: $,
          TRANSFORM_ROTATE: q,
          TRANSFORM_SKEW: K,
          STYLE_OPACITY: Z,
          STYLE_FILTER: J,
          STYLE_FONT_VARIATION: ee,
          STYLE_SIZE: et,
          STYLE_BACKGROUND_COLOR: ea,
          STYLE_BORDER: en,
          STYLE_TEXT_COLOR: ei,
          GENERAL_DISPLAY: el,
          OBJECT_VALUE: ed,
        } = s.ActionTypeConsts,
        eo = (e) => e.trim(),
        ec = Object.freeze({ [ea]: C, [en]: U, [ei]: k }),
        es = Object.freeze({
          [E.TRANSFORM_PREFIXED]: y,
          [C]: I,
          [N]: N,
          [A]: A,
          [h]: h,
          [M]: M,
          [S]: S,
        }),
        er = new Map();
      function ef() {
        er.clear();
      }
      let eu = 1;
      function ep() {
        return "i" + eu++;
      }
      let eE = 1;
      function eT(e, t) {
        for (let a in e) {
          let n = e[a];
          if (n && n.ref === t) return n.id;
        }
        return "e" + eE++;
      }
      function eI({ events: e, actionLists: t, site: a } = {}) {
        let n = (0, d.default)(
            e,
            (e, t) => {
              let { eventTypeId: a } = t;
              return e[a] || (e[a] = {}), (e[a][t.id] = t), e;
            },
            {}
          ),
          i = a && a.mediaQueries,
          l = [];
        return (
          i
            ? (l = i.map((e) => e.key))
            : ((i = []), console.warn("IX2 missing mediaQueries in site data")),
          {
            ixData: {
              events: e,
              actionLists: t,
              eventTypeMap: n,
              mediaQueries: i,
              mediaQueryKeys: l,
            },
          }
        );
      }
      let ey = (e, t) => e === t;
      function em({ store: e, select: t, onChange: a, comparator: n = ey }) {
        let { getState: i, subscribe: l } = e,
          d = l(function () {
            let l = t(i());
            if (null == l) return void d();
            n(l, o) || a((o = l), e);
          }),
          o = t(i());
        return d;
      }
      function eg(e) {
        let t = typeof e;
        if ("string" === t) return { id: e };
        if (null != e && "object" === t) {
          let {
            id: t,
            objectId: a,
            selector: n,
            selectorGuids: i,
            appliesTo: l,
            useEventTarget: d,
          } = e;
          return {
            id: t,
            objectId: a,
            selector: n,
            selectorGuids: i,
            appliesTo: l,
            useEventTarget: d,
          };
        }
        return {};
      }
      function eb({
        config: e,
        event: t,
        eventTarget: a,
        elementRoot: n,
        elementApi: i,
      }) {
        let l, d, o;
        if (!i) throw Error("IX2 missing elementApi");
        let { targets: c } = e;
        if (Array.isArray(c) && c.length > 0)
          return c.reduce(
            (e, l) =>
              e.concat(
                eb({
                  config: { target: l },
                  event: t,
                  eventTarget: a,
                  elementRoot: n,
                  elementApi: i,
                })
              ),
            []
          );
        let {
            getValidDocument: r,
            getQuerySelector: f,
            queryDocument: u,
            getChildElements: p,
            getSiblingElements: T,
            matchSelector: I,
            elementContains: y,
            isSiblingNode: m,
          } = i,
          { target: g } = e;
        if (!g) return [];
        let {
          id: b,
          objectId: O,
          selector: v,
          selectorGuids: R,
          appliesTo: L,
          useEventTarget: _,
        } = eg(g);
        if (O) return [er.has(O) ? er.get(O) : er.set(O, {}).get(O)];
        if (L === s.EventAppliesTo.PAGE) {
          let e = r(b);
          return e ? [e] : [];
        }
        let N = (t?.action?.config?.affectedElements ?? {})[b || v] || {},
          A = !!(N.id || N.selector),
          S = t && f(eg(t.target));
        if (
          (A
            ? ((l = N.limitAffectedElements), (d = S), (o = f(N)))
            : (d = o = f({ id: b, selector: v, selectorGuids: R })),
          t && _)
        ) {
          let e = a && (o || !0 === _) ? [a] : u(S);
          if (o) {
            if (_ === V) return u(o).filter((t) => e.some((e) => y(t, e)));
            if (_ === w) return u(o).filter((t) => e.some((e) => y(e, t)));
            if (_ === B) return u(o).filter((t) => e.some((e) => m(e, t)));
          }
          return e;
        }
        return null == d || null == o
          ? []
          : E.IS_BROWSER_ENV && n
          ? u(o).filter((e) => n.contains(e))
          : l === w
          ? u(d, o)
          : l === G
          ? p(u(d)).filter(I(o))
          : l === B
          ? T(u(d)).filter(I(o))
          : u(o);
      }
      function eO({ element: e, actionItem: t }) {
        if (!E.IS_BROWSER_ENV) return {};
        let { actionTypeId: a } = t;
        switch (a) {
          case et:
          case ea:
          case en:
          case ei:
          case el:
            return window.getComputedStyle(e);
          default:
            return {};
        }
      }
      let ev = /px/,
        eR = (e, t) =>
          t.reduce(
            (e, t) => (null == e[t.type] && (e[t.type] = ew[t.type]), e),
            e || {}
          ),
        eL = (e, t) =>
          t.reduce(
            (e, t) => (
              null == e[t.type] &&
                (e[t.type] = eG[t.type] || t.defaultValue || 0),
              e
            ),
            e || {}
          );
      function e_(e, t = {}, a = {}, n, i) {
        let { getStyle: d } = i,
          { actionTypeId: o } = n;
        if ((0, p.isPluginType)(o)) return (0, p.getPluginOrigin)(o)(t[o], n);
        switch (n.actionTypeId) {
          case z:
          case $:
          case q:
          case K:
            return t[n.actionTypeId] || ek[n.actionTypeId];
          case J:
            return eR(t[n.actionTypeId], n.config.filters);
          case ee:
            return eL(t[n.actionTypeId], n.config.fontVariations);
          case Z:
            return { value: (0, l.default)(parseFloat(d(e, N)), 1) };
          case et: {
            let t,
              i = d(e, h),
              o = d(e, M);
            return {
              widthValue:
                n.config.widthUnit === D
                  ? ev.test(i)
                    ? parseFloat(i)
                    : parseFloat(a.width)
                  : (0, l.default)(parseFloat(i), parseFloat(a.width)),
              heightValue:
                n.config.heightUnit === D
                  ? ev.test(o)
                    ? parseFloat(o)
                    : parseFloat(a.height)
                  : (0, l.default)(parseFloat(o), parseFloat(a.height)),
            };
          }
          case ea:
          case en:
          case ei:
            return (function ({
              element: e,
              actionTypeId: t,
              computedStyle: a,
              getStyle: n,
            }) {
              let i = ec[t],
                d = n(e, i),
                o = (function (e, t) {
                  let a = e.exec(t);
                  return a ? a[1] : "";
                })(eP, ex.test(d) ? d : a[i]).split(F);
              return {
                rValue: (0, l.default)(parseInt(o[0], 10), 255),
                gValue: (0, l.default)(parseInt(o[1], 10), 255),
                bValue: (0, l.default)(parseInt(o[2], 10), 255),
                aValue: (0, l.default)(parseFloat(o[3]), 1),
              };
            })({
              element: e,
              actionTypeId: n.actionTypeId,
              computedStyle: a,
              getStyle: d,
            });
          case el:
            return { value: (0, l.default)(d(e, x), a.display) };
          case ed:
            return t[n.actionTypeId] || { value: 0 };
          default:
            return;
        }
      }
      let eN = (e, t) => (t && (e[t.type] = t.value || 0), e),
        eA = (e, t) => (t && (e[t.type] = t.value || 0), e),
        eS = (e, t, a) => {
          if ((0, p.isPluginType)(e)) return (0, p.getPluginConfig)(e)(a, t);
          switch (e) {
            case J: {
              let e = (0, o.default)(a.filters, ({ type: e }) => e === t);
              return e ? e.value : 0;
            }
            case ee: {
              let e = (0, o.default)(
                a.fontVariations,
                ({ type: e }) => e === t
              );
              return e ? e.value : 0;
            }
            default:
              return a[t];
          }
        };
      function eh({ element: e, actionItem: t, elementApi: a }) {
        if ((0, p.isPluginType)(t.actionTypeId))
          return (0, p.getPluginDestination)(t.actionTypeId)(t.config);
        switch (t.actionTypeId) {
          case z:
          case $:
          case q:
          case K: {
            let { xValue: e, yValue: a, zValue: n } = t.config;
            return { xValue: e, yValue: a, zValue: n };
          }
          case et: {
            let { getStyle: n, setStyle: i, getProperty: l } = a,
              { widthUnit: d, heightUnit: o } = t.config,
              { widthValue: c, heightValue: s } = t.config;
            if (!E.IS_BROWSER_ENV) return { widthValue: c, heightValue: s };
            if (d === D) {
              let t = n(e, h);
              i(e, h, ""), (c = l(e, "offsetWidth")), i(e, h, t);
            }
            if (o === D) {
              let t = n(e, M);
              i(e, M, ""), (s = l(e, "offsetHeight")), i(e, M, t);
            }
            return { widthValue: c, heightValue: s };
          }
          case ea:
          case en:
          case ei: {
            let {
              rValue: n,
              gValue: i,
              bValue: l,
              aValue: d,
              globalSwatchId: o,
            } = t.config;
            if (o && o.startsWith("--")) {
              let { getStyle: t } = a,
                n = t(e, o),
                i = (0, u.normalizeColor)(n);
              return {
                rValue: i.red,
                gValue: i.green,
                bValue: i.blue,
                aValue: i.alpha,
              };
            }
            return { rValue: n, gValue: i, bValue: l, aValue: d };
          }
          case J:
            return t.config.filters.reduce(eN, {});
          case ee:
            return t.config.fontVariations.reduce(eA, {});
          default: {
            let { value: e } = t.config;
            return { value: e };
          }
        }
      }
      function eM(e) {
        return /^TRANSFORM_/.test(e)
          ? H
          : /^STYLE_/.test(e)
          ? j
          : /^GENERAL_/.test(e)
          ? W
          : /^PLUGIN_/.test(e)
          ? X
          : void 0;
      }
      function eC(e, t) {
        return e === j ? t.replace("STYLE_", "").toLowerCase() : null;
      }
      function eU(e, t, a, n, i, l, o, c, s) {
        switch (c) {
          case H:
            var r = e,
              f = t,
              u = a,
              T = i,
              I = o;
            let y = eV
                .map((e) => {
                  let t = ek[e],
                    {
                      xValue: a = t.xValue,
                      yValue: n = t.yValue,
                      zValue: i = t.zValue,
                      xUnit: l = "",
                      yUnit: d = "",
                      zUnit: o = "",
                    } = f[e] || {};
                  switch (e) {
                    case z:
                      return `${m}(${a}${l}, ${n}${d}, ${i}${o})`;
                    case $:
                      return `${g}(${a}${l}, ${n}${d}, ${i}${o})`;
                    case q:
                      return `${b}(${a}${l}) ${O}(${n}${d}) ${v}(${i}${o})`;
                    case K:
                      return `${R}(${a}${l}, ${n}${d})`;
                    default:
                      return "";
                  }
                })
                .join(" "),
              { setStyle: N } = I;
            eD(r, E.TRANSFORM_PREFIXED, I),
              N(r, E.TRANSFORM_PREFIXED, y),
              (function (
                { actionTypeId: e },
                { xValue: t, yValue: a, zValue: n }
              ) {
                return (
                  (e === z && void 0 !== n) ||
                  (e === $ && void 0 !== n) ||
                  (e === q && (void 0 !== t || void 0 !== a))
                );
              })(T, u) && N(r, E.TRANSFORM_STYLE_PREFIXED, L);
            return;
          case j:
            return (function (e, t, a, n, i, l) {
              let { setStyle: o } = l;
              switch (n.actionTypeId) {
                case et: {
                  let { widthUnit: t = "", heightUnit: i = "" } = n.config,
                    { widthValue: d, heightValue: c } = a;
                  void 0 !== d &&
                    (t === D && (t = "px"), eD(e, h, l), o(e, h, d + t)),
                    void 0 !== c &&
                      (i === D && (i = "px"), eD(e, M, l), o(e, M, c + i));
                  break;
                }
                case J:
                  var c = n.config;
                  let s = (0, d.default)(
                      a,
                      (e, t, a) => `${e} ${a}(${t}${eB(a, c)})`,
                      ""
                    ),
                    { setStyle: r } = l;
                  eD(e, A, l), r(e, A, s);
                  break;
                case ee:
                  n.config;
                  let f = (0, d.default)(
                      a,
                      (e, t, a) => (e.push(`"${a}" ${t}`), e),
                      []
                    ).join(", "),
                    { setStyle: u } = l;
                  eD(e, S, l), u(e, S, f);
                  break;
                case ea:
                case en:
                case ei: {
                  let t = ec[n.actionTypeId],
                    i = Math.round(a.rValue),
                    d = Math.round(a.gValue),
                    c = Math.round(a.bValue),
                    s = a.aValue;
                  eD(e, t, l),
                    o(
                      e,
                      t,
                      s >= 1
                        ? `rgb(${i},${d},${c})`
                        : `rgba(${i},${d},${c},${s})`
                    );
                  break;
                }
                default: {
                  let { unit: t = "" } = n.config;
                  eD(e, i, l), o(e, i, a.value + t);
                }
              }
            })(e, 0, a, i, l, o);
          case W:
            var C = e,
              U = i,
              k = o;
            let { setStyle: w } = k;
            if (U.actionTypeId === el) {
              let { value: e } = U.config;
              w(C, x, e === _ && E.IS_BROWSER_ENV ? E.FLEX_PREFIXED : e);
            }
            return;
          case X: {
            let { actionTypeId: e } = i;
            if ((0, p.isPluginType)(e)) return (0, p.renderPlugin)(e)(s, t, i);
          }
        }
      }
      let ek = {
          [z]: Object.freeze({ xValue: 0, yValue: 0, zValue: 0 }),
          [$]: Object.freeze({ xValue: 1, yValue: 1, zValue: 1 }),
          [q]: Object.freeze({ xValue: 0, yValue: 0, zValue: 0 }),
          [K]: Object.freeze({ xValue: 0, yValue: 0 }),
        },
        ew = Object.freeze({
          blur: 0,
          "hue-rotate": 0,
          invert: 0,
          grayscale: 0,
          saturate: 100,
          sepia: 0,
          contrast: 100,
          brightness: 100,
        }),
        eG = Object.freeze({ wght: 0, opsz: 0, wdth: 0, slnt: 0 }),
        eB = (e, t) => {
          let a = (0, o.default)(t.filters, ({ type: t }) => t === e);
          if (a && a.unit) return a.unit;
          switch (e) {
            case "blur":
              return "px";
            case "hue-rotate":
              return "deg";
            default:
              return "%";
          }
        },
        eV = Object.keys(ek),
        ex = /^rgb/,
        eP = RegExp("rgba?\\(([^)]+)\\)");
      function eD(e, t, a) {
        if (!E.IS_BROWSER_ENV) return;
        let n = es[t];
        if (!n) return;
        let { getStyle: i, setStyle: l } = a,
          d = i(e, P);
        if (!d) return void l(e, P, n);
        let o = d.split(F).map(eo);
        -1 === o.indexOf(n) && l(e, P, o.concat(n).join(F));
      }
      function eF(e, t, a) {
        if (!E.IS_BROWSER_ENV) return;
        let n = es[t];
        if (!n) return;
        let { getStyle: i, setStyle: l } = a,
          d = i(e, P);
        d &&
          -1 !== d.indexOf(n) &&
          l(
            e,
            P,
            d
              .split(F)
              .map(eo)
              .filter((e) => e !== n)
              .join(F)
          );
      }
      function eQ({ store: e, elementApi: t }) {
        let { ixData: a } = e.getState(),
          { events: n = {}, actionLists: i = {} } = a;
        Object.keys(n).forEach((e) => {
          let a = n[e],
            { config: l } = a.action,
            { actionListId: d } = l,
            o = i[d];
          o && eY({ actionList: o, event: a, elementApi: t });
        }),
          Object.keys(i).forEach((e) => {
            eY({ actionList: i[e], elementApi: t });
          });
      }
      function eY({ actionList: e = {}, event: t, elementApi: a }) {
        let { actionItemGroups: n, continuousParameterGroups: i } = e;
        n &&
          n.forEach((e) => {
            eH({ actionGroup: e, event: t, elementApi: a });
          }),
          i &&
            i.forEach((e) => {
              let { continuousActionGroups: n } = e;
              n.forEach((e) => {
                eH({ actionGroup: e, event: t, elementApi: a });
              });
            });
      }
      function eH({ actionGroup: e, event: t, elementApi: a }) {
        let { actionItems: n } = e;
        n.forEach((e) => {
          let n,
            { actionTypeId: i, config: l } = e;
          (n = (0, p.isPluginType)(i)
            ? (t) => (0, p.clearPlugin)(i)(t, e)
            : ej({ effect: eX, actionTypeId: i, elementApi: a })),
            eb({ config: l, event: t, elementApi: a }).forEach(n);
        });
      }
      function eW(e, t, a) {
        let { setStyle: n, getStyle: i } = a,
          { actionTypeId: l } = t;
        if (l === et) {
          let { config: a } = t;
          a.widthUnit === D && n(e, h, ""), a.heightUnit === D && n(e, M, "");
        }
        i(e, P) && ej({ effect: eF, actionTypeId: l, elementApi: a })(e);
      }
      let ej =
        ({ effect: e, actionTypeId: t, elementApi: a }) =>
        (n) => {
          switch (t) {
            case z:
            case $:
            case q:
            case K:
              e(n, E.TRANSFORM_PREFIXED, a);
              break;
            case J:
              e(n, A, a);
              break;
            case ee:
              e(n, S, a);
              break;
            case Z:
              e(n, N, a);
              break;
            case et:
              e(n, h, a), e(n, M, a);
              break;
            case ea:
            case en:
            case ei:
              e(n, ec[t], a);
              break;
            case el:
              e(n, x, a);
          }
        };
      function eX(e, t, a) {
        let { setStyle: n } = a;
        eF(e, t, a),
          n(e, t, ""),
          t === E.TRANSFORM_PREFIXED && n(e, E.TRANSFORM_STYLE_PREFIXED, "");
      }
      function ez(e) {
        let t = 0,
          a = 0;
        return (
          e.forEach((e, n) => {
            let { config: i } = e,
              l = i.delay + i.duration;
            l >= t && ((t = l), (a = n));
          }),
          a
        );
      }
      function e$(e, t) {
        let { actionItemGroups: a, useFirstGroupAsInitialState: n } = e,
          { actionItem: i, verboseTimeElapsed: l = 0 } = t,
          d = 0,
          o = 0;
        return (
          a.forEach((e, t) => {
            if (n && 0 === t) return;
            let { actionItems: a } = e,
              c = a[ez(a)],
              { config: s, actionTypeId: r } = c;
            i.id === c.id && (o = d + l);
            let f = eM(r) === W ? 0 : s.duration;
            d += s.delay + f;
          }),
          d > 0 ? (0, f.optimizeFloat)(o / d) : 0
        );
      }
      function eq({ actionList: e, actionItemId: t, rawData: a }) {
        let { actionItemGroups: n, continuousParameterGroups: i } = e,
          l = [],
          d = (e) => (
            l.push((0, c.mergeIn)(e, ["config"], { delay: 0, duration: 0 })),
            e.id === t
          );
        return (
          n && n.some(({ actionItems: e }) => e.some(d)),
          i &&
            i.some((e) => {
              let { continuousActionGroups: t } = e;
              return t.some(({ actionItems: e }) => e.some(d));
            }),
          (0, c.setIn)(a, ["actionLists"], {
            [e.id]: { id: e.id, actionItemGroups: [{ actionItems: l }] },
          })
        );
      }
      function eK(e, { basedOn: t }) {
        return (
          (e === s.EventTypeConsts.SCROLLING_IN_VIEW &&
            (t === s.EventBasedOn.ELEMENT || null == t)) ||
          (e === s.EventTypeConsts.MOUSE_MOVE && t === s.EventBasedOn.ELEMENT)
        );
      }
      function eZ(e, t) {
        return e + Q + t;
      }
      function eJ(e, t) {
        return null == t || -1 !== e.indexOf(t);
      }
      function e0(e, t) {
        return (0, r.default)(e && e.sort(), t && t.sort());
      }
      function e1(e) {
        if ("string" == typeof e) return e;
        if (e.pluginElement && e.objectId)
          return e.pluginElement + Y + e.objectId;
        if (e.objectId) return e.objectId;
        let { id: t = "", selector: a = "", useEventTarget: n = "" } = e;
        return t + Y + a + Y + n;
      }
    },
    7164: function (e, t) {
      "use strict";
      function a(e, t) {
        return e === t
          ? 0 !== e || 0 !== t || 1 / e == 1 / t
          : e != e && t != t;
      }
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "default", {
          enumerable: !0,
          get: function () {
            return n;
          },
        });
      let n = function (e, t) {
        if (a(e, t)) return !0;
        if (
          "object" != typeof e ||
          null === e ||
          "object" != typeof t ||
          null === t
        )
          return !1;
        let n = Object.keys(e),
          i = Object.keys(t);
        if (n.length !== i.length) return !1;
        for (let i = 0; i < n.length; i++)
          if (!Object.hasOwn(t, n[i]) || !a(e[n[i]], t[n[i]])) return !1;
        return !0;
      };
    },
    5861: function (e, t, a) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        createElementState: function () {
          return R;
        },
        ixElements: function () {
          return v;
        },
        mergeActionState: function () {
          return L;
        },
      };
      for (var i in n)
        Object.defineProperty(t, i, { enumerable: !0, get: n[i] });
      let l = a(1185),
        d = a(7087),
        {
          HTML_ELEMENT: o,
          PLAIN_OBJECT: c,
          EXPRESSION_ELEMENT: s,
          CONFIG_X_VALUE: r,
          CONFIG_Y_VALUE: f,
          CONFIG_Z_VALUE: u,
          CONFIG_VALUE: p,
          CONFIG_X_UNIT: E,
          CONFIG_Y_UNIT: T,
          CONFIG_Z_UNIT: I,
          CONFIG_UNIT: y,
        } = d.IX2EngineConstants,
        {
          IX2_SESSION_STOPPED: m,
          IX2_INSTANCE_ADDED: g,
          IX2_ELEMENT_STATE_CHANGED: b,
        } = d.IX2EngineActionTypes,
        O = {},
        v = (e = O, t = {}) => {
          switch (t.type) {
            case m:
              return O;
            case g: {
              let {
                  elementId: a,
                  element: n,
                  origin: i,
                  actionItem: d,
                  refType: o,
                } = t.payload,
                { actionTypeId: c } = d,
                s = e;
              return (
                (0, l.getIn)(s, [a, n]) !== n && (s = R(s, n, o, a, d)),
                L(s, a, c, i, d)
              );
            }
            case b: {
              let {
                elementId: a,
                actionTypeId: n,
                current: i,
                actionItem: l,
              } = t.payload;
              return L(e, a, n, i, l);
            }
            default:
              return e;
          }
        };
      function R(e, t, a, n, i) {
        let d =
          a === c ? (0, l.getIn)(i, ["config", "target", "objectId"]) : null;
        return (0, l.mergeIn)(e, [n], { id: n, ref: t, refId: d, refType: a });
      }
      function L(e, t, a, n, i) {
        let d = (function (e) {
          let { config: t } = e;
          return _.reduce((e, a) => {
            let n = a[0],
              i = a[1],
              l = t[n],
              d = t[i];
            return null != l && null != d && (e[i] = d), e;
          }, {});
        })(i);
        return (0, l.mergeIn)(e, [t, "refState", a], n, d);
      }
      let _ = [
        [r, E],
        [f, T],
        [u, I],
        [p, y],
      ];
    },
    3224: function () {
      Webflow.require("ix2").init({
        events: {
          "e-28": {
            id: "e-28",
            name: "",
            animationType: "custom",
            eventTypeId: "TAB_ACTIVE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-9",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-29",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".process-tabs",
              originalId:
                "66fb138f8830dc37a4b53ea7|5b760c14-deed-ce04-d0e5-0fd1e357577e",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".process-tabs",
                originalId:
                  "66fb138f8830dc37a4b53ea7|5b760c14-deed-ce04-d0e5-0fd1e357577e",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19244e13a35,
          },
          "e-29": {
            id: "e-29",
            name: "",
            animationType: "custom",
            eventTypeId: "TAB_INACTIVE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-10",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-28",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".process-tabs",
              originalId:
                "66fb138f8830dc37a4b53ea7|5b760c14-deed-ce04-d0e5-0fd1e357577e",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".process-tabs",
                originalId:
                  "66fb138f8830dc37a4b53ea7|5b760c14-deed-ce04-d0e5-0fd1e357577e",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19244e13a35,
          },
          "e-54": {
            id: "e-54",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-13",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-55",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".fade-in",
              originalId:
                "66ebfd984234fb259fa972a5|6d60413a-396b-1f9c-4c17-89fbf1a095e5",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".fade-in",
                originalId:
                  "66ebfd984234fb259fa972a5|6d60413a-396b-1f9c-4c17-89fbf1a095e5",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 20,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19247fd3744,
          },
          "e-58": {
            id: "e-58",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-59",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192480e1bc2,
          },
          "e-59": {
            id: "e-59",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-58",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192480e1bc2,
          },
          "e-60": {
            id: "e-60",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-61",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192480e1d60,
          },
          "e-61": {
            id: "e-61",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-60",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192480e1d60,
          },
          "e-62": {
            id: "e-62",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-63",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192480e1f12,
          },
          "e-63": {
            id: "e-63",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-62",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192480e1f12,
          },
          "e-68": {
            id: "e-68",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-69",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbadf3ce3426cdd90fe674|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbadf3ce3426cdd90fe674|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248590a70,
          },
          "e-69": {
            id: "e-69",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-68",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbadf3ce3426cdd90fe674|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbadf3ce3426cdd90fe674|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248590a70,
          },
          "e-70": {
            id: "e-70",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-71",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbadf3ce3426cdd90fe674|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbadf3ce3426cdd90fe674|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248590bd4,
          },
          "e-71": {
            id: "e-71",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-70",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbadf3ce3426cdd90fe674|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbadf3ce3426cdd90fe674|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248590bd4,
          },
          "e-72": {
            id: "e-72",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-73",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbadf3ce3426cdd90fe674|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbadf3ce3426cdd90fe674|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248590d30,
          },
          "e-73": {
            id: "e-73",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-72",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbadf3ce3426cdd90fe674|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbadf3ce3426cdd90fe674|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248590d30,
          },
          "e-74": {
            id: "e-74",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-75",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbadf3ce3426cdd90fe674|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbadf3ce3426cdd90fe674|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248590ec8,
          },
          "e-75": {
            id: "e-75",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-74",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbadf3ce3426cdd90fe674|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbadf3ce3426cdd90fe674|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248590ec8,
          },
          "e-76": {
            id: "e-76",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-77",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbff95a71fe3c0ee84d70a|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbff95a71fe3c0ee84d70a|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192485e78f0,
          },
          "e-77": {
            id: "e-77",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-76",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbff95a71fe3c0ee84d70a|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbff95a71fe3c0ee84d70a|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192485e78f0,
          },
          "e-78": {
            id: "e-78",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-79",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbff95a71fe3c0ee84d70a|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbff95a71fe3c0ee84d70a|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192485e78f0,
          },
          "e-79": {
            id: "e-79",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-78",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbff95a71fe3c0ee84d70a|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbff95a71fe3c0ee84d70a|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192485e78f0,
          },
          "e-80": {
            id: "e-80",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-81",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbff95a71fe3c0ee84d70a|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbff95a71fe3c0ee84d70a|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192485e78f0,
          },
          "e-81": {
            id: "e-81",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-80",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbff95a71fe3c0ee84d70a|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbff95a71fe3c0ee84d70a|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192485e78f0,
          },
          "e-82": {
            id: "e-82",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-15",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-83",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbff95a71fe3c0ee84d70a|a4d7acc7-392f-0fa1-88e8-23d9168209cd",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbff95a71fe3c0ee84d70a|a4d7acc7-392f-0fa1-88e8-23d9168209cd",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192485e78f0,
          },
          "e-84": {
            id: "e-84",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-85",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1924863490b,
          },
          "e-85": {
            id: "e-85",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-84",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1924863490b,
          },
          "e-86": {
            id: "e-86",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-87",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248634a7c,
          },
          "e-87": {
            id: "e-87",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-86",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248634a7c,
          },
          "e-88": {
            id: "e-88",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-89",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248634bb6,
          },
          "e-89": {
            id: "e-89",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-88",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248634bb6,
          },
          "e-90": {
            id: "e-90",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-91",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248634d1d,
          },
          "e-91": {
            id: "e-91",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-90",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19248634d1d,
          },
          "e-92": {
            id: "e-92",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-16",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-93",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".button-main.is-white",
              originalId: "b473a1bc-e3c5-7edc-cff7-15dc11afe5a1",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".button-main.is-white",
                originalId: "b473a1bc-e3c5-7edc-cff7-15dc11afe5a1",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192670b7a84,
          },
          "e-93": {
            id: "e-93",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-17",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-92",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".button-main.is-white",
              originalId: "b473a1bc-e3c5-7edc-cff7-15dc11afe5a1",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".button-main.is-white",
                originalId: "b473a1bc-e3c5-7edc-cff7-15dc11afe5a1",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192670b7a85,
          },
          "e-94": {
            id: "e-94",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-95",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6703f89612826faacd081b94|22c90a92-0c4c-f9ad-15f9-3a3cf2048f77",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6703f89612826faacd081b94|22c90a92-0c4c-f9ad-15f9-3a3cf2048f77",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19267a3a40b,
          },
          "e-95": {
            id: "e-95",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-94",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6703f89612826faacd081b94|22c90a92-0c4c-f9ad-15f9-3a3cf2048f77",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6703f89612826faacd081b94|22c90a92-0c4c-f9ad-15f9-3a3cf2048f77",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19267a3a40b,
          },
          "e-96": {
            id: "e-96",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-97",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6703f89612826faacd081b94|22c90a92-0c4c-f9ad-15f9-3a3cf2048f8e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6703f89612826faacd081b94|22c90a92-0c4c-f9ad-15f9-3a3cf2048f8e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19267a3a40b,
          },
          "e-97": {
            id: "e-97",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-96",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6703f89612826faacd081b94|22c90a92-0c4c-f9ad-15f9-3a3cf2048f8e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6703f89612826faacd081b94|22c90a92-0c4c-f9ad-15f9-3a3cf2048f8e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19267a3a40b,
          },
          "e-98": {
            id: "e-98",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-99",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6703f89612826faacd081b94|22c90a92-0c4c-f9ad-15f9-3a3cf2048fa5",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6703f89612826faacd081b94|22c90a92-0c4c-f9ad-15f9-3a3cf2048fa5",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19267a3a40b,
          },
          "e-99": {
            id: "e-99",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-98",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6703f89612826faacd081b94|22c90a92-0c4c-f9ad-15f9-3a3cf2048fa5",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6703f89612826faacd081b94|22c90a92-0c4c-f9ad-15f9-3a3cf2048fa5",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19267a3a40b,
          },
          "e-154": {
            id: "e-154",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-155",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|9f7196b6-045d-1a3d-4de6-52b25279ac99",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|9f7196b6-045d-1a3d-4de6-52b25279ac99",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-155": {
            id: "e-155",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-154",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|9f7196b6-045d-1a3d-4de6-52b25279ac99",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|9f7196b6-045d-1a3d-4de6-52b25279ac99",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-156": {
            id: "e-156",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-157",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|ad497cfd-d5ed-d3a1-5b05-a30f4c8d0319",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|ad497cfd-d5ed-d3a1-5b05-a30f4c8d0319",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-157": {
            id: "e-157",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-156",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|ad497cfd-d5ed-d3a1-5b05-a30f4c8d0319",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|ad497cfd-d5ed-d3a1-5b05-a30f4c8d0319",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-158": {
            id: "e-158",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-159",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|1916df03-2a5d-cdea-dd76-3e036a13009c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|1916df03-2a5d-cdea-dd76-3e036a13009c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-159": {
            id: "e-159",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-158",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|1916df03-2a5d-cdea-dd76-3e036a13009c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|1916df03-2a5d-cdea-dd76-3e036a13009c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-160": {
            id: "e-160",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-161",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|47ba7366-de01-85fd-77a3-6fbcf59607c2",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|47ba7366-de01-85fd-77a3-6fbcf59607c2",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-161": {
            id: "e-161",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-160",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|47ba7366-de01-85fd-77a3-6fbcf59607c2",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|47ba7366-de01-85fd-77a3-6fbcf59607c2",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-162": {
            id: "e-162",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-163",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|466f8253-fadc-d262-eb63-7dd47cd12347",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|466f8253-fadc-d262-eb63-7dd47cd12347",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-163": {
            id: "e-163",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-162",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|466f8253-fadc-d262-eb63-7dd47cd12347",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|466f8253-fadc-d262-eb63-7dd47cd12347",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-164": {
            id: "e-164",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-165",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|1a610ca6-b92c-2f5c-4816-68dc5ddf04f4",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|1a610ca6-b92c-2f5c-4816-68dc5ddf04f4",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-165": {
            id: "e-165",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-164",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|1a610ca6-b92c-2f5c-4816-68dc5ddf04f4",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|1a610ca6-b92c-2f5c-4816-68dc5ddf04f4",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-166": {
            id: "e-166",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-167",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|7064dfec-2b31-b934-9aae-dd76a261a404",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|7064dfec-2b31-b934-9aae-dd76a261a404",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-167": {
            id: "e-167",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-166",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|7064dfec-2b31-b934-9aae-dd76a261a404",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|7064dfec-2b31-b934-9aae-dd76a261a404",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-168": {
            id: "e-168",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-169",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|f858a8ae-1981-7c26-d187-a11960606603",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|f858a8ae-1981-7c26-d187-a11960606603",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-169": {
            id: "e-169",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-168",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|f858a8ae-1981-7c26-d187-a11960606603",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|f858a8ae-1981-7c26-d187-a11960606603",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-170": {
            id: "e-170",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-171",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|fe33076f-86d8-9045-b100-5466cefa92d9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|fe33076f-86d8-9045-b100-5466cefa92d9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-171": {
            id: "e-171",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-170",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67068cfa60898994cf0caa44|fe33076f-86d8-9045-b100-5466cefa92d9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67068cfa60898994cf0caa44|fe33076f-86d8-9045-b100-5466cefa92d9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1927196bcd6,
          },
          "e-178": {
            id: "e-178",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-179",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6706f26421f0543fa87592a0|ecac9275-1d39-29f0-3b13-95955876ce4d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6706f26421f0543fa87592a0|ecac9275-1d39-29f0-3b13-95955876ce4d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19273536c35,
          },
          "e-179": {
            id: "e-179",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-178",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6706f26421f0543fa87592a0|ecac9275-1d39-29f0-3b13-95955876ce4d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6706f26421f0543fa87592a0|ecac9275-1d39-29f0-3b13-95955876ce4d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19273536c35,
          },
          "e-180": {
            id: "e-180",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-181",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbe0f096c0e9e0cebc1cce|28902246-a35d-51da-b4ef-7a0bf8736988",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbe0f096c0e9e0cebc1cce|28902246-a35d-51da-b4ef-7a0bf8736988",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19273767566,
          },
          "e-181": {
            id: "e-181",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-180",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbe0f096c0e9e0cebc1cce|28902246-a35d-51da-b4ef-7a0bf8736988",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbe0f096c0e9e0cebc1cce|28902246-a35d-51da-b4ef-7a0bf8736988",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19273767566,
          },
          "e-182": {
            id: "e-182",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-23",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-183",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".fade-in-0",
              originalId:
                "66ebfd984234fb259fa972a5|3ba50a0d-c072-143a-8f3b-cd7fcff5ff28",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".fade-in-0",
                originalId:
                  "66ebfd984234fb259fa972a5|3ba50a0d-c072-143a-8f3b-cd7fcff5ff28",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19287a6e249,
          },
          "e-185": {
            id: "e-185",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-11",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-186",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbb1a30b4912068180f6c2|7889fdc0-28f1-ddf9-426b-89e6b31417c0",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbb1a30b4912068180f6c2|7889fdc0-28f1-ddf9-426b-89e6b31417c0",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1928b93a7d0,
          },
          "e-186": {
            id: "e-186",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-12",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-185",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbb1a30b4912068180f6c2|7889fdc0-28f1-ddf9-426b-89e6b31417c0",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbb1a30b4912068180f6c2|7889fdc0-28f1-ddf9-426b-89e6b31417c0",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1928b93a7d0,
          },
          "e-187": {
            id: "e-187",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-188",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66faa850635f83cedbab678d|5a4e337c-3337-32ce-762c-89b731dfb415",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66faa850635f83cedbab678d|5a4e337c-3337-32ce-762c-89b731dfb415",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1928c4bb364,
          },
          "e-188": {
            id: "e-188",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-187",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66faa850635f83cedbab678d|5a4e337c-3337-32ce-762c-89b731dfb415",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66faa850635f83cedbab678d|5a4e337c-3337-32ce-762c-89b731dfb415",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1928c4bb364,
          },
          "e-189": {
            id: "e-189",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-190",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1929019540c,
          },
          "e-190": {
            id: "e-190",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-189",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1929019540c,
          },
          "e-195": {
            id: "e-195",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-196",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-196": {
            id: "e-196",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-195",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-197": {
            id: "e-197",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-198",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-198": {
            id: "e-198",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-197",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-199": {
            id: "e-199",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-200",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-200": {
            id: "e-200",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-199",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-201": {
            id: "e-201",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-15",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-202",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|a4d7acc7-392f-0fa1-88e8-23d9168209cd",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|a4d7acc7-392f-0fa1-88e8-23d9168209cd",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-203": {
            id: "e-203",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-204",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-204": {
            id: "e-204",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-203",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-205": {
            id: "e-205",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-206",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-206": {
            id: "e-206",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-205",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-207": {
            id: "e-207",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-208",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-208": {
            id: "e-208",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-207",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-209": {
            id: "e-209",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-210",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-210": {
            id: "e-210",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-209",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-211": {
            id: "e-211",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-2",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-212",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|56513673-df46-50e1-5bad-30eaba04e70a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|56513673-df46-50e1-5bad-30eaba04e70a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-212": {
            id: "e-212",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-3",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-211",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|56513673-df46-50e1-5bad-30eaba04e70a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|56513673-df46-50e1-5bad-30eaba04e70a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-213": {
            id: "e-213",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-2",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-214",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|66d3a35f-f948-5ad1-9eea-218794ed58cd",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|66d3a35f-f948-5ad1-9eea-218794ed58cd",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-214": {
            id: "e-214",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-3",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-213",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|66d3a35f-f948-5ad1-9eea-218794ed58cd",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|66d3a35f-f948-5ad1-9eea-218794ed58cd",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-215": {
            id: "e-215",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-2",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-216",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|e1cdf446-9925-5a3c-e2ff-18bdabffb4bf",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|e1cdf446-9925-5a3c-e2ff-18bdabffb4bf",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-216": {
            id: "e-216",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-3",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-215",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|e1cdf446-9925-5a3c-e2ff-18bdabffb4bf",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|e1cdf446-9925-5a3c-e2ff-18bdabffb4bf",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-217": {
            id: "e-217",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-218",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-218": {
            id: "e-218",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-217",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "670e5f8c377e95ea46547ed8|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "670e5f8c377e95ea46547ed8|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19290254349,
          },
          "e-221": {
            id: "e-221",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-28",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-222",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".badge-card.item",
              originalId: "d161c8d4-576a-1603-22c8-f8b03e550d47",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".badge-card.item",
                originalId: "d161c8d4-576a-1603-22c8-f8b03e550d47",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192c7befae1,
          },
          "e-222": {
            id: "e-222",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-29",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-221",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".badge-card.item",
              originalId: "d161c8d4-576a-1603-22c8-f8b03e550d47",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".badge-card.item",
                originalId: "d161c8d4-576a-1603-22c8-f8b03e550d47",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192c7befae3,
          },
          "e-223": {
            id: "e-223",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-30",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-224",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".work-item.bg-blur",
              originalId:
                "66fb2801f78e1172dcb4ff47|cf8ecbed-b594-016b-7107-c90de7713383",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".work-item.bg-blur",
                originalId:
                  "66fb2801f78e1172dcb4ff47|cf8ecbed-b594-016b-7107-c90de7713383",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192c8783599,
          },
          "e-224": {
            id: "e-224",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-31",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-223",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".work-item.bg-blur",
              originalId:
                "66fb2801f78e1172dcb4ff47|cf8ecbed-b594-016b-7107-c90de7713383",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".work-item.bg-blur",
                originalId:
                  "66fb2801f78e1172dcb4ff47|cf8ecbed-b594-016b-7107-c90de7713383",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192c878359c,
          },
          "e-231": {
            id: "e-231",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-232",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "672112ee2aa00e56c22b6a6a|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "672112ee2aa00e56c22b6a6a|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192d931f754,
          },
          "e-232": {
            id: "e-232",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-231",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "672112ee2aa00e56c22b6a6a|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "672112ee2aa00e56c22b6a6a|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192d931f754,
          },
          "e-233": {
            id: "e-233",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-234",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "672112ee2aa00e56c22b6a6a|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "672112ee2aa00e56c22b6a6a|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192d931f754,
          },
          "e-234": {
            id: "e-234",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-233",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "672112ee2aa00e56c22b6a6a|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "672112ee2aa00e56c22b6a6a|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192d931f754,
          },
          "e-235": {
            id: "e-235",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-236",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "672112ee2aa00e56c22b6a6a|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "672112ee2aa00e56c22b6a6a|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192d931f754,
          },
          "e-236": {
            id: "e-236",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-235",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "672112ee2aa00e56c22b6a6a|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "672112ee2aa00e56c22b6a6a|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192d931f754,
          },
          "e-237": {
            id: "e-237",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-238",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "672112ee2aa00e56c22b6a6a|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "672112ee2aa00e56c22b6a6a|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192d931f754,
          },
          "e-238": {
            id: "e-238",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-237",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "672112ee2aa00e56c22b6a6a|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "672112ee2aa00e56c22b6a6a|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192d931f754,
          },
          "e-239": {
            id: "e-239",
            name: "",
            animationType: "custom",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-32",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-240",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "d36be264-3199-d56f-ed0f-22a1bbf1fca0",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "d36be264-3199-d56f-ed0f-22a1bbf1fca0",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192d9dc59cd,
          },
          "e-240": {
            id: "e-240",
            name: "",
            animationType: "custom",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-33",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-239",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "d36be264-3199-d56f-ed0f-22a1bbf1fca0",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "d36be264-3199-d56f-ed0f-22a1bbf1fca0",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192d9dc59cf,
          },
          "e-241": {
            id: "e-241",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-242",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66faa850635f83cedbab678d|d490ec30-eb95-07e2-46b8-3594fc723d5e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66faa850635f83cedbab678d|d490ec30-eb95-07e2-46b8-3594fc723d5e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192de2fab1b,
          },
          "e-242": {
            id: "e-242",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-241",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66faa850635f83cedbab678d|d490ec30-eb95-07e2-46b8-3594fc723d5e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66faa850635f83cedbab678d|d490ec30-eb95-07e2-46b8-3594fc723d5e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192de2fab1b,
          },
          "e-247": {
            id: "e-247",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-2",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-248",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".service-card.item.bg-blur",
              originalId:
                "66ebfd984234fb259fa972a5|c6837d88-4032-dc89-3fac-6a32bc7c238c",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".service-card.item.bg-blur",
                originalId:
                  "66ebfd984234fb259fa972a5|c6837d88-4032-dc89-3fac-6a32bc7c238c",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192f933b69c,
          },
          "e-248": {
            id: "e-248",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-3",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-247",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".service-card.item.bg-blur",
              originalId:
                "66ebfd984234fb259fa972a5|c6837d88-4032-dc89-3fac-6a32bc7c238c",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".service-card.item.bg-blur",
                originalId:
                  "66ebfd984234fb259fa972a5|c6837d88-4032-dc89-3fac-6a32bc7c238c",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192f933b69e,
          },
          "e-249": {
            id: "e-249",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-250",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192ff8e4d08,
          },
          "e-250": {
            id: "e-250",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-249",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192ff8e4d08,
          },
          "e-251": {
            id: "e-251",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-34",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-252",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x193023b6717,
          },
          "e-257": {
            id: "e-257",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-35",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-258",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1930c4b6d62,
          },
          "e-259": {
            id: "e-259",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-260",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66faa850635f83cedbab678d|07e78169-57e6-aa2c-c0ae-3064fffa6382",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66faa850635f83cedbab678d|07e78169-57e6-aa2c-c0ae-3064fffa6382",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1930c543013,
          },
          "e-261": {
            id: "e-261",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-262",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fb138f8830dc37a4b53ea7|cd7f7716-a526-3b24-a583-f013bcbb4464",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fb138f8830dc37a4b53ea7|cd7f7716-a526-3b24-a583-f013bcbb4464",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1930c55f62c,
          },
          "e-263": {
            id: "e-263",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-264",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fb2801f78e1172dcb4ff47|cd7f7716-a526-3b24-a583-f013bcbb4464",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fb2801f78e1172dcb4ff47|cd7f7716-a526-3b24-a583-f013bcbb4464",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1930c5a9fed,
          },
          "e-265": {
            id: "e-265",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-39",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-266",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fb972381fa6866fa37132f|8e40969c-0f97-d269-9cd8-49ce8cb41695",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fb972381fa6866fa37132f|8e40969c-0f97-d269-9cd8-49ce8cb41695",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1930c5cc92d,
          },
          "e-267": {
            id: "e-267",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-40",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-268",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbadf3ce3426cdd90fe674|3d2a2523-3886-49b9-4687-96f36af1eef3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbadf3ce3426cdd90fe674|3d2a2523-3886-49b9-4687-96f36af1eef3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1930c5f5214,
          },
          "e-269": {
            id: "e-269",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-41",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-270",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "672112ee2aa00e56c22b6a6a|3d2a2523-3886-49b9-4687-96f36af1eef3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "672112ee2aa00e56c22b6a6a|3d2a2523-3886-49b9-4687-96f36af1eef3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1930c622da7,
          },
          "e-271": {
            id: "e-271",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-42",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-272",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbfb32c902f521155e6fea|847db60d-d673-f499-927c-6f6576e47ff5",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbfb32c902f521155e6fea|847db60d-d673-f499-927c-6f6576e47ff5",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1930c6404e3,
          },
          "e-273": {
            id: "e-273",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-43",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-274",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".awards-card.item",
              originalId: "b1116d67-8989-c0a6-fe88-e04ffc32aa27",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".awards-card.item",
                originalId: "b1116d67-8989-c0a6-fe88-e04ffc32aa27",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1932fcd1763,
          },
          "e-274": {
            id: "e-274",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-44",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-273",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".awards-card.item",
              originalId: "b1116d67-8989-c0a6-fe88-e04ffc32aa27",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".awards-card.item",
                originalId: "b1116d67-8989-c0a6-fe88-e04ffc32aa27",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1932fcd1766,
          },
          "e-275": {
            id: "e-275",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-45",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-276",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbb1a30b4912068180f6c2|b8490dfc-874b-d2b9-9080-df5ced28e10b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbb1a30b4912068180f6c2|b8490dfc-874b-d2b9-9080-df5ced28e10b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1934e24682e,
          },
          "e-277": {
            id: "e-277",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLLING_IN_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_CONTINUOUS_ACTION",
              config: {
                actionListId: "a-5",
                affectedElements: {},
                duration: 0,
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fb138f8830dc37a4b53ea7|12fe564f-ff2c-9a11-43bc-cf909ca3d3dd",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fb138f8830dc37a4b53ea7|12fe564f-ff2c-9a11-43bc-cf909ca3d3dd",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: [
              {
                continuousParameterGroupId: "a-5-p",
                smoothing: 75,
                startsEntering: !0,
                addStartOffset: !1,
                addOffsetValue: 50,
                startsExiting: !1,
                addEndOffset: !1,
                endOffsetValue: 50,
              },
            ],
            createdOn: 0x1935061bba0,
          },
          "e-278": {
            id: "e-278",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLLING_IN_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_CONTINUOUS_ACTION",
              config: {
                actionListId: "a-5",
                affectedElements: {},
                duration: 0,
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbadf3ce3426cdd90fe674|13069673-41e0-66bf-ee75-26809105d6b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbadf3ce3426cdd90fe674|13069673-41e0-66bf-ee75-26809105d6b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: [
              {
                continuousParameterGroupId: "a-5-p",
                smoothing: 75,
                startsEntering: !0,
                addStartOffset: !1,
                addOffsetValue: 50,
                startsExiting: !1,
                addEndOffset: !1,
                endOffsetValue: 50,
              },
            ],
            createdOn: 0x1935061f9a5,
          },
          "e-280": {
            id: "e-280",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-39",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-281",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a7|d3efd7b7-d5a0-1c0a-b13e-7e7d3fc166bf",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a7|d3efd7b7-d5a0-1c0a-b13e-7e7d3fc166bf",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x193508cba91,
          },
          "e-282": {
            id: "e-282",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLLING_IN_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_CONTINUOUS_ACTION",
              config: {
                actionListId: "a-5",
                affectedElements: {},
                duration: 0,
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "13069673-41e0-66bf-ee75-26809105d6b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "13069673-41e0-66bf-ee75-26809105d6b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: [
              {
                continuousParameterGroupId: "a-5-p",
                smoothing: 50,
                startsEntering: !0,
                addStartOffset: !1,
                addOffsetValue: 50,
                startsExiting: !1,
                addEndOffset: !1,
                endOffsetValue: 50,
              },
            ],
            createdOn: 0x1935503a46b,
          },
          "e-283": {
            id: "e-283",
            name: "",
            animationType: "custom",
            eventTypeId: "SCROLLING_IN_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_CONTINUOUS_ACTION",
              config: {
                actionListId: "a-5",
                affectedElements: {},
                duration: 0,
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbadf3ce3426cdd90fe674|40d9b13e-dcba-7600-62ff-7bc6bed05bdb",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbadf3ce3426cdd90fe674|40d9b13e-dcba-7600-62ff-7bc6bed05bdb",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: [
              {
                continuousParameterGroupId: "a-5-p",
                smoothing: 50,
                startsEntering: !0,
                addStartOffset: !1,
                addOffsetValue: 50,
                startsExiting: !1,
                addEndOffset: !1,
                endOffsetValue: 50,
              },
            ],
            createdOn: 0x193550408de,
          },
          "e-284": {
            id: "e-284",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_START",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-46",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-285",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66fbc92058bcbd96a39bed05",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66fbc92058bcbd96a39bed05",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1938dbbacd6,
          },
          "e-286": {
            id: "e-286",
            name: "",
            animationType: "custom",
            eventTypeId: "NAVBAR_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-48",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-287",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "3cf852fa-58d8-e21a-efb0-03ad2968231d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "3cf852fa-58d8-e21a-efb0-03ad2968231d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943cfe5e70,
          },
          "e-287": {
            id: "e-287",
            name: "",
            animationType: "custom",
            eventTypeId: "NAVBAR_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-49",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-286",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "3cf852fa-58d8-e21a-efb0-03ad2968231d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "3cf852fa-58d8-e21a-efb0-03ad2968231d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943cfe5e71,
          },
          "e-288": {
            id: "e-288",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-289",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-289": {
            id: "e-289",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-288",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-290": {
            id: "e-290",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-291",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-291": {
            id: "e-291",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-290",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-292": {
            id: "e-292",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-293",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-293": {
            id: "e-293",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-292",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-294": {
            id: "e-294",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-295",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-295": {
            id: "e-295",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-294",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-296": {
            id: "e-296",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-297",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-297": {
            id: "e-297",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-296",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-298": {
            id: "e-298",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-299",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-299": {
            id: "e-299",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-298",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-300": {
            id: "e-300",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-301",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-301": {
            id: "e-301",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-300",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-302": {
            id: "e-302",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-303",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-303": {
            id: "e-303",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-302",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-304": {
            id: "e-304",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-305",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-305": {
            id: "e-305",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-304",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-306": {
            id: "e-306",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-34",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-307",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-308": {
            id: "e-308",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-35",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-309",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d08ca50,
          },
          "e-310": {
            id: "e-310",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-50",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-311",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|4d971bac-e3ed-8b4c-9a2a-29505be8a039",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|4d971bac-e3ed-8b4c-9a2a-29505be8a039",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d094ec1,
          },
          "e-311": {
            id: "e-311",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-51",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-310",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|4d971bac-e3ed-8b4c-9a2a-29505be8a039",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|4d971bac-e3ed-8b4c-9a2a-29505be8a039",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d094ec1,
          },
          "e-312": {
            id: "e-312",
            name: "",
            animationType: "preset",
            eventTypeId: "NAVBAR_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-52",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-313",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|fa871315-8fb4-1ab9-4713-05e4a7f063b6",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|fa871315-8fb4-1ab9-4713-05e4a7f063b6",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d094ec1,
          },
          "e-313": {
            id: "e-313",
            name: "",
            animationType: "preset",
            eventTypeId: "NAVBAR_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-53",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-312",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "677c2b34df341ce6750f9e3f|fa871315-8fb4-1ab9-4713-05e4a7f063b6",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "677c2b34df341ce6750f9e3f|fa871315-8fb4-1ab9-4713-05e4a7f063b6",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1943d094ec1,
          },
          "e-314": {
            id: "e-314",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-35",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-315",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6862c0b421a26f5966e861f9|c46885e1-4251-ea7f-91d6-597ccfae9f5b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6862c0b421a26f5966e861f9|c46885e1-4251-ea7f-91d6-597ccfae9f5b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x197c1c3cd86,
          },
          "e-318": {
            id: "e-318",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-54",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-319",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "66ebfd984234fb259fa972a5|7c551dab-88d0-1667-a4e8-a5d45f12df68",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "66ebfd984234fb259fa972a5|7c551dab-88d0-1667-a4e8-a5d45f12df68",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1995150e147,
          },
          "e-320": {
            id: "e-320",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-321",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b11c19e1fded26e777dfe|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b11c19e1fded26e777dfe|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91bd5f8c,
          },
          "e-321": {
            id: "e-321",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-320",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b11c19e1fded26e777dfe|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b11c19e1fded26e777dfe|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91bd5f8c,
          },
          "e-322": {
            id: "e-322",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-323",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b11c19e1fded26e777dfe|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b11c19e1fded26e777dfe|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91bd5f8c,
          },
          "e-323": {
            id: "e-323",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-322",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b11c19e1fded26e777dfe|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b11c19e1fded26e777dfe|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91bd5f8c,
          },
          "e-324": {
            id: "e-324",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-325",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b11c19e1fded26e777dfe|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b11c19e1fded26e777dfe|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91bd5f8c,
          },
          "e-325": {
            id: "e-325",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-324",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b11c19e1fded26e777dfe|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b11c19e1fded26e777dfe|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91bd5f8c,
          },
          "e-326": {
            id: "e-326",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-327",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b11c19e1fded26e777dfe|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b11c19e1fded26e777dfe|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91bd5f8c,
          },
          "e-327": {
            id: "e-327",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-326",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b11c19e1fded26e777dfe|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b11c19e1fded26e777dfe|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91bd5f8c,
          },
          "e-328": {
            id: "e-328",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-41",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-329",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b11c19e1fded26e777dfe|3d2a2523-3886-49b9-4687-96f36af1eef3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b11c19e1fded26e777dfe|3d2a2523-3886-49b9-4687-96f36af1eef3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91bd5f8c,
          },
          "e-330": {
            id: "e-330",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-331",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a064e4453244601283d|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a064e4453244601283d|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddad51,
          },
          "e-331": {
            id: "e-331",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-330",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a064e4453244601283d|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a064e4453244601283d|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddad51,
          },
          "e-332": {
            id: "e-332",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-333",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a064e4453244601283d|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a064e4453244601283d|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddad51,
          },
          "e-333": {
            id: "e-333",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-332",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a064e4453244601283d|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a064e4453244601283d|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddad51,
          },
          "e-334": {
            id: "e-334",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-335",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a064e4453244601283d|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a064e4453244601283d|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddad51,
          },
          "e-335": {
            id: "e-335",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-334",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a064e4453244601283d|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a064e4453244601283d|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddad51,
          },
          "e-336": {
            id: "e-336",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-337",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a064e4453244601283d|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a064e4453244601283d|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddad51,
          },
          "e-337": {
            id: "e-337",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-336",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a064e4453244601283d|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a064e4453244601283d|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddad51,
          },
          "e-338": {
            id: "e-338",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-41",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-339",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a064e4453244601283d|3d2a2523-3886-49b9-4687-96f36af1eef3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a064e4453244601283d|3d2a2523-3886-49b9-4687-96f36af1eef3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddad51,
          },
          "e-340": {
            id: "e-340",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-341",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a19eb8d3e39cc7bba16|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a19eb8d3e39cc7bba16|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddf776,
          },
          "e-341": {
            id: "e-341",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-340",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a19eb8d3e39cc7bba16|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a19eb8d3e39cc7bba16|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddf776,
          },
          "e-342": {
            id: "e-342",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-343",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a19eb8d3e39cc7bba16|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a19eb8d3e39cc7bba16|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddf776,
          },
          "e-343": {
            id: "e-343",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-342",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a19eb8d3e39cc7bba16|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a19eb8d3e39cc7bba16|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddf776,
          },
          "e-344": {
            id: "e-344",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-345",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a19eb8d3e39cc7bba16|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a19eb8d3e39cc7bba16|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddf776,
          },
          "e-345": {
            id: "e-345",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-344",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a19eb8d3e39cc7bba16|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a19eb8d3e39cc7bba16|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddf776,
          },
          "e-346": {
            id: "e-346",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-347",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a19eb8d3e39cc7bba16|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a19eb8d3e39cc7bba16|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddf776,
          },
          "e-347": {
            id: "e-347",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-346",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a19eb8d3e39cc7bba16|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a19eb8d3e39cc7bba16|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddf776,
          },
          "e-348": {
            id: "e-348",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-41",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-349",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a19eb8d3e39cc7bba16|3d2a2523-3886-49b9-4687-96f36af1eef3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a19eb8d3e39cc7bba16|3d2a2523-3886-49b9-4687-96f36af1eef3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91ddf776,
          },
          "e-350": {
            id: "e-350",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-351",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a2b25dc5b4f4d4dde0c|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a2b25dc5b4f4d4dde0c|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91de3cbd,
          },
          "e-351": {
            id: "e-351",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-350",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a2b25dc5b4f4d4dde0c|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a2b25dc5b4f4d4dde0c|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91de3cbd,
          },
          "e-352": {
            id: "e-352",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-353",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a2b25dc5b4f4d4dde0c|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a2b25dc5b4f4d4dde0c|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91de3cbd,
          },
          "e-353": {
            id: "e-353",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-352",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a2b25dc5b4f4d4dde0c|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a2b25dc5b4f4d4dde0c|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91de3cbd,
          },
          "e-354": {
            id: "e-354",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-355",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a2b25dc5b4f4d4dde0c|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a2b25dc5b4f4d4dde0c|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91de3cbd,
          },
          "e-355": {
            id: "e-355",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-354",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a2b25dc5b4f4d4dde0c|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a2b25dc5b4f4d4dde0c|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91de3cbd,
          },
          "e-356": {
            id: "e-356",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-357",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a2b25dc5b4f4d4dde0c|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a2b25dc5b4f4d4dde0c|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91de3cbd,
          },
          "e-357": {
            id: "e-357",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-356",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a2b25dc5b4f4d4dde0c|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a2b25dc5b4f4d4dde0c|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91de3cbd,
          },
          "e-358": {
            id: "e-358",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-41",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-359",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b1a2b25dc5b4f4d4dde0c|3d2a2523-3886-49b9-4687-96f36af1eef3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b1a2b25dc5b4f4d4dde0c|3d2a2523-3886-49b9-4687-96f36af1eef3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19a91de3cbd,
          },
          "e-360": {
            id: "e-360",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-35",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-361",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b2010765c6d06a9959add|c37cbfb5-610b-c83a-05ae-a9cc47bdbfd9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b2010765c6d06a9959add|c37cbfb5-610b-c83a-05ae-a9cc47bdbfd9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19aa69a0063,
          },
          "e-362": {
            id: "e-362",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-363",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "691b2010765c6d06a9959add|ee018559-ba48-8e6b-30ae-b9895f26c0bc",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "691b2010765c6d06a9959add|ee018559-ba48-8e6b-30ae-b9895f26c0bc",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19aa6b26efa,
          },
          "e-364": {
            id: "e-364",
            name: "",
            animationType: "preset",
            eventTypeId: "PAGE_START",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-46",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-365",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6942b6d52a4a58024437a302",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6942b6d52a4a58024437a302",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19b2c9a35d4,
          },
          "e-366": {
            id: "e-366",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-35",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-367",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "e987c0ef-06f3-4ff4-04b1-611658ba846e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "e987c0ef-06f3-4ff4-04b1-611658ba846e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19b30fb1241,
          },
          "e-368": {
            id: "e-368",
            name: "",
            animationType: "preset",
            eventTypeId: "PAGE_START",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-46",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-369",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6960ee303ca90afcdd7b692e",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6960ee303ca90afcdd7b692e",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19ba2a27166,
          },
          "e-370": {
            id: "e-370",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-371",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-371": {
            id: "e-371",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-370",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-372": {
            id: "e-372",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-373",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-373": {
            id: "e-373",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-372",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-374": {
            id: "e-374",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-375",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-375": {
            id: "e-375",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-374",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-376": {
            id: "e-376",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-377",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-377": {
            id: "e-377",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-376",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-378": {
            id: "e-378",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-379",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-379": {
            id: "e-379",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-378",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-380": {
            id: "e-380",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-381",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-381": {
            id: "e-381",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-380",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-382": {
            id: "e-382",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-383",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-383": {
            id: "e-383",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-382",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-384": {
            id: "e-384",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-385",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-385": {
            id: "e-385",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-384",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-386": {
            id: "e-386",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-387",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-387": {
            id: "e-387",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-386",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-388": {
            id: "e-388",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-34",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-389",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-390": {
            id: "e-390",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-35",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-391",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-392": {
            id: "e-392",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-54",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-393",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6966a864bec71726faf75559|7c551dab-88d0-1667-a4e8-a5d45f12df68",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6966a864bec71726faf75559|7c551dab-88d0-1667-a4e8-a5d45f12df68",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bb901d0d4,
          },
          "e-394": {
            id: "e-394",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-395",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-395": {
            id: "e-395",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-394",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-396": {
            id: "e-396",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-397",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-397": {
            id: "e-397",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-396",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-398": {
            id: "e-398",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-399",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-399": {
            id: "e-399",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-398",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-400": {
            id: "e-400",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-401",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-401": {
            id: "e-401",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-400",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-402": {
            id: "e-402",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-403",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-403": {
            id: "e-403",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-402",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-404": {
            id: "e-404",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-405",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-405": {
            id: "e-405",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-404",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-406": {
            id: "e-406",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-407",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-407": {
            id: "e-407",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-406",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-408": {
            id: "e-408",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-409",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-409": {
            id: "e-409",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-408",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-410": {
            id: "e-410",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-411",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-411": {
            id: "e-411",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-410",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-412": {
            id: "e-412",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-34",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-413",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-414": {
            id: "e-414",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-35",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-415",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-416": {
            id: "e-416",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-54",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-417",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6978892d33c753621d45bd12|7c551dab-88d0-1667-a4e8-a5d45f12df68",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6978892d33c753621d45bd12|7c551dab-88d0-1667-a4e8-a5d45f12df68",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19bfed7d5b9,
          },
          "e-418": {
            id: "e-418",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-419",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-419": {
            id: "e-419",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-418",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-420": {
            id: "e-420",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-421",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-421": {
            id: "e-421",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-420",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-422": {
            id: "e-422",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-423",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-423": {
            id: "e-423",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-422",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-424": {
            id: "e-424",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-425",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-425": {
            id: "e-425",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-424",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-426": {
            id: "e-426",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-427",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-427": {
            id: "e-427",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-426",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-428": {
            id: "e-428",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-429",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-429": {
            id: "e-429",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-428",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-430": {
            id: "e-430",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-431",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-431": {
            id: "e-431",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-430",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-432": {
            id: "e-432",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-433",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-433": {
            id: "e-433",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-432",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-434": {
            id: "e-434",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-435",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-435": {
            id: "e-435",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-434",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-436": {
            id: "e-436",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-34",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-437",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-438": {
            id: "e-438",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-35",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-439",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-440": {
            id: "e-440",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-54",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-441",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "697a757976023b108a5e2e60|7c551dab-88d0-1667-a4e8-a5d45f12df68",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "697a757976023b108a5e2e60|7c551dab-88d0-1667-a4e8-a5d45f12df68",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c065af944,
          },
          "e-442": {
            id: "e-442",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-443",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6706f40a11d97dfd34dbe3ad|7232bbe9-e06f-ab64-5813-b25eec68ca73",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6706f40a11d97dfd34dbe3ad|7232bbe9-e06f-ab64-5813-b25eec68ca73",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c5286d7b6,
          },
          "e-443": {
            id: "e-443",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-442",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6706f40a11d97dfd34dbe3ad|7232bbe9-e06f-ab64-5813-b25eec68ca73",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6706f40a11d97dfd34dbe3ad|7232bbe9-e06f-ab64-5813-b25eec68ca73",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c5286d7b6,
          },
          "e-444": {
            id: "e-444",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-445",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-445": {
            id: "e-445",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-444",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-446": {
            id: "e-446",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-447",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-447": {
            id: "e-447",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-446",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-448": {
            id: "e-448",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-449",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-449": {
            id: "e-449",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-448",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-450": {
            id: "e-450",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-451",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-451": {
            id: "e-451",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-450",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-452": {
            id: "e-452",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-453",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-453": {
            id: "e-453",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-452",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-454": {
            id: "e-454",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-455",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-455": {
            id: "e-455",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-454",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-456": {
            id: "e-456",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-457",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-457": {
            id: "e-457",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-456",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-458": {
            id: "e-458",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-459",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-459": {
            id: "e-459",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-458",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-460": {
            id: "e-460",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-461",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-461": {
            id: "e-461",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-460",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-462": {
            id: "e-462",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-34",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-463",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-464": {
            id: "e-464",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-35",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-465",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-466": {
            id: "e-466",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-54",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-467",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6996069394ce68e59ee2c758|7c551dab-88d0-1667-a4e8-a5d45f12df68",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6996069394ce68e59ee2c758|7c551dab-88d0-1667-a4e8-a5d45f12df68",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19c7209ba00,
          },
          "e-468": {
            id: "e-468",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-469",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69a7fce0c0ed6710b5efc744|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69a7fce0c0ed6710b5efc744|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19cb833cbd5,
          },
          "e-469": {
            id: "e-469",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-468",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69a7fce0c0ed6710b5efc744|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69a7fce0c0ed6710b5efc744|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19cb833cbd5,
          },
          "e-470": {
            id: "e-470",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-471",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69a7fce0c0ed6710b5efc744|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69a7fce0c0ed6710b5efc744|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19cb833cbd5,
          },
          "e-471": {
            id: "e-471",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-470",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69a7fce0c0ed6710b5efc744|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69a7fce0c0ed6710b5efc744|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19cb833cbd5,
          },
          "e-472": {
            id: "e-472",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-473",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69a7fce0c0ed6710b5efc744|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69a7fce0c0ed6710b5efc744|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19cb833cbd5,
          },
          "e-473": {
            id: "e-473",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-472",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69a7fce0c0ed6710b5efc744|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69a7fce0c0ed6710b5efc744|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19cb833cbd5,
          },
          "e-474": {
            id: "e-474",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-475",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69a7fce0c0ed6710b5efc744|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69a7fce0c0ed6710b5efc744|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19cb833cbd5,
          },
          "e-475": {
            id: "e-475",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-474",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69a7fce0c0ed6710b5efc744|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69a7fce0c0ed6710b5efc744|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19cb833cbd5,
          },
          "e-476": {
            id: "e-476",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-41",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-477",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69a7fce0c0ed6710b5efc744|3d2a2523-3886-49b9-4687-96f36af1eef3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69a7fce0c0ed6710b5efc744|3d2a2523-3886-49b9-4687-96f36af1eef3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19cb833cbd5,
          },
          "e-478": {
            id: "e-478",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-56",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-479",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "0174441a-af9e-6111-e900-73e62701de2e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "0174441a-af9e-6111-e900-73e62701de2e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d061dcbf8,
          },
          "e-479": {
            id: "e-479",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-57",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-478",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "0174441a-af9e-6111-e900-73e62701de2e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "0174441a-af9e-6111-e900-73e62701de2e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d061dcbfa,
          },
          "e-480": {
            id: "e-480",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-56",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-481",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "0174441a-af9e-6111-e900-73e62701de42",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "0174441a-af9e-6111-e900-73e62701de42",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d0627b961,
          },
          "e-481": {
            id: "e-481",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-57",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-480",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "0174441a-af9e-6111-e900-73e62701de42",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "0174441a-af9e-6111-e900-73e62701de42",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d0627b963,
          },
          "e-482": {
            id: "e-482",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-483",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c10f4f42137e560992b1be|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c10f4f42137e560992b1be|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d1a23d240,
          },
          "e-483": {
            id: "e-483",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-482",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c10f4f42137e560992b1be|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c10f4f42137e560992b1be|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d1a23d240,
          },
          "e-484": {
            id: "e-484",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-485",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c10f4f42137e560992b1be|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c10f4f42137e560992b1be|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d1a23d240,
          },
          "e-485": {
            id: "e-485",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-484",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c10f4f42137e560992b1be|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c10f4f42137e560992b1be|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d1a23d240,
          },
          "e-486": {
            id: "e-486",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-487",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c10f4f42137e560992b1be|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c10f4f42137e560992b1be|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d1a23d240,
          },
          "e-487": {
            id: "e-487",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-486",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c10f4f42137e560992b1be|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c10f4f42137e560992b1be|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d1a23d240,
          },
          "e-488": {
            id: "e-488",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-489",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c10f4f42137e560992b1be|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c10f4f42137e560992b1be|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d1a23d240,
          },
          "e-489": {
            id: "e-489",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-488",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c10f4f42137e560992b1be|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c10f4f42137e560992b1be|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d1a23d240,
          },
          "e-490": {
            id: "e-490",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-40",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-491",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c10f4f42137e560992b1be|3d2a2523-3886-49b9-4687-96f36af1eef3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c10f4f42137e560992b1be|3d2a2523-3886-49b9-4687-96f36af1eef3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d1a23d240,
          },
          "e-492": {
            id: "e-492",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLLING_IN_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_CONTINUOUS_ACTION",
              config: {
                actionListId: "a-5",
                affectedElements: {},
                duration: 0,
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c10f4f42137e560992b1be|13069673-41e0-66bf-ee75-26809105d6b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c10f4f42137e560992b1be|13069673-41e0-66bf-ee75-26809105d6b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: [
              {
                continuousParameterGroupId: "a-5-p",
                smoothing: 75,
                startsEntering: !0,
                addStartOffset: !1,
                addOffsetValue: 50,
                startsExiting: !1,
                addEndOffset: !1,
                endOffsetValue: 50,
              },
            ],
            createdOn: 0x19d1a23d240,
          },
          "e-493": {
            id: "e-493",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLLING_IN_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_CONTINUOUS_ACTION",
              config: {
                actionListId: "a-5",
                affectedElements: {},
                duration: 0,
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c10f4f42137e560992b1be|40d9b13e-dcba-7600-62ff-7bc6bed05bdb",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c10f4f42137e560992b1be|40d9b13e-dcba-7600-62ff-7bc6bed05bdb",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: [
              {
                continuousParameterGroupId: "a-5-p",
                smoothing: 50,
                startsEntering: !0,
                addStartOffset: !1,
                addOffsetValue: 50,
                startsExiting: !1,
                addEndOffset: !1,
                endOffsetValue: 50,
              },
            ],
            createdOn: 0x19d1a23d240,
          },
          "e-494": {
            id: "e-494",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-495",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c3c5233a0e697a0415183f|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c3c5233a0e697a0415183f|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d24ba1446,
          },
          "e-495": {
            id: "e-495",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-494",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c3c5233a0e697a0415183f|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c3c5233a0e697a0415183f|a0ebca2c-1ad2-2ea8-5832-16fec8a6676b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d24ba1446,
          },
          "e-496": {
            id: "e-496",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-497",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c3c5233a0e697a0415183f|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c3c5233a0e697a0415183f|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d24ba1446,
          },
          "e-497": {
            id: "e-497",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-496",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c3c5233a0e697a0415183f|d0608f99-301f-004a-8981-8b2162b815b9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c3c5233a0e697a0415183f|d0608f99-301f-004a-8981-8b2162b815b9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d24ba1446,
          },
          "e-498": {
            id: "e-498",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-499",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c3c5233a0e697a0415183f|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c3c5233a0e697a0415183f|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d24ba1446,
          },
          "e-499": {
            id: "e-499",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-498",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c3c5233a0e697a0415183f|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c3c5233a0e697a0415183f|f58cdf73-92eb-a9d5-0246-3da71188eb4c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d24ba1446,
          },
          "e-500": {
            id: "e-500",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-501",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c3c5233a0e697a0415183f|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c3c5233a0e697a0415183f|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d24ba1446,
          },
          "e-501": {
            id: "e-501",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-500",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c3c5233a0e697a0415183f|eaeef379-e72d-c572-7b3c-6b3cd17da716",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c3c5233a0e697a0415183f|eaeef379-e72d-c572-7b3c-6b3cd17da716",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d24ba1446,
          },
          "e-502": {
            id: "e-502",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-41",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-503",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69c3c5233a0e697a0415183f|3d2a2523-3886-49b9-4687-96f36af1eef3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69c3c5233a0e697a0415183f|3d2a2523-3886-49b9-4687-96f36af1eef3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d24ba1446,
          },
          "e-504": {
            id: "e-504",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-505",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-505": {
            id: "e-505",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-504",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|a49cab9a-b28e-2128-e85e-b0634b8d180e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|a49cab9a-b28e-2128-e85e-b0634b8d180e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-506": {
            id: "e-506",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-507",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-507": {
            id: "e-507",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-506",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|58d24844-6490-59d4-bd5b-9083392d6a7e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|58d24844-6490-59d4-bd5b-9083392d6a7e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-508": {
            id: "e-508",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-509",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-509": {
            id: "e-509",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-508",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|49f32b68-e68e-be38-6f06-11709c07a2e3",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|49f32b68-e68e-be38-6f06-11709c07a2e3",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-510": {
            id: "e-510",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-511",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-511": {
            id: "e-511",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-510",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|b54f4ad6-92c6-7bc0-1d41-4c955b41a968",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-512": {
            id: "e-512",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-513",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-513": {
            id: "e-513",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-512",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|541c6d64-2f58-4717-1cc1-ab4c4a5dd28a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-514": {
            id: "e-514",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-515",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-515": {
            id: "e-515",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-514",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|1b590568-f54d-a46a-2375-abb9128fecc9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|1b590568-f54d-a46a-2375-abb9128fecc9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-516": {
            id: "e-516",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-517",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-517": {
            id: "e-517",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-516",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|ab2e29a4-6469-8c80-154a-01fa5fadb944",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|ab2e29a4-6469-8c80-154a-01fa5fadb944",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-518": {
            id: "e-518",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-519",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-519": {
            id: "e-519",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-518",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|dd86f20a-0c4e-551d-7aa2-ee55b794ff3a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-520": {
            id: "e-520",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-521",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-521": {
            id: "e-521",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-520",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|cef56f61-b82b-4a09-c5d7-8b6f73b7a59d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-522": {
            id: "e-522",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-34",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-523",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|f4ee31a0-4765-da94-17c5-c0c0e64e7ecd",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-524": {
            id: "e-524",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-35",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-525",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|47fe0c96-e668-2b0c-d4c9-c12e4fea27b8",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-526": {
            id: "e-526",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-54",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-527",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69cd4162e60a77ca748fc131|7c551dab-88d0-1667-a4e8-a5d45f12df68",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69cd4162e60a77ca748fc131|7c551dab-88d0-1667-a4e8-a5d45f12df68",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d49c76cad,
          },
          "e-528": {
            id: "e-528",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-58",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-529",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "690233775e450e4713bb0cdb|dc799aeb-2700-25e0-9009-cd9f847311f9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "690233775e450e4713bb0cdb|dc799aeb-2700-25e0-9009-cd9f847311f9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d4f17cf58,
          },
          "e-529": {
            id: "e-529",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-59",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-528",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "690233775e450e4713bb0cdb|dc799aeb-2700-25e0-9009-cd9f847311f9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "690233775e450e4713bb0cdb|dc799aeb-2700-25e0-9009-cd9f847311f9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d4f17cf59,
          },
          "e-530": {
            id: "e-530",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-58",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-531",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".card-link.case-study-hover",
              originalId:
                "6931c570dc7359dbc36b72bb|b62aa0b7-afaf-4371-cbdf-b5248fba82eb",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".card-link.case-study-hover",
                originalId:
                  "6931c570dc7359dbc36b72bb|b62aa0b7-afaf-4371-cbdf-b5248fba82eb",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d4f1fe0c6,
          },
          "e-531": {
            id: "e-531",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-59",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-530",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".card-link.case-study-hover",
              originalId:
                "6931c570dc7359dbc36b72bb|b62aa0b7-afaf-4371-cbdf-b5248fba82eb",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".card-link.case-study-hover",
                originalId:
                  "6931c570dc7359dbc36b72bb|b62aa0b7-afaf-4371-cbdf-b5248fba82eb",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d4f1fe0c7,
          },
          "e-532": {
            id: "e-532",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-533",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69d7702a99e81c884de7cf77|15b4f691-16af-1675-47df-f222432c987f",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69d7702a99e81c884de7cf77|15b4f691-16af-1675-47df-f222432c987f",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d72059646,
          },
          "e-533": {
            id: "e-533",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-532",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "69d7702a99e81c884de7cf77|15b4f691-16af-1675-47df-f222432c987f",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "69d7702a99e81c884de7cf77|15b4f691-16af-1675-47df-f222432c987f",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19d72059646,
          },
          "e-534": {
            id: "e-534",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-60",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-535",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".button-main-3.is-white",
              originalId: "b473a1bc-e3c5-7edc-cff7-15dc11afe5a1",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".button-main-3.is-white",
                originalId: "b473a1bc-e3c5-7edc-cff7-15dc11afe5a1",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192670b7a84,
          },
          "e-535": {
            id: "e-535",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-61",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-534",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".button-main-3.is-white",
              originalId: "b473a1bc-e3c5-7edc-cff7-15dc11afe5a1",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".button-main-3.is-white",
                originalId: "b473a1bc-e3c5-7edc-cff7-15dc11afe5a1",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x192670b7a85,
          },
          "e-536": {
            id: "e-536",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-537",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "698c6c788acd75c176aaf010|4c003213-3e95-dec9-eae0-f450f545e964",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "698c6c788acd75c176aaf010|4c003213-3e95-dec9-eae0-f450f545e964",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19caf198897,
          },
          "e-537": {
            id: "e-537",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-61",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-536",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".button-main-3.is-white",
              originalId:
                "698c6c788acd75c176aaf010|4c003213-3e95-dec9-eae0-f450f545e964",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".button-main-3.is-white",
                originalId:
                  "698c6c788acd75c176aaf010|4c003213-3e95-dec9-eae0-f450f545e964",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19caf198897,
          },
          "e-538": {
            id: "e-538",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-54",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-539",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "4442fb85-3a68-f73b-8972-2c55fe741f36",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "4442fb85-3a68-f73b-8972-2c55fe741f36",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19db01ed8b2,
          },
          "e-540": {
            id: "e-540",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-64",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-541",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".logo-wrap-home.hover-tooltip",
              originalId:
                "6931c570dc7359dbc36b72bb|18868a55-82dc-3377-0b2b-6404ced395f6",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".logo-wrap-home.hover-tooltip",
                originalId:
                  "6931c570dc7359dbc36b72bb|18868a55-82dc-3377-0b2b-6404ced395f6",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19db9bbefaf,
          },
          "e-541": {
            id: "e-541",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-65",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-540",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".logo-wrap-home.hover-tooltip",
              originalId:
                "6931c570dc7359dbc36b72bb|18868a55-82dc-3377-0b2b-6404ced395f6",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".logo-wrap-home.hover-tooltip",
                originalId:
                  "6931c570dc7359dbc36b72bb|18868a55-82dc-3377-0b2b-6404ced395f6",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19db9bbefb1,
          },
          "e-542": {
            id: "e-542",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-543",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6706f26421f0543fa87592a0|f97cbf12-05c3-47d3-85fb-28aceb73d5f7",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6706f26421f0543fa87592a0|f97cbf12-05c3-47d3-85fb-28aceb73d5f7",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19e1775681e,
          },
          "e-543": {
            id: "e-543",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-542",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6706f26421f0543fa87592a0|f97cbf12-05c3-47d3-85fb-28aceb73d5f7",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6706f26421f0543fa87592a0|f97cbf12-05c3-47d3-85fb-28aceb73d5f7",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19e1775681e,
          },
          "e-544": {
            id: "e-544",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-545",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6a01e09bb8ff57bb31aea0e0|91680f8b-962c-9128-46f9-89f260078cf7",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6a01e09bb8ff57bb31aea0e0|91680f8b-962c-9128-46f9-89f260078cf7",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19e17789cb4,
          },
          "e-545": {
            id: "e-545",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-544",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6a01e09bb8ff57bb31aea0e0|91680f8b-962c-9128-46f9-89f260078cf7",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "6a01e09bb8ff57bb31aea0e0|91680f8b-962c-9128-46f9-89f260078cf7",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19e17789cb4,
          },
          "e-546": {
            id: "e-546",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-547",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "698c6c788acd75c176aaf010|c09c2946-5884-9299-6e53-1d03d042e6af",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "698c6c788acd75c176aaf010|c09c2946-5884-9299-6e53-1d03d042e6af",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19e3a9cff72,
          },
          "e-547": {
            id: "e-547",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-546",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "698c6c788acd75c176aaf010|c09c2946-5884-9299-6e53-1d03d042e6af",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "698c6c788acd75c176aaf010|c09c2946-5884-9299-6e53-1d03d042e6af",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19e3a9cff72,
          },
          "e-548": {
            id: "e-548",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-549",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6706f26421f0543fa87592a0|b443a6b8-8b0e-a4ca-d511-3e996867b42e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19f0565eb88,
          },
          "e-549": {
            id: "e-549",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-548",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "6706f26421f0543fa87592a0|b443a6b8-8b0e-a4ca-d511-3e996867b42e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19f0565eb88,
          },
        },
        actionLists: {
          "a-9": {
            id: "a-9",
            title: "process-tabs-change",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-9-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".process-text-wrapper",
                        selectorGuids: ["7aae2074-6cb1-9217-4f8d-6dcb04b04dc7"],
                      },
                      heightValue: 0,
                      widthUnit: "PX",
                      heightUnit: "px",
                      locked: !1,
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-9-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".process-text-wrapper",
                        selectorGuids: ["7aae2074-6cb1-9217-4f8d-6dcb04b04dc7"],
                      },
                      widthUnit: "PX",
                      heightUnit: "AUTO",
                      locked: !1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x19244e1458b,
          },
          "a-10": {
            id: "a-10",
            title: "process-tabs-change 2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-10-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".process-text-wrapper",
                        selectorGuids: ["7aae2074-6cb1-9217-4f8d-6dcb04b04dc7"],
                      },
                      heightValue: 0,
                      widthUnit: "PX",
                      heightUnit: "px",
                      locked: !1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x19244e1458b,
          },
          "a-13": {
            id: "a-13",
            title: "fade-in-to-view",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-13-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".fade-in",
                        selectorGuids: ["5fb53b53-cd21-9b94-2bb5-a4a33b1e085c"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-13-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 750,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".fade-in",
                        selectorGuids: ["5fb53b53-cd21-9b94-2bb5-a4a33b1e085c"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x19247fd3f41,
          },
          "a-7": {
            id: "a-7",
            title: "blog-item-hover",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-7-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".blog-card-hover",
                        selectorGuids: ["6bdc3722-28c9-2add-fc29-9adee7e55563"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-7-n-8",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-hover-stroke",
                        selectorGuids: ["465bbb9f-f3f8-e04f-df02-063668afeac8"],
                      },
                      widthValue: 140,
                      widthUnit: "%",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-7-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-hover-stroke",
                        selectorGuids: ["465bbb9f-f3f8-e04f-df02-063668afeac8"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-7-n-3",
                    actionTypeId: "TRANSFORM_SCALE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hover-card-text",
                        selectorGuids: ["a053c71c-1534-e7c0-a38e-3f1459a9d12a"],
                      },
                      xValue: 1.4,
                      yValue: 1.4,
                      locked: !0,
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-7-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".blog-card-hover",
                        selectorGuids: ["6bdc3722-28c9-2add-fc29-9adee7e55563"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-7-n-4",
                    actionTypeId: "TRANSFORM_SCALE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hover-card-text",
                        selectorGuids: ["a053c71c-1534-e7c0-a38e-3f1459a9d12a"],
                      },
                      xValue: 1,
                      yValue: 1,
                      locked: !0,
                    },
                  },
                  {
                    id: "a-7-n-9",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-hover-stroke",
                        selectorGuids: ["465bbb9f-f3f8-e04f-df02-063668afeac8"],
                      },
                      widthValue: 120,
                      widthUnit: "%",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-7-n-7",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-hover-stroke",
                        selectorGuids: ["465bbb9f-f3f8-e04f-df02-063668afeac8"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x19244ab0f82,
          },
          "a-8": {
            id: "a-8",
            title: "blog-item-hover 2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-8-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".blog-card-hover",
                        selectorGuids: ["6bdc3722-28c9-2add-fc29-9adee7e55563"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-8-n-6",
                    actionTypeId: "TRANSFORM_SCALE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hover-card-text",
                        selectorGuids: ["a053c71c-1534-e7c0-a38e-3f1459a9d12a"],
                      },
                      xValue: 1.2,
                      yValue: 1.2,
                      locked: !0,
                    },
                  },
                  {
                    id: "a-8-n-7",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-hover-stroke",
                        selectorGuids: ["465bbb9f-f3f8-e04f-df02-063668afeac8"],
                      },
                      widthValue: 120,
                      widthUnit: "%",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-8-n-8",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-hover-stroke",
                        selectorGuids: ["465bbb9f-f3f8-e04f-df02-063668afeac8"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x19244ab0f82,
          },
          "a-15": {
            id: "a-15",
            title: "integrations-card-scroll-in",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-15-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector:
                          ".integrations-component-wrappper.hide-mobile-landscape",
                        selectorGuids: [
                          "32c04c66-3028-738c-8f92-187304b8c049",
                          "2389902a-cdc5-2548-7759-eba5575ebc70",
                        ],
                      },
                      widthValue: 0,
                      heightValue: 0,
                      widthUnit: "%",
                      heightUnit: "%",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-15-n-15",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector:
                          ".integrations-component-wrappper.hide-mobile-landscape",
                        selectorGuids: [
                          "32c04c66-3028-738c-8f92-187304b8c049",
                          "2389902a-cdc5-2548-7759-eba5575ebc70",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-15-n-9",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".integrations-middle",
                        selectorGuids: ["12f15d40-ab1f-4436-f986-0d6e29587046"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-15-n-8",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".integrations-bottom-middle",
                        selectorGuids: ["eccf2394-7425-d2b3-c78d-7fc2a6d78f79"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-15-n-7",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".integrations-center",
                        selectorGuids: ["496ef534-4c74-ea0a-fadc-57f5cb033ab5"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-15-n-6",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".inegrations-top",
                        selectorGuids: ["308714a7-e4d8-2663-01f9-52f9a137cc63"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-15-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".integrations-bottom",
                        selectorGuids: ["68b4cae1-44b3-947f-63f0-9a9270452847"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-15-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".webflow-icon",
                        selectorGuids: ["506183e2-136b-530e-2132-96821600b8f2"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-15-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 2e3,
                      target: {
                        selector:
                          ".integrations-component-wrappper.hide-mobile-landscape",
                        selectorGuids: [
                          "32c04c66-3028-738c-8f92-187304b8c049",
                          "2389902a-cdc5-2548-7759-eba5575ebc70",
                        ],
                      },
                      widthValue: 100,
                      heightValue: 100,
                      widthUnit: "%",
                      heightUnit: "%",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-15-n-16",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 2e3,
                      target: {
                        selector:
                          ".integrations-component-wrappper.hide-mobile-landscape",
                        selectorGuids: [
                          "32c04c66-3028-738c-8f92-187304b8c049",
                          "2389902a-cdc5-2548-7759-eba5575ebc70",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-15-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".webflow-icon",
                        selectorGuids: ["506183e2-136b-530e-2132-96821600b8f2"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-15-n-10",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 500,
                      easing: "ease",
                      duration: 2e3,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".integrations-middle",
                        selectorGuids: ["12f15d40-ab1f-4436-f986-0d6e29587046"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-15-n-14",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 500,
                      easing: "ease",
                      duration: 2e3,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".integrations-bottom",
                        selectorGuids: ["68b4cae1-44b3-947f-63f0-9a9270452847"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-15-n-13",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 500,
                      easing: "ease",
                      duration: 2e3,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".inegrations-top",
                        selectorGuids: ["308714a7-e4d8-2663-01f9-52f9a137cc63"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-15-n-12",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 500,
                      easing: "ease",
                      duration: 2e3,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".integrations-center",
                        selectorGuids: ["496ef534-4c74-ea0a-fadc-57f5cb033ab5"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-15-n-11",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 500,
                      easing: "ease",
                      duration: 2e3,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".integrations-bottom-middle",
                        selectorGuids: ["eccf2394-7425-d2b3-c78d-7fc2a6d78f79"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1924810a89a,
          },
          "a-16": {
            id: "a-16",
            title: "White-button-hover",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-16-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".button-bg-gradient",
                        selectorGuids: ["33a225cd-0caf-e980-01f0-f60fe12f36fe"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-16-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".button-bg-gradient",
                        selectorGuids: ["33a225cd-0caf-e980-01f0-f60fe12f36fe"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-16-n-3",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".button-main.is-white",
                        selectorGuids: [
                          "85b92749-30b7-8357-a17a-5febc34fd606",
                          "336570e9-535a-68eb-f09d-eb5a3bf97ed8",
                        ],
                      },
                      globalSwatchId: "--ffffff",
                      rValue: 255,
                      bValue: 255,
                      gValue: 255,
                      aValue: 1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x192670b8274,
          },
          "a-17": {
            id: "a-17",
            title: "White-button-hover 2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-17-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".button-bg-gradient",
                        selectorGuids: ["33a225cd-0caf-e980-01f0-f60fe12f36fe"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-17-n-3",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".button-main.is-white",
                        selectorGuids: [
                          "85b92749-30b7-8357-a17a-5febc34fd606",
                          "336570e9-535a-68eb-f09d-eb5a3bf97ed8",
                        ],
                      },
                      globalSwatchId: "--dark-blue",
                      rValue: 17,
                      bValue: 90,
                      gValue: 36,
                      aValue: 1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x192670b8274,
          },
          "a-23": {
            id: "a-23",
            title: "fade-into-view-0",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-23-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".fade-in-0",
                        selectorGuids: ["22cabcdc-e087-4e03-ed2c-649ccb09aa8a"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-23-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 750,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".fade-in-0",
                        selectorGuids: ["22cabcdc-e087-4e03-ed2c-649ccb09aa8a"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x19247fd3f41,
          },
          "a-11": {
            id: "a-11",
            title: "work-index-card-hover",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-11-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".work-category-arrow",
                        selectorGuids: ["56e75ca2-5903-afab-b1a1-bd333a7a5a91"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-11-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 400,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-tag",
                        selectorGuids: ["5b141a50-72d5-2610-ab70-30634f1ec43e"],
                      },
                      xValue: -2.75,
                      xUnit: "rem",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                  {
                    id: "a-11-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".work-category-arrow",
                        selectorGuids: ["56e75ca2-5903-afab-b1a1-bd333a7a5a91"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x19247d889ab,
          },
          "a-12": {
            id: "a-12",
            title: "work-index-card-hover 2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-12-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "easeIn",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".work-category-arrow",
                        selectorGuids: ["56e75ca2-5903-afab-b1a1-bd333a7a5a91"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-12-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "easeIn",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-tag",
                        selectorGuids: ["5b141a50-72d5-2610-ab70-30634f1ec43e"],
                      },
                      xValue: 0,
                      xUnit: "rem",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x19247d889ab,
          },
          "a-2": {
            id: "a-2",
            title: "service-card-hover",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-2-n-3",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-arrow",
                        selectorGuids: ["c4c60553-7cd3-7386-3584-39eb89a6c837"],
                      },
                      zValue: -45,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1921d444716,
          },
          "a-3": {
            id: "a-3",
            title: "service-card-hover-out",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-3-n-2",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-arrow",
                        selectorGuids: ["c4c60553-7cd3-7386-3584-39eb89a6c837"],
                      },
                      zValue: 0,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1921d444716,
          },
          "a-28": {
            id: "a-28",
            title: "badge-card-hover",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-28-n",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-arrow",
                        selectorGuids: ["c4c60553-7cd3-7386-3584-39eb89a6c837"],
                      },
                      zValue: -45,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1921d444716,
          },
          "a-29": {
            id: "a-29",
            title: "badge-card-hover-out",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-29-n",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-arrow",
                        selectorGuids: ["c4c60553-7cd3-7386-3584-39eb89a6c837"],
                      },
                      zValue: 0,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1921d444716,
          },
          "a-30": {
            id: "a-30",
            title: "work-hover-card | Hover in",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-30-n",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".blog-card-hover",
                        selectorGuids: ["6bdc3722-28c9-2add-fc29-9adee7e55563"],
                      },
                      value: "none",
                    },
                  },
                  {
                    id: "a-30-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".blog-card-hover",
                        selectorGuids: ["6bdc3722-28c9-2add-fc29-9adee7e55563"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-30-n-2",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".blog-card-hover",
                        selectorGuids: ["6bdc3722-28c9-2add-fc29-9adee7e55563"],
                      },
                      value: "flex",
                    },
                  },
                  {
                    id: "a-30-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "easeIn",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".blog-card-hover",
                        selectorGuids: ["6bdc3722-28c9-2add-fc29-9adee7e55563"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x192c8784454,
          },
          "a-31": {
            id: "a-31",
            title: "work-hover-card | Hover out",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-31-n",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "easeOut",
                      duration: 0,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".blog-card-hover",
                        selectorGuids: ["6bdc3722-28c9-2add-fc29-9adee7e55563"],
                      },
                      value: "none",
                    },
                  },
                  {
                    id: "a-31-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "easeOut",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".blog-card-hover",
                        selectorGuids: ["6bdc3722-28c9-2add-fc29-9adee7e55563"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x192c8784454,
          },
          "a-32": {
            id: "a-32",
            title: "Nav-dropdown-open",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-32-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".dropdown-list-wrapper",
                        selectorGuids: ["384d117a-076f-3f00-7df9-74fe994b9386"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-32-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".dropdown-list-wrapper",
                        selectorGuids: ["384d117a-076f-3f00-7df9-74fe994b9386"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x192d9dc6527,
          },
          "a-33": {
            id: "a-33",
            title: "Nav-dropdown-open 2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-33-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".dropdown-list-wrapper",
                        selectorGuids: ["384d117a-076f-3f00-7df9-74fe994b9386"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x192d9dc6527,
          },
          "a-34": {
            id: "a-34",
            title: "integrations-card-scroll-in 2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-34-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector:
                          ".integrations-component-wrappper.hide-mobile-landscape",
                        selectorGuids: [
                          "32c04c66-3028-738c-8f92-187304b8c049",
                          "2389902a-cdc5-2548-7759-eba5575ebc70",
                        ],
                      },
                      widthValue: 0,
                      heightValue: 0,
                      widthUnit: "%",
                      heightUnit: "%",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-34-n-17",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".integrartions-icon-wrapper",
                        selectorGuids: ["b769247b-1d66-e756-6a4e-8456afa8b1f0"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-34-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector:
                          ".integrations-component-wrappper.hide-mobile-landscape",
                        selectorGuids: [
                          "32c04c66-3028-738c-8f92-187304b8c049",
                          "2389902a-cdc5-2548-7759-eba5575ebc70",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-34-n-8",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".webflow-icon",
                        selectorGuids: ["506183e2-136b-530e-2132-96821600b8f2"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-34-n-9",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 1e3,
                      target: {
                        selector:
                          ".integrations-component-wrappper.hide-mobile-landscape",
                        selectorGuids: [
                          "32c04c66-3028-738c-8f92-187304b8c049",
                          "2389902a-cdc5-2548-7759-eba5575ebc70",
                        ],
                      },
                      widthValue: 100,
                      heightValue: 100,
                      widthUnit: "%",
                      heightUnit: "%",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-34-n-10",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector:
                          ".integrations-component-wrappper.hide-mobile-landscape",
                        selectorGuids: [
                          "32c04c66-3028-738c-8f92-187304b8c049",
                          "2389902a-cdc5-2548-7759-eba5575ebc70",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-34-n-11",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 1e3,
                      target: {
                        selector: ".webflow-icon",
                        selectorGuids: ["506183e2-136b-530e-2132-96821600b8f2"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-34-n-12",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 250,
                      easing: "ease",
                      duration: 1e3,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".integrations-middle",
                        selectorGuids: ["12f15d40-ab1f-4436-f986-0d6e29587046"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-34-n-18",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 250,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".integrartions-icon-wrapper",
                        selectorGuids: ["b769247b-1d66-e756-6a4e-8456afa8b1f0"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-34-n-13",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 250,
                      easing: "ease",
                      duration: 1e3,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".integrations-bottom",
                        selectorGuids: ["68b4cae1-44b3-947f-63f0-9a9270452847"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-34-n-14",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 250,
                      easing: "ease",
                      duration: 1e3,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".inegrations-top",
                        selectorGuids: ["308714a7-e4d8-2663-01f9-52f9a137cc63"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-34-n-15",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 250,
                      easing: "ease",
                      duration: 1e3,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".integrations-center",
                        selectorGuids: ["496ef534-4c74-ea0a-fadc-57f5cb033ab5"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-34-n-16",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 250,
                      easing: "ease",
                      duration: 1e3,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".integrations-bottom-middle",
                        selectorGuids: ["eccf2394-7425-d2b3-c78d-7fc2a6d78f79"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1924810a89a,
          },
          "a-35": {
            id: "a-35",
            title: "Home-hero-waterfall",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-35-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector:
                          ".heading-style-h2.text-align-center.black-text-gradient.max-width-xlarge",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27142",
                          "c2ce6606-bc95-e349-a521-ac3dd04e989e",
                          "b3f9a896-a72f-a347-ba30-e8659739bead",
                          "485692c6-5116-0d47-edf7-e9ffe18481d6",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-35-n-11",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".splide",
                        selectorGuids: ["aa2a8df6-039c-01f1-d039-6ffc46534bcf"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-35-n-9",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".home-hero-logo-component.for-home",
                        selectorGuids: [
                          "022e161d-cccf-fde6-63c8-04272c0bca06",
                          "3281dd07-cddf-c85f-d410-5ac72c01db22",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-35-n-7",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".form",
                        selectorGuids: ["d6562fbe-7f26-d4f4-0746-743996c414d9"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-35-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".text-size-s.text-align-center.mw-650",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27122",
                          "60f72115-6633-4391-83aa-20fc2396507f",
                          "df01f31f-c2b1-6016-ef0e-f4003f4c1932",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-35-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".flex-horizontal.gap-8",
                        selectorGuids: [
                          "c518aac4-d385-22fc-8c07-ac3512debeb0",
                          "9dacb071-1bcf-e98c-4622-4a3cc4c76f01",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-35-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector:
                          ".heading-style-h2.text-align-center.black-text-gradient.max-width-xlarge",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27142",
                          "c2ce6606-bc95-e349-a521-ac3dd04e989e",
                          "b3f9a896-a72f-a347-ba30-e8659739bead",
                          "485692c6-5116-0d47-edf7-e9ffe18481d6",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-35-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 200,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".flex-horizontal.gap-8",
                        selectorGuids: [
                          "c518aac4-d385-22fc-8c07-ac3512debeb0",
                          "9dacb071-1bcf-e98c-4622-4a3cc4c76f01",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-35-n-6",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 400,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".text-size-s.text-align-center.mw-650",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27122",
                          "60f72115-6633-4391-83aa-20fc2396507f",
                          "df01f31f-c2b1-6016-ef0e-f4003f4c1932",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-35-n-8",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 600,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".form",
                        selectorGuids: ["d6562fbe-7f26-d4f4-0746-743996c414d9"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-35-n-10",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 800,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".home-hero-logo-component.for-home",
                        selectorGuids: [
                          "022e161d-cccf-fde6-63c8-04272c0bca06",
                          "3281dd07-cddf-c85f-d410-5ac72c01db22",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-35-n-12",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 1e3,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".splide",
                        selectorGuids: ["aa2a8df6-039c-01f1-d039-6ffc46534bcf"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1930c4dfbbd,
          },
          "a-36": {
            id: "a-36",
            title: "about-hero-waterfall",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-36-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".heading-style-h2.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27142",
                          "156c9f60-c505-093c-d31d-3337b541e303",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-36-n-11",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        id: "66faa850635f83cedbab678d|e79acc70-df47-8210-8596-4429a9a30277",
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-36-n-9",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        id: "66faa850635f83cedbab678d|e79acc70-df47-8210-8596-4429a9a3026e",
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-36-n-7",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        id: "66faa850635f83cedbab678d|e79acc70-df47-8210-8596-4429a9a30265",
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-36-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".header-tag",
                        selectorGuids: ["9022e6d4-4037-4380-997f-a6aa02407f50"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-36-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".text-size-xl",
                        selectorGuids: ["f6e62f35-89df-25a5-6c03-68e70892b75a"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-36-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".heading-style-h2.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27142",
                          "156c9f60-c505-093c-d31d-3337b541e303",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-36-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 200,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".text-size-xl",
                        selectorGuids: ["f6e62f35-89df-25a5-6c03-68e70892b75a"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-36-n-6",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 400,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".header-tag",
                        selectorGuids: ["9022e6d4-4037-4380-997f-a6aa02407f50"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-36-n-8",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 600,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        id: "66faa850635f83cedbab678d|e79acc70-df47-8210-8596-4429a9a30265",
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-36-n-10",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 800,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        id: "66faa850635f83cedbab678d|e79acc70-df47-8210-8596-4429a9a3026e",
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-36-n-12",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 1e3,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        id: "66faa850635f83cedbab678d|e79acc70-df47-8210-8596-4429a9a30277",
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1930c543999,
          },
          "a-37": {
            id: "a-37",
            title: "design-and-dev-waterfall-hero",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-37-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h3.mw-540.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27103",
                          "5481861b-0539-5fa6-d7e9-c3f0a24c22f9",
                          "8d978d31-de99-0913-cf89-dd3000d87a9b",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-37-n-9",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".splide__list.work.stagger-animation",
                        selectorGuids: [
                          "248db211-cf9e-d772-a80e-42268483ffe3",
                          "3508e375-a6bf-a3ef-7061-7e95b5863147",
                          "125eabfc-8829-5a52-b220-a9ad77b53a54",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-37-n-7",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".splide__arrows.work",
                        selectorGuids: [
                          "ac5f53d1-9129-4fe0-b99e-ee50639fb08f",
                          "882af980-cb79-2a6a-afdf-06c0a884b678",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-37-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector:
                          ".heading-style-h4.black-text-gradient.mobile-align-center",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27133",
                          "ed22c008-cd62-8967-002d-9bc2196eaecb",
                          "71ae8537-6041-e649-6bda-f06304075e55",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-37-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".common-copy-wrapper",
                        selectorGuids: ["c7bb9382-3d24-8eab-5213-e2ad68ec83c9"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-37-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h3.mw-540.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27103",
                          "5481861b-0539-5fa6-d7e9-c3f0a24c22f9",
                          "8d978d31-de99-0913-cf89-dd3000d87a9b",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-37-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 200,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".common-copy-wrapper",
                        selectorGuids: ["c7bb9382-3d24-8eab-5213-e2ad68ec83c9"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-37-n-6",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 400,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector:
                          ".heading-style-h4.black-text-gradient.mobile-align-center",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27133",
                          "ed22c008-cd62-8967-002d-9bc2196eaecb",
                          "71ae8537-6041-e649-6bda-f06304075e55",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-37-n-8",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 400,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".splide__arrows.work",
                        selectorGuids: [
                          "ac5f53d1-9129-4fe0-b99e-ee50639fb08f",
                          "882af980-cb79-2a6a-afdf-06c0a884b678",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-37-n-10",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 600,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".splide__list.work.stagger-animation",
                        selectorGuids: [
                          "248db211-cf9e-d772-a80e-42268483ffe3",
                          "3508e375-a6bf-a3ef-7061-7e95b5863147",
                          "125eabfc-8829-5a52-b220-a9ad77b53a54",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1930c5600fc,
          },
          "a-38": {
            id: "a-38",
            title: "Site maintainance-waterfall",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-38-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h3.mw-540.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27103",
                          "5481861b-0539-5fa6-d7e9-c3f0a24c22f9",
                          "8d978d31-de99-0913-cf89-dd3000d87a9b",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-38-n-7",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".header-wrapper.mw-650",
                        selectorGuids: [
                          "a0fa0d11-7bf3-b143-f6ad-c989a1119288",
                          "72e1ab64-524e-c092-077a-5fa4fc440713",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-38-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".section-hero-logos",
                        selectorGuids: ["32196e74-9647-cfd2-1555-5f389b9a72fd"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-38-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".common-copy-wrapper",
                        selectorGuids: ["c7bb9382-3d24-8eab-5213-e2ad68ec83c9"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-38-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h3.mw-540.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27103",
                          "5481861b-0539-5fa6-d7e9-c3f0a24c22f9",
                          "8d978d31-de99-0913-cf89-dd3000d87a9b",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-38-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 200,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".common-copy-wrapper",
                        selectorGuids: ["c7bb9382-3d24-8eab-5213-e2ad68ec83c9"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-38-n-6",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 400,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".section-hero-logos",
                        selectorGuids: ["32196e74-9647-cfd2-1555-5f389b9a72fd"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-38-n-8",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 600,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".header-wrapper.mw-650",
                        selectorGuids: [
                          "a0fa0d11-7bf3-b143-f6ad-c989a1119288",
                          "72e1ab64-524e-c092-077a-5fa4fc440713",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1930c5ab8d7,
          },
          "a-39": {
            id: "a-39",
            title: "Webflow-enterprise-hero-waterfall",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-39-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".tag-wrapper.fade-in",
                        selectorGuids: [
                          "8e9dc97d-3a3c-7376-b723-652db3475de6",
                          "fda057ba-b689-85db-8cea-92cc52b788c9",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-39-n-9",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".section-hero-logos._1",
                        selectorGuids: [
                          "32196e74-9647-cfd2-1555-5f389b9a72fd",
                          "482733c3-01a6-8a38-cc25-58a65dee4669",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-39-n-7",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".button-main",
                        selectorGuids: ["85b92749-30b7-8357-a17a-5febc34fd606"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-39-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".text-size-s.text-align-center.mw-650",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27122",
                          "60f72115-6633-4391-83aa-20fc2396507f",
                          "df01f31f-c2b1-6016-ef0e-f4003f4c1932",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-39-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h2.text-align-center.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27142",
                          "c2ce6606-bc95-e349-a521-ac3dd04e989e",
                          "b3f9a896-a72f-a347-ba30-e8659739bead",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-39-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".tag-wrapper.fade-in",
                        selectorGuids: [
                          "8e9dc97d-3a3c-7376-b723-652db3475de6",
                          "fda057ba-b689-85db-8cea-92cc52b788c9",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-39-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 200,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h2.text-align-center.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27142",
                          "c2ce6606-bc95-e349-a521-ac3dd04e989e",
                          "b3f9a896-a72f-a347-ba30-e8659739bead",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-39-n-6",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 400,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".text-size-s.text-align-center.mw-650",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27122",
                          "60f72115-6633-4391-83aa-20fc2396507f",
                          "df01f31f-c2b1-6016-ef0e-f4003f4c1932",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-39-n-8",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 600,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".button-main",
                        selectorGuids: ["85b92749-30b7-8357-a17a-5febc34fd606"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-39-n-10",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 800,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".section-hero-logos._1",
                        selectorGuids: [
                          "32196e74-9647-cfd2-1555-5f389b9a72fd",
                          "482733c3-01a6-8a38-cc25-58a65dee4669",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1930c5cd27b,
          },
          "a-40": {
            id: "a-40",
            title: "figma-to-webflow-waterfall",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-40-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h3.mw-540.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27103",
                          "5481861b-0539-5fa6-d7e9-c3f0a24c22f9",
                          "8d978d31-de99-0913-cf89-dd3000d87a9b",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-40-n-7",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".work-content",
                        selectorGuids: ["68aea625-afb6-ef75-b076-05dfad07738e"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-40-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".section-trusted-by",
                        selectorGuids: ["63bf570c-f65b-0248-1f51-95e2e8b6796f"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-40-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".common-copy-wrapper",
                        selectorGuids: ["c7bb9382-3d24-8eab-5213-e2ad68ec83c9"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-40-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h3.mw-540.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27103",
                          "5481861b-0539-5fa6-d7e9-c3f0a24c22f9",
                          "8d978d31-de99-0913-cf89-dd3000d87a9b",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-40-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 200,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".common-copy-wrapper",
                        selectorGuids: ["c7bb9382-3d24-8eab-5213-e2ad68ec83c9"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-40-n-6",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 400,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".section-trusted-by",
                        selectorGuids: ["63bf570c-f65b-0248-1f51-95e2e8b6796f"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-40-n-8",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 600,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".work-content",
                        selectorGuids: ["68aea625-afb6-ef75-b076-05dfad07738e"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1930c5f7b5a,
          },
          "a-41": {
            id: "a-41",
            title: "webflow-dev-waterfall",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-41-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h3.mw-540.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27103",
                          "5481861b-0539-5fa6-d7e9-c3f0a24c22f9",
                          "8d978d31-de99-0913-cf89-dd3000d87a9b",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-41-n-7",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".header-wrapper.fade-in",
                        selectorGuids: [
                          "a0fa0d11-7bf3-b143-f6ad-c989a1119288",
                          "9a949a9e-dea7-7e6e-e564-6e9bed36b034",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-41-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".section-trusted-by",
                        selectorGuids: ["63bf570c-f65b-0248-1f51-95e2e8b6796f"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-41-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".common-copy-wrapper",
                        selectorGuids: ["c7bb9382-3d24-8eab-5213-e2ad68ec83c9"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-41-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h3.mw-540.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27103",
                          "5481861b-0539-5fa6-d7e9-c3f0a24c22f9",
                          "8d978d31-de99-0913-cf89-dd3000d87a9b",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-41-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 200,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".common-copy-wrapper",
                        selectorGuids: ["c7bb9382-3d24-8eab-5213-e2ad68ec83c9"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-41-n-6",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 400,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "SIBLINGS",
                        selector: ".section-trusted-by",
                        selectorGuids: ["63bf570c-f65b-0248-1f51-95e2e8b6796f"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-41-n-8",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 600,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".header-wrapper.fade-in",
                        selectorGuids: [
                          "a0fa0d11-7bf3-b143-f6ad-c989a1119288",
                          "9a949a9e-dea7-7e6e-e564-6e9bed36b034",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1930c623824,
          },
          "a-42": {
            id: "a-42",
            title: "markets-waterfall",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-42-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h3.mw-540.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27103",
                          "5481861b-0539-5fa6-d7e9-c3f0a24c22f9",
                          "8d978d31-de99-0913-cf89-dd3000d87a9b",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-42-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".work-content",
                        selectorGuids: ["68aea625-afb6-ef75-b076-05dfad07738e"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-42-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".common-copy-wrapper",
                        selectorGuids: ["c7bb9382-3d24-8eab-5213-e2ad68ec83c9"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-42-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h3.mw-540.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27103",
                          "5481861b-0539-5fa6-d7e9-c3f0a24c22f9",
                          "8d978d31-de99-0913-cf89-dd3000d87a9b",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-42-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 200,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".common-copy-wrapper",
                        selectorGuids: ["c7bb9382-3d24-8eab-5213-e2ad68ec83c9"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-42-n-6",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 400,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".work-content",
                        selectorGuids: ["68aea625-afb6-ef75-b076-05dfad07738e"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1930c640ff0,
          },
          "a-43": {
            id: "a-43",
            title: "Awards card hover",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-43-n",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-arrow",
                        selectorGuids: ["c4c60553-7cd3-7386-3584-39eb89a6c837"],
                      },
                      zValue: -45,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1932fcd2231,
          },
          "a-44": {
            id: "a-44",
            title: "Awards card hover 2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-44-n",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".card-arrow",
                        selectorGuids: ["c4c60553-7cd3-7386-3584-39eb89a6c837"],
                      },
                      zValue: 0,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1932fcd2231,
          },
          "a-45": {
            id: "a-45",
            title: "Work scroll into view",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-45-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h3.mw-540.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27103",
                          "5481861b-0539-5fa6-d7e9-c3f0a24c22f9",
                          "8d978d31-de99-0913-cf89-dd3000d87a9b",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-45-n-7",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        id: "66fbb1a30b4912068180f6c2|3b10e8fe-fde5-7f5e-bf9d-2dc57e0c5a37",
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-45-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".form-filters",
                        selectorGuids: ["bdb14ab2-beaf-f396-b683-a67fe8292109"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-45-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".common-copy-wrapper",
                        selectorGuids: ["c7bb9382-3d24-8eab-5213-e2ad68ec83c9"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-45-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector:
                          ".heading-style-h3.mw-540.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27103",
                          "5481861b-0539-5fa6-d7e9-c3f0a24c22f9",
                          "8d978d31-de99-0913-cf89-dd3000d87a9b",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-45-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 200,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".common-copy-wrapper",
                        selectorGuids: ["c7bb9382-3d24-8eab-5213-e2ad68ec83c9"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-45-n-6",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 400,
                      easing: "",
                      duration: 1e3,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".form-filters",
                        selectorGuids: ["bdb14ab2-beaf-f396-b683-a67fe8292109"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-45-n-8",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 600,
                      easing: "",
                      duration: 1e3,
                      target: {
                        id: "66fbb1a30b4912068180f6c2|3b10e8fe-fde5-7f5e-bf9d-2dc57e0c5a37",
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1934e247379,
          },
          "a-5": {
            id: "a-5",
            title: "logos-opposite-movement",
            continuousParameterGroups: [
              {
                id: "a-5-p",
                type: "SCROLL_PROGRESS",
                parameterLabel: "Scroll",
                continuousActionGroups: [
                  {
                    keyframe: 20,
                    actionItems: [
                      {
                        id: "a-5-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                          delay: 0,
                          easing: "",
                          duration: 500,
                          target: {
                            useEventTarget: "CHILDREN",
                            selector: ".top-certificates-wrapper.align-right",
                            selectorGuids: [
                              "6f89dcf4-e366-e21b-e712-e73acb09a16b",
                              "2ea48b83-3d68-6501-1351-42653fe17ccd",
                            ],
                          },
                          xValue: 0,
                          yValue: null,
                          xUnit: "%",
                          yUnit: "%",
                          zUnit: "PX",
                        },
                      },
                      {
                        id: "a-5-n-3",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                          delay: 0,
                          easing: "",
                          duration: 500,
                          target: {
                            useEventTarget: "CHILDREN",
                            selector: ".top-certificates-wrapper.align-left",
                            selectorGuids: [
                              "6f89dcf4-e366-e21b-e712-e73acb09a16b",
                              "844dc0d1-c678-5954-f762-08d02d0f4c50",
                            ],
                          },
                          xValue: 0,
                          xUnit: "%",
                          yUnit: "PX",
                          zUnit: "PX",
                        },
                      },
                    ],
                  },
                  {
                    keyframe: 100,
                    actionItems: [
                      {
                        id: "a-5-n-2",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                          delay: 0,
                          easing: "",
                          duration: 500,
                          target: {
                            useEventTarget: "CHILDREN",
                            selector: ".top-certificates-wrapper.align-right",
                            selectorGuids: [
                              "6f89dcf4-e366-e21b-e712-e73acb09a16b",
                              "2ea48b83-3d68-6501-1351-42653fe17ccd",
                            ],
                          },
                          xValue: -80,
                          xUnit: "%",
                          yUnit: "PX",
                          zUnit: "PX",
                        },
                      },
                      {
                        id: "a-5-n-4",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                          delay: 0,
                          easing: "",
                          duration: 500,
                          target: {
                            useEventTarget: "CHILDREN",
                            selector: ".top-certificates-wrapper.align-left",
                            selectorGuids: [
                              "6f89dcf4-e366-e21b-e712-e73acb09a16b",
                              "844dc0d1-c678-5954-f762-08d02d0f4c50",
                            ],
                          },
                          xValue: 80,
                          xUnit: "%",
                          yUnit: "PX",
                          zUnit: "PX",
                        },
                      },
                    ],
                  },
                ],
              },
            ],
            createdOn: 0x1921e4b85f4,
          },
          "a-46": {
            id: "a-46",
            title: "contact-page-scroll-into-view",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-46-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".heading-style-h2.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27142",
                          "156c9f60-c505-093c-d31d-3337b541e303",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-46-n-7",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".work-content",
                        selectorGuids: ["68aea625-afb6-ef75-b076-05dfad07738e"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-46-n-5",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".form-contact",
                        selectorGuids: ["a443f47c-12f5-d5c7-7f58-71d53b7a66c0"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-46-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".text-size-s",
                        selectorGuids: ["07815991-952a-8d98-0e00-e4c25af27122"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-46-n-9",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".trusted-by_wrap.hide-tablet",
                        selectorGuids: [
                          "069dca89-7033-3c59-d9f1-8b7183397ab2",
                          "7cacca33-4f9e-ae05-6ab6-ec515aeed515",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-46-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".heading-style-h2.black-text-gradient",
                        selectorGuids: [
                          "07815991-952a-8d98-0e00-e4c25af27142",
                          "156c9f60-c505-093c-d31d-3337b541e303",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-46-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 200,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".text-size-s",
                        selectorGuids: ["07815991-952a-8d98-0e00-e4c25af27122"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-46-n-10",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 300,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".trusted-by_wrap.hide-tablet",
                        selectorGuids: [
                          "069dca89-7033-3c59-d9f1-8b7183397ab2",
                          "7cacca33-4f9e-ae05-6ab6-ec515aeed515",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-46-n-6",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 400,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".form-contact",
                        selectorGuids: ["a443f47c-12f5-d5c7-7f58-71d53b7a66c0"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-46-n-8",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 600,
                      easing: "",
                      duration: 1e3,
                      target: {
                        selector: ".work-content",
                        selectorGuids: ["68aea625-afb6-ef75-b076-05dfad07738e"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1938dbbb7d2,
          },
          "a-48": {
            id: "a-48",
            title: "hamburger-menu-open",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-48-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.middle",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "b0cd004b-7113-8635-7425-bf34620838e1",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-48-n-5",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.bottom",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "e83d58a0-3f40-0863-76f9-2a03b11e53fa",
                        ],
                      },
                      zValue: -45,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                  {
                    id: "a-48-n-4",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.bottom",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "e83d58a0-3f40-0863-76f9-2a03b11e53fa",
                        ],
                      },
                      yValue: -0.5,
                      xUnit: "PX",
                      yUnit: "rem",
                      zUnit: "PX",
                    },
                  },
                  {
                    id: "a-48-n-3",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.top",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "08d14246-cde8-9f4f-20bd-88d2d77c529c",
                        ],
                      },
                      zValue: 45,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                  {
                    id: "a-48-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.top",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "08d14246-cde8-9f4f-20bd-88d2d77c529c",
                        ],
                      },
                      yValue: 0.125,
                      xUnit: "PX",
                      yUnit: "rem",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1943cfe9a05,
          },
          "a-49": {
            id: "a-49",
            title: "hamburger-menu-open 2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-49-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.middle",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "b0cd004b-7113-8635-7425-bf34620838e1",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-49-n-2",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.bottom",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "e83d58a0-3f40-0863-76f9-2a03b11e53fa",
                        ],
                      },
                      zValue: 0,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                  {
                    id: "a-49-n-3",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.bottom",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "e83d58a0-3f40-0863-76f9-2a03b11e53fa",
                        ],
                      },
                      yValue: 0,
                      xUnit: "PX",
                      yUnit: "rem",
                      zUnit: "PX",
                    },
                  },
                  {
                    id: "a-49-n-4",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.top",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "08d14246-cde8-9f4f-20bd-88d2d77c529c",
                        ],
                      },
                      zValue: 0,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                  {
                    id: "a-49-n-5",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.top",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "08d14246-cde8-9f4f-20bd-88d2d77c529c",
                        ],
                      },
                      yValue: 0,
                      xUnit: "PX",
                      yUnit: "rem",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1943cfe9a05,
          },
          "a-50": {
            id: "a-50",
            title: "Nav-dropdown-open 3",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-50-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".dropdown-list-wrapper",
                        selectorGuids: ["384d117a-076f-3f00-7df9-74fe994b9386"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-50-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".dropdown-list-wrapper",
                        selectorGuids: ["384d117a-076f-3f00-7df9-74fe994b9386"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x192d9dc6527,
          },
          "a-51": {
            id: "a-51",
            title: "Nav-dropdown-open 4",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-51-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".dropdown-list-wrapper",
                        selectorGuids: ["384d117a-076f-3f00-7df9-74fe994b9386"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x192d9dc6527,
          },
          "a-52": {
            id: "a-52",
            title: "hamburger-menu-open 3",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-52-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.middle",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "b0cd004b-7113-8635-7425-bf34620838e1",
                        ],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-52-n-2",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.bottom",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "e83d58a0-3f40-0863-76f9-2a03b11e53fa",
                        ],
                      },
                      zValue: -45,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                  {
                    id: "a-52-n-3",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.bottom",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "e83d58a0-3f40-0863-76f9-2a03b11e53fa",
                        ],
                      },
                      yValue: -0.4375,
                      xUnit: "PX",
                      yUnit: "rem",
                      zUnit: "PX",
                    },
                  },
                  {
                    id: "a-52-n-4",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.top",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "08d14246-cde8-9f4f-20bd-88d2d77c529c",
                        ],
                      },
                      zValue: 45,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                  {
                    id: "a-52-n-5",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.top",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "08d14246-cde8-9f4f-20bd-88d2d77c529c",
                        ],
                      },
                      yValue: 0.4375,
                      xUnit: "PX",
                      yUnit: "rem",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1943cfe9a05,
          },
          "a-53": {
            id: "a-53",
            title: "hamburger-menu-open 4",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-53-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.middle",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "b0cd004b-7113-8635-7425-bf34620838e1",
                        ],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-53-n-2",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.bottom",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "e83d58a0-3f40-0863-76f9-2a03b11e53fa",
                        ],
                      },
                      zValue: 0,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                  {
                    id: "a-53-n-3",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.bottom",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "e83d58a0-3f40-0863-76f9-2a03b11e53fa",
                        ],
                      },
                      yValue: 0,
                      xUnit: "PX",
                      yUnit: "rem",
                      zUnit: "PX",
                    },
                  },
                  {
                    id: "a-53-n-4",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.top",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "08d14246-cde8-9f4f-20bd-88d2d77c529c",
                        ],
                      },
                      zValue: 0,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                  {
                    id: "a-53-n-5",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".hamburge-bread.top",
                        selectorGuids: [
                          "97c41e2a-9e8b-dd34-e87c-7be11dc7d3b3",
                          "08d14246-cde8-9f4f-20bd-88d2d77c529c",
                        ],
                      },
                      yValue: 0,
                      xUnit: "PX",
                      yUnit: "rem",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1943cfe9a05,
          },
          "a-54": {
            id: "a-54",
            title: "Close Banner",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-54-n-3",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 500,
                      target: {
                        useEventTarget: "PARENT",
                        selector: ".nav-banner",
                        selectorGuids: ["5920dda0-8e75-b43b-5361-25295349c661"],
                      },
                      yValue: -4,
                      xUnit: "PX",
                      yUnit: "rem",
                      zUnit: "PX",
                    },
                  },
                  {
                    id: "a-54-n-4",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 500,
                      target: {
                        selector: ".home-nav-wrapper",
                        selectorGuids: ["a3f1b6fc-71c6-bb1b-0e97-12a4cd98b092"],
                      },
                      yValue: -2.5,
                      xUnit: "PX",
                      yUnit: "rem",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-54-n-2",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        useEventTarget: "PARENT",
                        selector: ".nav-banner",
                        selectorGuids: ["5920dda0-8e75-b43b-5361-25295349c661"],
                      },
                      value: "none",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1994865a11d,
          },
          "a-56": {
            id: "a-56",
            title: "mini-cs_hover-in",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-56-n",
                    actionTypeId: "STYLE_BORDER",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".mini-cs_content-wrap",
                        selectorGuids: ["a1a9cbc1-6638-4fac-fc0b-3ec08c905bd6"],
                      },
                      globalSwatchId: "",
                      rValue: 0,
                      bValue: 0,
                      gValue: 0,
                      aValue: 0,
                    },
                  },
                  {
                    id: "a-56-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".mini-cs_button-wrap",
                        selectorGuids: ["da5859aa-2e8b-f323-c810-53d9c67ea27e"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-56-n-2",
                    actionTypeId: "STYLE_BORDER",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".mini-cs_content-wrap",
                        selectorGuids: ["a1a9cbc1-6638-4fac-fc0b-3ec08c905bd6"],
                      },
                      globalSwatchId: "",
                      rValue: 52,
                      bValue: 229,
                      gValue: 103,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-56-n-4",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".mini-cs_button-wrap",
                        selectorGuids: ["da5859aa-2e8b-f323-c810-53d9c67ea27e"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x19d061e0071,
          },
          "a-57": {
            id: "a-57",
            title: "mini-cs_hover-out",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-57-n",
                    actionTypeId: "STYLE_BORDER",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".mini-cs_content-wrap",
                        selectorGuids: ["a1a9cbc1-6638-4fac-fc0b-3ec08c905bd6"],
                      },
                      globalSwatchId: "",
                      rValue: 0,
                      bValue: 0,
                      gValue: 0,
                      aValue: 0,
                    },
                  },
                  {
                    id: "a-57-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".mini-cs_button-wrap",
                        selectorGuids: ["da5859aa-2e8b-f323-c810-53d9c67ea27e"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x19d061e0071,
          },
          "a-58": {
            id: "a-58",
            title: "case-study_hover",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-58-n",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".case-study-hover_icon",
                        selectorGuids: ["b549945f-c08d-f41d-04c7-00c9e50042e7"],
                      },
                      zValue: 0,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-58-n-2",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        selector: ".case-study-hover_icon",
                        selectorGuids: ["b549945f-c08d-f41d-04c7-00c9e50042e7"],
                      },
                      zValue: -45,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x19d4f17daf0,
          },
          "a-59": {
            id: "a-59",
            title: "case-study_hover-out",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-59-n",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        selector: ".case-study-hover_icon",
                        selectorGuids: ["b549945f-c08d-f41d-04c7-00c9e50042e7"],
                      },
                      zValue: 0,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x19d4f17daf0,
          },
          "a-60": {
            id: "a-60",
            title: "White-button-hover 7",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-60-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".button-bg-gradient-2",
                        selectorGuids: ["1bf59912-dc1c-e826-10d2-1f480a1a7ab2"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-60-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".button-bg-gradient-2",
                        selectorGuids: ["1bf59912-dc1c-e826-10d2-1f480a1a7ab2"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                  {
                    id: "a-60-n-4",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".button-main-3.is-white",
                        selectorGuids: [
                          "1bf59912-dc1c-e826-10d2-1f480a1a7ab3",
                          "1bf59912-dc1c-e826-10d2-1f480a1a7ab5",
                        ],
                      },
                      globalSwatchId: "--ffffff",
                      rValue: 255,
                      bValue: 255,
                      gValue: 255,
                      aValue: 1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x192670b8274,
          },
          "a-61": {
            id: "a-61",
            title: "White-button-hover 8",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-61-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".button-bg-gradient-2",
                        selectorGuids: ["1bf59912-dc1c-e826-10d2-1f480a1a7ab2"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-61-n-3",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 300,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".button-main-3.is-white",
                        selectorGuids: [
                          "1bf59912-dc1c-e826-10d2-1f480a1a7ab3",
                          "1bf59912-dc1c-e826-10d2-1f480a1a7ab5",
                        ],
                      },
                      globalSwatchId: "--dark-blue",
                      rValue: 17,
                      bValue: 90,
                      gValue: 36,
                      aValue: 1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x192670b8274,
          },
          "a-64": {
            id: "a-64",
            title: "logo-bar_hover-in",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-64-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".home-hero-popup-card",
                        selectorGuids: ["88fa63a1-6735-c346-e877-8eb06049dcc9"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-64-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".home-hero-popup-card",
                        selectorGuids: ["88fa63a1-6735-c346-e877-8eb06049dcc9"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x19db9bc2449,
          },
          "a-65": {
            id: "a-65",
            title: "logo-bar_hover-out",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-65-n",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "ease",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".home-hero-popup-card",
                        selectorGuids: ["88fa63a1-6735-c346-e877-8eb06049dcc9"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x19db9bc2449,
          },
        },
        site: {
          mediaQueries: [
            { key: "main", min: 992, max: 1e4 },
            { key: "medium", min: 768, max: 991 },
            { key: "small", min: 480, max: 767 },
            { key: "tiny", min: 0, max: 479 },
          ],
        },
      });
    },
  },
]);
