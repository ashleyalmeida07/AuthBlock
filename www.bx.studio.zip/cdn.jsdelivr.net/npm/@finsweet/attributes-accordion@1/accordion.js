"use strict";
(() => {
  var A = "fs-attributes";
  var $ = "a11y",
    m = "accordion";
  var V = "cmsattribute";
  var I = "cmsload";
  var C = "support";
  var L = async (...t) => {
    var o;
    let e = [];
    for (let s of t) {
      let r = await ((o = window.fsAttributes[s]) == null ? void 0 : o.loading);
      e.push(r);
    }
    return e;
  };
  var E = () => {};
  function d(t, e, o, s) {
    return t
      ? (t.addEventListener(e, o, s), () => t.removeEventListener(e, o, s))
      : E;
  }
  var f = (t, e) => !!t && e.includes(t);
  var N = (t) => t != null;
  var _ = (t) => typeof t == "string";
  function U(t, e, o, s = !0) {
    let r = o ? [o] : [];
    if (!t) return r;
    let i = t.split(",").reduce((n, c) => {
      let a = c.trim();
      return (!s || a) && n.push(a), n;
    }, []);
    if (e) {
      let n = i.filter((c) => f(c, e));
      return n.length ? n : r;
    }
    return i;
  }
  var y = (t) =>
    !!(t.offsetWidth || t.offsetHeight || t.getClientRects().length);
  function H(t, e, o) {
    var r;
    let s = window.fsAttributes[t];
    return (s.destroy = o || E), (r = s.resolve) == null || r.call(s, e), e;
  }
  var G = (t, e = "1", o = "iife") => {
    let r = `${t}${o === "esm" ? ".esm" : ""}.js`;
    return `https://cdn.jsdelivr.net/npm/@finsweet/attributes-${t}@${e}/${r}`;
  };
  var pt = `${A}-${C}`,
    k = async () => {
      var r;
      let { fsAttributes: t, location: e } = window,
        { host: o, searchParams: s } = new URL(e.href);
      return !o.includes("webflow.io") || !s.has(pt)
        ? !1
        : (r = t.import) == null
        ? void 0
        : r.call(t, C, "1");
    };
  var R = (t) => {
    let e = (r, i, n) => {
      let c = t[r],
        { key: a, values: l } = c,
        u;
      if (!i) return `[${a}]`;
      let S = l == null ? void 0 : l[i];
      _(S)
        ? (u = S)
        : (u = S(n && "instanceIndex" in n ? n.instanceIndex : void 0));
      let b = n && "caseInsensitive" in n && n.caseInsensitive ? "i" : "";
      if (!(n != null && n.operator)) return `[${a}="${u}"${b}]`;
      switch (n.operator) {
        case "prefixed":
          return `[${a}^="${u}"${b}]`;
        case "suffixed":
          return `[${a}$="${u}"${b}]`;
        case "contains":
          return `[${a}*="${u}"${b}]`;
      }
    };
    function o(r, i) {
      let n = e("element", r, i),
        c = (i == null ? void 0 : i.scope) || document;
      return i != null && i.all
        ? [...c.querySelectorAll(n)]
        : c.querySelector(n);
    }
    return [
      e,
      o,
      (r, i) => {
        let n = t[i];
        return n ? r.getAttribute(n.key) : null;
      },
    ];
  };
  var x = {
      preventLoad: { key: `${A}-preventload` },
      debugMode: { key: `${A}-debug` },
      src: { key: "src", values: { finsweet: "@finsweet/attributes" } },
      dev: { key: `${A}-dev` },
    },
    [w, se] = R(x);
  var F = (t) => {
    let { currentScript: e } = document,
      o = {};
    if (!e) return { attributes: o, preventsLoad: !1 };
    let r = {
      preventsLoad: _(e.getAttribute(x.preventLoad.key)),
      attributes: o,
    };
    for (let i in t) {
      let n = e.getAttribute(t[i]);
      r.attributes[i] = n;
    }
    return r;
  };
  var q = ({ scriptAttributes: t, attributeKey: e, version: o, init: s }) => {
      var c;
      mt(), (c = window.fsAttributes)[e] || (c[e] = {});
      let { preventsLoad: r, attributes: i } = F(t),
        n = window.fsAttributes[e];
      (n.version = o),
        (n.init = s),
        r ||
          (window.Webflow || (window.Webflow = []),
          window.Webflow.push(() => s(i)));
    },
    mt = () => {
      let t = Tt();
      if (window.fsAttributes && !Array.isArray(window.fsAttributes)) {
        B(window.fsAttributes, t);
        return;
      }
      let e = At(t);
      B(e, t),
        Et(e),
        (window.fsAttributes = e),
        (window.FsAttributes = window.fsAttributes),
        k();
    },
    At = (t) => {
      let e = {
        cms: {},
        push(...o) {
          var s, r;
          for (let [i, n] of o)
            (r = (s = this[i]) == null ? void 0 : s.loading) == null ||
              r.then(n);
        },
        async import(o, s) {
          let r = e[o];
          return (
            r ||
            new Promise((i) => {
              let n = document.createElement("script");
              (n.src = G(o, s)),
                (n.async = !0),
                (n.onload = () => {
                  let [c] = B(e, [o]);
                  i(c);
                }),
                document.head.append(n);
            })
          );
        },
        destroy() {
          var o, s;
          for (let r of t)
            (s = (o = window.fsAttributes[r]) == null ? void 0 : o.destroy) ==
              null || s.call(o);
        },
      };
      return e;
    },
    Tt = () => {
      let t = w("src", "finsweet", { operator: "contains" }),
        e = w("dev");
      return [...document.querySelectorAll(`script${t}, script${e}`)].reduce(
        (r, i) => {
          var c;
          let n =
            i.getAttribute(x.dev.key) ||
            ((c = i.src.match(/[\w-. ]+(?=(\.js)$)/)) == null ? void 0 : c[0]);
          return n && !r.includes(n) && r.push(n), r;
        },
        []
      );
    },
    B = (t, e) =>
      e.map((s) => {
        let r = t[s];
        return (
          r ||
          ((t[s] = {}),
          (r = t[s]),
          (r.loading = new Promise((i) => {
            r.resolve = (n) => {
              i(n), delete r.resolve;
            };
          })),
          r)
        );
      }),
    Et = (t) => {
      let e = Array.isArray(window.fsAttributes) ? window.fsAttributes : [];
      t.push(...e);
    };
  var j = "1.1.2";
  var X = () => {
    var t, e;
    return (e = (t = window.fsAttributes).import) == null
      ? void 0
      : e.call(t, $, "1");
  };
  var g = `fs-${m}`,
    ft = "group",
    xt = "accordion",
    bt = "trigger",
    It = "content",
    _t = "arrow",
    yt = "single",
    v = { true: "true" },
    Rt = "initial",
    gt = { none: "none" },
    St = "active",
    h = {
      element: {
        key: `${g}-element`,
        values: {
          group: ft,
          accordion: xt,
          trigger: bt,
          content: It,
          arrow: _t,
        },
      },
      single: { key: `${g}-${yt}`, values: v },
      initial: { key: `${g}-${Rt}`, values: gt },
      active: { key: `${g}-${St}` },
    },
    [W, T, p] = R(h),
    z = `is-active-${m}`,
    Q = `[fs-${I}-element^="list"]`;
  var K = (t) => {
      let e = Z();
      if (!t) return e;
      let o = new Set(e);
      for (let { items: s } of t)
        for (let { element: r } of s) {
          let i = Z(r);
          for (let n of i) o.add(n);
        }
      return [...o];
    },
    Z = (t) => T("accordion", { scope: t, operator: "prefixed", all: !0 });
  var J = "role";
  var tt = "tabindex",
    et = "aria-label",
    O = "aria-labelledby";
  var ot = "aria-controls";
  var rt = (t = 21) =>
    crypto
      .getRandomValues(new Uint8Array(t))
      .reduce(
        (e, o) => (
          (o &= 63),
          o < 36
            ? (e += o.toString(36))
            : o < 62
            ? (e += (o - 26).toString(36).toUpperCase())
            : o > 62
            ? (e += "-")
            : (e += "_"),
          e
        ),
        ""
      );
  var M = (t) => {
    if (!t.id || document.getElementById(t.id) !== t) {
      let e = rt();
      return (t.id = e), e;
    }
    return t.id;
  };
  function st(t, e) {
    if (!t) return e != null ? e : null;
    let o = Number(t);
    return isNaN(o) ? e || null : o;
  }
  var nt = (t, e) => {
    let o = M(t),
      s = M(e);
    t.setAttribute(J, "button"),
      t.setAttribute(ot, s),
      t.setAttribute(tt, "0"),
      !e.hasAttribute(O) && !e.hasAttribute(et) && e.setAttribute(O, o);
  };
  var D = ({
    accordion: t,
    trigger: e,
    content: o,
    arrow: s,
    isOpen: r,
    groupActiveClass: i,
    accordionActiveClass: n,
    arrowActiveClass: c,
    contentActiveClass: a,
    triggerActiveClass: l,
  }) => {
    let u = r ? "add" : "remove";
    t.classList[u](n || i),
      e.classList[u](l || i),
      o.classList[u](a || i),
      s == null || s.classList[u](c || i);
  };
  var P = (t) => `${getComputedStyle(t).height}`;
  var it = (t) => {
      (t.style.display = "block"), (t.style.maxHeight = "");
      let e = P(t);
      (t.style.maxHeight = "0px"),
        requestAnimationFrame(() => {
          t.style.maxHeight = e;
        });
    },
    Y = (t) => {
      let e = d(t, "transitionend", ({ propertyName: s }) => {
          s === "max-height" && ((t.style.display = "none"), e());
        }),
        o = P(t);
      return (
        (t.style.maxHeight = o),
        requestAnimationFrame(() => {
          t.style.maxHeight = "0px";
        }),
        e
      );
    };
  var ct = (t) => {
      let e = p(t, "single") === v.true,
        o = p(t, "initial"),
        s = p(t, "active") || z,
        r;
      return (
        o &&
          (f(o, Object.values(h.initial.values))
            ? (r = o)
            : (r = U(o).map(st).filter(N))),
        { single: e, initial: r, activeClass: s, accordions: [] }
      );
    },
    at = (t, e) => {
      let o = T("trigger", { operator: "prefixed", scope: t }),
        s = T("content", { operator: "prefixed", scope: t }),
        r = T("arrow", { operator: "prefixed", scope: t });
      if (!o || !s) return;
      let i = e.activeClass,
        n = p(t, "active"),
        c = p(o, "active"),
        a = p(s, "active"),
        l = r ? p(r, "active") : null;
      return {
        accordion: t,
        trigger: o,
        content: s,
        arrow: r,
        groupActiveClass: i,
        accordionActiveClass: n,
        triggerActiveClass: c,
        contentActiveClass: a,
        arrowActiveClass: l,
      };
    };
  var ut = (t) => {
      let o = t
        .reduce((s, r) => {
          let i = r.closest(W("element", "group")) || document.body,
            n = s.get(i);
          n || ((n = ct(i)), s.set(i, n));
          let c = Ct(r, n);
          return c && n.accordions.push({ accordion: r, controls: c }), s;
        }, new Map())
        .values();
      for (let s of o) Lt(s);
      return o;
    },
    Ct = (t, e) => {
      let o = at(t, e);
      if (!o) return;
      let { trigger: s, content: r } = o,
        i = y(r),
        n;
      y(t) || (n = Y(r)), nt(s, r), D({ ...o, isOpen: i });
      let c = (l) => {
        if ((n == null || n(), (n = void 0), i)) (n = Y(r)), (i = !1);
        else if ((it(r), (i = !0), e.single && l))
          for (let u of e.accordions) u.accordion !== t && u.controls.close();
        D({ ...o, isOpen: i });
      };
      return {
        destroy: d(s, "click", c),
        open: () => {
          i || c();
        },
        close: () => {
          i && c();
        },
        isOpen: () => i,
      };
    },
    Lt = ({ single: t, initial: e, accordions: o }) => {
      let s = !1,
        r = e === "none",
        i = Array.isArray(e);
      for (let [n, { controls: c }] of o.entries()) {
        let a = n + 1,
          l = i && e.includes(a);
        if ((t && s) || (i && !e.includes(a)) || r) {
          c.close();
          continue;
        }
        l && (c.open(), (s = !0)), s || (s = c.isOpen());
      }
    };
  var lt = async () => {
    await L(V);
    let t = K();
    if (t.some((s) => s.closest(Q))) {
      let s = (await L(I))[0];
      t = K(s);
    }
    let o = ut(t);
    return (
      X(),
      H(m, o, () => {
        for (let { accordions: s } of o)
          for (let { controls: r } of s) r.destroy();
      })
    );
  };
  q({ init: lt, version: j, attributeKey: m });
})();
